<?php require_once __DIR__ . '/config.php'; require_login(); ?>
<?php
$user = current_user();
$success = '';
if (is_post()) {
  verify_csrf();
  $name = trim($_POST['name'] ?? '');
  if ($name !== '') {
    $stmt = db()->prepare("UPDATE users SET name=? WHERE id=?");
    $stmt->execute([$name, $user['id']]);
    $_SESSION['user']['name'] = $name;
    $success = 'به‌روزرسانی شد.';
  }
}
?>
<?php include __DIR__ . '/includes/header.php'; ?>
<?php include __DIR__ . '/includes/navbar.php'; ?>
<main class="container my-4" style="max-width:560px">
  <h1 class="h5 mb-3">پروفایل</h1>
  <?php if ($success): ?><div class="alert alert-success"><?= e($success) ?></div><?php endif; ?>
  <form method="post">
    <input type="hidden" name="_token" value="<?= e(csrf_token()) ?>">
    <div class="mb-3">
      <label class="form-label">نام</label>
      <input type="text" name="name" class="form-control" value="<?= e($user['name']) ?>" required>
    </div>
    <button class="btn btn-primary">ذخیره</button>
  </form>
</main>
<?php include __DIR__ . '/includes/footer.php'; ?>
