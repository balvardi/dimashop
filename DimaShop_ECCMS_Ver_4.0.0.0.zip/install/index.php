<?php
declare(strict_types=1);

/**
 * Dima Shop - Simple Installer
 * - Run: http://your-host/install/index.php
 * - After success, delete the "install" folder.
 */

function default_base_url(): string {
  $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
  $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
  $scriptDir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
  // remove trailing /install from the path
  $base = preg_replace('~/install$~', '', $scriptDir);
  if ($base === '') $base = '/';
  if (substr($base, -1) !== '/') $base .= '/';
  return $base;
}

$root = realpath(__DIR__ . '/..');
$lockFile = $root . '/installed.lock';
$configFile = $root . '/config.php';
$schemaFile = $root . '/sql/schema.sql';
$seedFile   = $root . '/sql/seed.sql';
$uploadsDir = $root . '/uploads';

$errors = [];
$success = '';
$installed = file_exists($lockFile);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$installed) {
  // Gather inputs
  $db_host = trim($_POST['db_host'] ?? '127.0.0.1');
  $db_name = trim($_POST['db_name'] ?? 'dima_shop');
  $db_user = trim($_POST['db_user'] ?? 'root');
  $db_pass = (string)($_POST['db_pass'] ?? '');
  $create_db = isset($_POST['create_db']);
  $run_seed = isset($_POST['run_seed']);
  $base_url = trim($_POST['base_url'] ?? default_base_url());
  $app_key = trim($_POST['app_key'] ?? '');
  if ($app_key === '') $app_key = bin2hex(random_bytes(32));

  $admin_name = trim($_POST['admin_name'] ?? 'Administrator');
  $admin_email = trim($_POST['admin_email'] ?? 'admin@example.com');
  $admin_pass = (string)($_POST['admin_pass'] ?? 'Admin@12345');

  $zarin_merchant = trim($_POST['zarin_merchant'] ?? '');
  $zarin_sandbox = isset($_POST['zarin_sandbox']);

  // Basic validation
  if ($db_host === '' || $db_name === '' || $db_user === '') $errors[] = 'اطلاعات دیتابیس را کامل وارد کنید.';
  if (!filter_var($admin_email, FILTER_VALIDATE_EMAIL)) $errors[] = 'ایمیل ادمین نامعتبر است.';
  if (strlen($admin_pass) < 8) $errors[] = 'رمز عبور ادمین باید حداقل 8 کاراکتر باشد.';

  // Connect and install
  if (!$errors) {
    try {
      // Step 1: Connect to server (no DB name first if create_db requested)
      $dsnNoDb = 'mysql:host=' . $db_host . ';charset=utf8mb4';
      $pdo = new PDO($dsnNoDb, $db_user, $db_pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
      ]);

      // Step 2: Create database if requested
      if ($create_db) {
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `" . str_replace('`','``',$db_name) . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci");
      }

      // Step 3: Connect to target database
      $dsn = 'mysql:host=' . $db_host . ';dbname=' . $db_name . ';charset=utf8mb4';
      $db = new PDO($dsn, $db_user, $db_pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
      ]);

      // Step 4: Run schema.sql
      if (!file_exists($schemaFile)) throw new Exception('فایل schema.sql یافت نشد.');
      run_sql_file($db, $schemaFile);

      // Step 5: Run seed.sql (optional)
      if ($run_seed) {
        if (!file_exists($seedFile)) throw new Exception('فایل seed.sql یافت نشد.');
        run_sql_file($db, $seedFile);
      }

      // Step 6: Create/Update admin user
      $hash = password_hash($admin_pass, PASSWORD_BCRYPT);
      $stmt = $db->prepare("SELECT id FROM users WHERE email=? LIMIT 1");
      $stmt->execute([$admin_email]);
      $existing = $stmt->fetchColumn();
      if ($existing) {
        $upd = $db->prepare("UPDATE users SET name=?, password_hash=?, role='admin' WHERE id=?");
        $upd->execute([$admin_name, $hash, $existing]);
      } else {
        $ins = $db->prepare("INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?,'admin')");
        $ins->execute([$admin_name, $admin_email, $hash]);
      }

      // Step 7: Ensure uploads dir
      if (!is_dir($uploadsDir)) {
        @mkdir($uploadsDir, 0775, true);
      }

      // Step 8: Write config.php
      $cfg = build_config_php($db_host, $db_name, $db_user, $db_pass, $base_url, $app_key, $zarin_merchant, $zarin_sandbox);
      // Backup old config if exists
      if (file_exists($configFile)) {
        @copy($configFile, $configFile . '.bak');
      }
      if (file_put_contents($configFile, $cfg) === false) {
        throw new Exception('عدم امکان نوشتن فایل config.php');
      }

      // Step 9: Create installed.lock
      @file_put_contents($lockFile, date('c'));

      $success = 'نصب با موفقیت انجام شد.';
      $installed = true;

    } catch (Throwable $e) {
      $errors[] = $e->getMessage();
    }
  }
}

function run_sql_file(PDO $pdo, string $filePath): void {
  $sql = file_get_contents($filePath);
  if ($sql === false) throw new Exception('عدم امکان خواندن فایل SQL: ' . $filePath);

  // Remove BOM
  $sql = preg_replace('/^\xEF\xBB\xBF/', '', $sql);
  // Remove comments (basic)
  $sql = preg_replace('~/\*.*?\*/~s', '', $sql);
  $lines = explode("\n", $sql);
  $clean = [];
  foreach ($lines as $line) {
    // Remove -- comments
    if (preg_match('~^\s*--~', $line)) continue;
    $clean[] = $line;
  }
  $sql = implode("\n", $clean);

  // Split by semicolon
  $statements = array_filter(array_map('trim', explode(';', $sql)), function ($s) {
    return $s !== '';
  });

  foreach ($statements as $stmt) {
    $pdo->exec($stmt);
  }
}

function build_config_php(string $host, string $name, string $user, string $pass, string $baseUrl, string $appKey, string $zarinMerchant, bool $zarinSandbox): string {
  $baseUrl = rtrim($baseUrl, '/') . '/';
  $sandbox = $zarinSandbox ? 'true' : 'false';
  $merchant = $zarinMerchant !== '' ? $zarinMerchant : 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx';
  $tpl = <<<PHP
<?php
// Dima Shop - Configuration (generated by installer)
declare(strict_types=1);

define('DB_HOST', %s);
define('DB_NAME', %s);
define('DB_USER', %s);
define('DB_PASS', %s);
define('DB_CHARSET', 'utf8mb4');

define('BASE_URL', %s);

// For CSRF tokens
define('APP_KEY', %s);

// Uploads directory (relative to project root)
define('UPLOAD_DIR', __DIR__ . '/uploads');

// Session settings
ini_set('session.cookie_httponly', '1');
// For HTTPS in production: ini_set('session.cookie_secure', '1');

if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

require_once __DIR__ . '/db/connection.php';
require_once __DIR__ . '/lib/helpers.php';

// Zarinpal config
define('ZARINPAL_MERCHANT_ID', %s);
define('ZARINPAL_SANDBOX', %s);

// Helper: Build absolute URL (https/http + host + BASE_URL)
function app_base_url(): string {
  \$scheme = (!empty(\$_SERVER['HTTPS']) && \$_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
  \$host = \$_SERVER['HTTP_HOST'] ?? 'localhost';
  \$base = rtrim(BASE_URL, '/');
  return \$scheme . '://' . \$host . \$base;
}
PHP;

  return sprintf(
    $tpl,
    var_export($host, true),
    var_export($name, true),
    var_export($user, true),
    var_export($pass, true),
    var_export($baseUrl, true),
    var_export($appKey, true),
    var_export($merchant, true),
    $sandbox
  );
}

?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="utf-8">
  <title>نصب دیماشاپ</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css"
        crossorigin="anonymous">
</head>
<body>
<div class="container my-5" style="max-width: 860px;">
  <h1 class="h4 mb-4">نصاب دیماشاپ</h1>

  <?php if ($installed): ?>
    <div class="alert alert-success">این سیستم قبلاً نصب شده است.</div>
    <div class="d-flex gap-2">
      <a class="btn btn-primary" href="<?= htmlspecialchars('../index.php', ENT_QUOTES) ?>">ورود به سایت</a>
      <a class="btn btn-outline-secondary" href="<?= htmlspecialchars('../admin/auth.php', ENT_QUOTES) ?>">ورود مدیر</a>
    </div>
    <p class="text-muted small mt-3">برای امنیت، توصیه می‌شود پوشه install را حذف کنید.</p>
  <?php else: ?>

    <?php if ($errors): ?>
      <div class="alert alert-danger">
        <?php foreach ($errors as $er): ?>
          <div><?= htmlspecialchars($er, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?></div>
        <?php endforeach; ?>
      </div>
    <?php elseif ($success): ?>
      <div class="alert alert-success"><?= htmlspecialchars($success, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?></div>
      <div class="d-flex gap-2">
        <a class="btn btn-primary" href="<?= htmlspecialchars('../index.php', ENT_QUOTES) ?>">صفحه اصلی</a>
        <a class="btn btn-dark" href="<?= htmlspecialchars('../admin/auth.php', ENT_QUOTES) ?>">ورود مدیر</a>
      </div>
      <p class="text-muted small mt-3">پوشه install را حذف کنید.</p>
    <?php endif; ?>

    <form method="post" class="row g-3">
      <div class="col-12">
        <div class="card">
          <div class="card-body">
            <h6 class="mb-3">تنظیمات دیتابیس</h6>
            <div class="row g-3">
              <div class="col-md-6">
                <label class="form-label">DB Host</label>
                <input name="db_host" class="form-control" value="<?= htmlspecialchars($_POST['db_host'] ?? '127.0.0.1', ENT_QUOTES) ?>" required>
              </div>
              <div class="col-md-6">
                <label class="form-label">DB Name</label>
                <input name="db_name" class="form-control" value="<?= htmlspecialchars($_POST['db_name'] ?? 'dima_shop', ENT_QUOTES) ?>" required>
              </div>
              <div class="col-md-6">
                <label class="form-label">DB User</label>
                <input name="db_user" class="form-control" value="<?= htmlspecialchars($_POST['db_user'] ?? 'root', ENT_QUOTES) ?>" required>
              </div>
              <div class="col-md-6">
                <label class="form-label">DB Password</label>
                <input type="password" name="db_pass" class="form-control" value="<?= htmlspecialchars($_POST['db_pass'] ?? '', ENT_QUOTES) ?>">
              </div>
              <div class="col-12 form-check mt-2">
                <input type="checkbox" class="form-check-input" id="create_db" name="create_db" <?= isset($_POST['create_db']) ? 'checked' : '' ?>>
                <label class="form-check-label" for="create_db">ایجاد دیتابیس در صورت عدم وجود</label>
              </div>
              <div class="col-12 form-check">
                <input type="checkbox" class="form-check-input" id="run_seed" name="run_seed" <?= isset($_POST['run_seed']) ? 'checked' : '' ?>>
                <label class="form-check-label" for="run_seed">اجرای داده‌های نمونه (seed.sql)</label>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="col-12">
        <div class="card">
          <div class="card-body">
            <h6 class="mb-3">تنظیمات برنامه</h6>
            <div class="row g-3">
              <div class="col-md-6">
                <label class="form-label">Base URL</label>
                <input name="base_url" class="form-control" value="<?= htmlspecialchars($_POST['base_url'] ?? default_base_url(), ENT_QUOTES) ?>" required>
                <div class="form-text">مثال: / یا /dima-shop/</div>
              </div>
              <div class="col-md-6">
                <label class="form-label">APP_KEY</label>
                <input name="app_key" class="form-control" value="<?= htmlspecialchars($_POST['app_key'] ?? '', ENT_QUOTES) ?>" placeholder="خالی بگذارید تا ایجاد شود">
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="col-12">
        <div class="card">
          <div class="card-body">
            <h6 class="mb-3">مدیر سیستم</h6>
            <div class="row g-3">
              <div class="col-md-4">
                <label class="form-label">نام</label>
                <input name="admin_name" class="form-control" value="<?= htmlspecialchars($_POST['admin_name'] ?? 'Administrator', ENT_QUOTES) ?>" required>
              </div>
              <div class="col-md-4">
                <label class="form-label">ایمیل</label>
                <input type="email" name="admin_email" class="form-control" value="<?= htmlspecialchars($_POST['admin_email'] ?? 'admin@example.com', ENT_QUOTES) ?>" required>
              </div>
              <div class="col-md-4">
                <label class="form-label">رمز عبور</label>
                <input type="password" name="admin_pass" class="form-control" value="<?= htmlspecialchars($_POST['admin_pass'] ?? 'Admin@12345', ENT_QUOTES) ?>" required>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="col-12">
        <div class="card">
          <div class="card-body">
            <h6 class="mb-3">درگاه پرداخت (اختیاری - زرین‌پال)</h6>
            <div class="row g-3">
              <div class="col-md-8">
                <label class="form-label">Merchant ID</label>
                <input name="zarin_merchant" class="form-control" value="<?= htmlspecialchars($_POST['zarin_merchant'] ?? '', ENT_QUOTES) ?>" placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx">
              </div>
              <div class="col-md-4 form-check d-flex align-items-end">
                <input type="checkbox" class="form-check-input me-2" id="zarin_sandbox" name="zarin_sandbox" <?= isset($_POST['zarin_sandbox']) ? 'checked' : 'checked' ?>>
                <label class="form-check-label" for="zarin_sandbox">Sandbox (تستی)</label>
              </div>
            </div>
            <div class="form-text mt-2">می‌توانید بعداً در config.php هم تغییر دهید.</div>
          </div>
        </div>
      </div>

      <div class="col-12">
        <button class="btn btn-success">نصب</button>
      </div>
    </form>

  <?php endif; ?>

  <hr class="my-4">
  <div class="text-muted small">
    اگر پس از نصب با خطای دسترسی مواجه شدید، دسترسی نوشتن روی روت پروژه و فایل config.php را بررسی کنید.
  </div>
</div>
</body>
</html>
