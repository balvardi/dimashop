<?php require_once __DIR__ . '/../config.php'; ?>
<?php
if (current_user() && $_SESSION['user']['role']==='admin') { header('Location: index.php'); exit; }
$error = '';
if (is_post()) {
	verify_csrf();
	$email = trim($_POST['email'] ?? '');
	$password = (string)($_POST['password'] ?? '');
	$stmt = db()->prepare("SELECT * FROM users WHERE email=? AND role='admin' LIMIT 1");
	$stmt->execute([$email]);
	$user = $stmt->fetch();
	if ($user && password_verify($password, $user['password_hash'])) {
		$_SESSION['user'] = ['id'=>$user['id'],'name'=>$user['name'],'email'=>$user['email'],'role'=>$user['role']];
		header('Location: index.php');
		exit;
	} else {
		$error = 'ورود ناموفق';
	}
}
?>
<?php include __DIR__ . '/../includes/header.php'; ?>
<main class="container my-5 col-md-4 text-center mt-5 mb-5">
	<div class="brand-dima-shop" title="فروشگاه ساز دیما"></div> 
	<h2 class="h5 mb-3">ورود مدیر</h2>
	<h4 class="h5 mb-3 small">لطفا برای ورود از ایمیل و رمز عبور استفاده کنید.</h4>
	<?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
	<form method="post">
		<input type="hidden" name="_token" value="<?= e(csrf_token()) ?>">
		<div class="mb-3">
			<label class="form-label">ایمیل</label>
			<input type="email" name="email" class="form-control" required>
		</div>
		<div class="mb-3">
			<label class="form-label">رمز عبور</label>
			<input type="password" name="password" class="form-control" required>
		</div>
		<button class="btn btn-dark w-100">ورود</button>
	</form>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
