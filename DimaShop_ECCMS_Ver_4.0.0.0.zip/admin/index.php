<?php require_once __DIR__ . '/../config.php'; require_admin(); ?>
<?php
$pdo = db();
$section = $_GET['section'] ?? 'dashboard';

/* Stats for dashboard */
$stats = [
  'products' => (int)$pdo->query("SELECT COUNT(*) FROM products")->fetchColumn(),
  'orders' => (int)$pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn(),
  'users' => (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn(),
  'sales' => (float)$pdo->query("SELECT COALESCE(SUM(total),0) FROM orders WHERE status IN ('paid','shipped','completed')")->fetchColumn(),
];

/* Monthly sales (last 12 months) */
$monthly = $pdo->query("
  SELECT DATE_FORMAT(created_at, '%Y-%m') AS ym, SUM(total) AS s
  FROM orders
  WHERE status IN ('paid','shipped','completed')
  GROUP BY ym
  ORDER BY ym ASC
")->fetchAll();
$labels = array_map(fn($r) => $r['ym'], $monthly);
$values = array_map(fn($r) => (float)$r['s'], $monthly);

/* Top products by revenue */
$topProducts = $pdo->query("
  SELECT p.title, SUM(oi.qty * oi.unit_price) AS revenue
  FROM order_items oi
  JOIN products p ON p.id = oi.product_id
  JOIN orders o ON o.id = oi.order_id AND o.status IN ('paid','shipped','completed')
  GROUP BY p.id
  ORDER BY revenue DESC
  LIMIT 5
")->fetchAll();

/* Helper to print active class */
function active($s, $section) { return $s === $section ? 'active' : ''; }
?>
<?php include __DIR__ . '/../includes/header.php'; ?>

<link rel="stylesheet" href="<?= e(BASE_URL) ?>assets/admin.css">

<div class="admin">
  <div class="topbar">
    <div class="container py-2 d-flex align-items-center gap-3">
      <a href="<?= e(BASE_URL) ?>admin/index.php" class="fw-bold text-decoration-none">Dima Admin</a>
      <span class="badge badge-soft">v1.0</span>
      <div class="ms-auto d-flex align-items-center gap-3">
        <a class="small text-decoration-none" href="<?= e(BASE_URL) ?>" target="_blank">مشاهده سایت</a>
        <div class="dropdown">
          <a class="dropdown-toggle small text-decoration-none" href="#" data-bs-toggle="dropdown"><?= e($_SESSION['user']['name'] ?? 'Admin') ?></a>
          <ul class="dropdown-menu dropdown-menu-end">
            <li><a class="dropdown-item" href="<?= e(BASE_URL) ?>profile.php">پروفایل</a></li>
            <li><a class="dropdown-item" href="<?= e(BASE_URL) ?>auth/logout.php">خروج</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <div class="container">
    <div class="row">
      <aside class="col-lg-3 col-xl-2 sidebar py-3">
        <nav class="nav flex-column gap-1">
          <a class="nav-link <?= active('dashboard',$section) ?>" href="?section=dashboard">داشبورد</a>
          <a class="nav-link <?= active('orders',$section) ?>" href="?section=orders">سفارش‌ها</a>
          <a class="nav-link <?= active('products',$section) ?>" href="?section=products">محصولات</a>
          <a class="nav-link <?= active('categories',$section) ?>" href="?section=categories">دسته‌بندی‌ها</a>
          <a class="nav-link <?= active('attributes',$section) ?>" href="?section=attributes">ویژگی‌ها</a>
          <a class="nav-link <?= active('sliders',$section) ?>" href="?section=sliders">اسلایدر</a>
          <a class="nav-link <?= active('coupons',$section) ?>" href="?section=coupons">کوپن</a>
          <a class="nav-link <?= active('posts',$section) ?>" href="?section=posts">بلاگ</a>
        </nav>
      </aside>
      <main class="col-lg-9 col-xl-10 py-3">
        <?php if ($section === 'dashboard'): ?>
          <div class="row g-3">
            <div class="col-sm-6 col-xl-3">
              <div class="card p-3">
                <div class="metric">
                  <div class="label">محصولات</div>
                  <div class="value"><?= (int)$stats['products'] ?></div>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-xl-3">
              <div class="card p-3">
                <div class="metric">
                  <div class="label">سفارش‌ها</div>
                  <div class="value"><?= (int)$stats['orders'] ?></div>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-xl-3">
              <div class="card p-3">
                <div class="metric">
                  <div class="label">کاربران</div>
                  <div class="value"><?= (int)$stats['users'] ?></div>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-xl-3">
              <div class="card p-3">
                <div class="metric">
                  <div class="label">مجموع فروش (تومان)</div>
                  <div class="value"><?= e(money((float)$stats['sales'])) ?></div>
                </div>
              </div>
            </div>
          </div>
          <div class="row g-3 mt-1">
            <div class="col-lg-8">
              <div class="chart-wrap">
                <div class="d-flex align-items-center justify-content-between mb-2">
                  <div class="fw-semibold">روند فروش ۱۲ ماه اخیر</div>
                  <span class="badge badge-soft">real-time</span>
                </div>
                <canvas id="salesChart" height="120"></canvas>
              </div>
            </div>
            <div class="col-lg-4">
              <div class="card p-3 h-100">
                <div class="fw-semibold mb-2">پرفروش‌ترین محصولات</div>
                <table class="table table-sm mb-0">
                  <thead><tr><th>محصول</th><th class="text-end">فروش</th></tr></thead>
                  <tbody>
                  <?php foreach ($topProducts as $r): ?>
                    <tr>
                      <td class="small"><?= e($r['title']) ?></td>
                      <td class="small text-end"><?= e(money((float)$r['revenue'])) ?></td>
                    </tr>
                  <?php endforeach; if (!$topProducts): ?>
                    <tr><td colspan="2" class="small text-muted">داده‌ای نیست.</td></tr>
                  <?php endif; ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        <?php endif; ?>

        <?php if ($section === 'categories'): ?>
          <?php
          if (is_post()) {
            verify_csrf();
            if (isset($_POST['create'])) {
              $name = trim($_POST['name'] ?? '');
              $parent_id = $_POST['parent_id'] !== '' ? (int)$_POST['parent_id'] : null;
              $slug = slugify($name);
              $stmt = $pdo->prepare("INSERT INTO categories (parent_id,name,slug,is_active) VALUES (?,?,?,1)");
              $stmt->execute([$parent_id,$name,$slug]);
            }
          }
          $cats = $pdo->query("SELECT * FROM categories ORDER BY id DESC")->fetchAll();
          ?>
          <div class="row g-3">
            <div class="col-md-4">
              <div class="card p-3">
                <div class="fw-semibold mb-2">افزودن دسته</div>
                <form method="post" class="small">
                  <input type="hidden" name="_token" value="<?= e(csrf_token()) ?>">
                  <input type="hidden" name="create" value="1">
                  <div class="mb-2"><label class="form-label">نام</label><input name="name" class="form-control" required></div>
                  <div class="mb-2">
                    <label class="form-label">والد</label>
                    <select name="parent_id" class="form-select">
                      <option value="">—</option>
                      <?php foreach ($cats as $c): ?><option value="<?= (int)$c['id'] ?>"><?= e($c['name']) ?></option><?php endforeach; ?>
                    </select>
                  </div>
                  <button class="btn btn-brand btn-sm">افزودن</button>
                </form>
              </div>
            </div>
            <div class="col-md-8">
              <div class="card p-3">
                <div class="fw-semibold mb-2">لیست دسته‌ها</div>
                <div class="table-responsive">
                  <table class="table table-sm align-middle mb-0">
                    <thead><tr><th>ID</th><th>نام</th><th>وضعیت</th></tr></thead>
                    <tbody>
                    <?php foreach ($cats as $c): ?>
                      <tr><td><?= (int)$c['id'] ?></td><td><?= e($c['name']) ?></td><td><?= $c['is_active'] ? 'فعال' : 'غیرفعال' ?></td></tr>
                    <?php endforeach; ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        <?php endif; ?>

        <?php if ($section === 'attributes'): ?>
          <?php
          if (is_post()) {
            verify_csrf();
            if (isset($_POST['create_attr'])) {
              $name = trim($_POST['name'] ?? '');
              if ($name) $pdo->prepare("INSERT INTO attributes (name) VALUES (?)")->execute([$name]);
            }
            if (isset($_POST['create_val'])) {
              $attribute_id = (int)$_POST['attribute_id'];
              $value = trim($_POST['value'] ?? '');
              $modifier_type = $_POST['modifier_type'] === 'percent' ? 'percent' : 'flat';
              $modifier_value = (float)$_POST['modifier_value'];
              $pdo->prepare("INSERT INTO attribute_values (attribute_id,value,modifier_type,modifier_value) VALUES (?,?,?,?)")
                  ->execute([$attribute_id,$value,$modifier_type,$modifier_value]);
            }
          }
          $attrs = $pdo->query("SELECT * FROM attributes ORDER BY id DESC")->fetchAll();
          $vals = $pdo->query("SELECT av.*, a.name as attr_name FROM attribute_values av JOIN attributes a ON a.id=av.attribute_id ORDER BY av.id DESC")->fetchAll();
          ?>
          <div class="row g-3">
            <div class="col-md-4">
              <div class="card p-3">
                <div class="fw-semibold mb-2">افزودن ویژگی</div>
                <form method="post" class="small">
                  <input type="hidden" name="_token" value="<?= e(csrf_token()) ?>">
                  <input type="hidden" name="create_attr" value="1">
                  <div class="mb-2"><label class="form-label">نام</label><input name="name" class="form-control" required></div>
                  <button class="btn btn-brand btn-sm">افزودن</button>
                </form>
              </div>
            </div>
            <div class="col-md-8">
              <div class="card p-3">
                <div class="fw-semibold mb-2">افزودن مقدار ویژگی</div>
                <form method="post" class="row g-2 small">
                  <input type="hidden" name="_token" value="<?= e(csrf_token()) ?>">
                  <input type="hidden" name="create_val" value="1">
                  <div class="col-md-3">
                    <label class="form-label">ویژگی</label>
                    <select name="attribute_id" class="form-select">
                      <?php foreach ($attrs as $a): ?><option value="<?= (int)$a['id'] ?>"><?= e($a['name']) ?></option><?php endforeach; ?>
                    </select>
                  </div>
                  <div class="col-md-3"><label class="form-label">مقدار</label><input name="value" class="form-control" required></div>
                  <div class="col-md-3">
                    <label class="form-label">نوع تعدیل</label>
                    <select name="modifier_type" class="form-select">
                      <option value="flat">ثابت</option>
                      <option value="percent">درصد</option>
                    </select>
                  </div>
                  <div class="col-md-3"><label class="form-label">مقدار</label><input name="modifier_value" type="number" step="0.01" class="form-control" value="0"></div>
                  <div class="col-12"><button class="btn btn-brand btn-sm">افزودن مقدار</button></div>
                </form>
                <hr>
                <div class="table-responsive">
                  <table class="table table-sm align-middle mb-0">
                    <thead><tr><th>ID</th><th>ویژگی</th><th>مقدار</th><th>تعدیل</th></tr></thead>
                    <tbody>
                    <?php foreach ($vals as $v): ?>
                      <tr><td><?= (int)$v['id'] ?></td><td><?= e($v['attr_name']) ?></td><td><?= e($v['value']) ?></td><td><?= e($v['modifier_type']) ?>: <?= e($v['modifier_value']) ?></td></tr>
                    <?php endforeach; ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        <?php endif; ?>

        <?php if ($section === 'products'): ?>
          <?php
          if (is_post()) {
            verify_csrf();
            if (isset($_POST['create_product'])) {
              $title = trim($_POST['title'] ?? '');
              $price = (float)($_POST['price'] ?? 0);
              $stock = (int)($_POST['stock'] ?? 0);
              $category_id = $_POST['category_id'] !== '' ? (int)$_POST['category_id'] : null;
              $brand_id = $_POST['brand_id'] !== '' ? (int)$_POST['brand_id'] : null;
              $slug = slugify($title);
              $desc = trim($_POST['description'] ?? '');
              $stmt = $pdo->prepare("INSERT INTO products (title,slug,price,stock,category_id,brand_id,description,is_active) VALUES (?,?,?,?,?,?,?,1)");
              $stmt->execute([$title,$slug,$price,$stock,$category_id,$brand_id,$desc]);
            }
            if (isset($_POST['link_attr'])) {
              $product_id = (int)$_POST['product_id'];
              $value_id = (int)$_POST['value_id'];
              $pdo->prepare("INSERT IGNORE INTO product_attribute_values (product_id, attribute_value_id) VALUES (?,?)")->execute([$product_id,$value_id]);
            }
          }
          $cats = $pdo->query("SELECT * FROM categories ORDER BY name ASC")->fetchAll();
          $brands = $pdo->query("SELECT * FROM brands ORDER BY name ASC")->fetchAll();
          $prods = $pdo->query("SELECT * FROM products ORDER BY id DESC LIMIT 100")->fetchAll();
          $attrVals = $pdo->query("SELECT av.id, CONCAT(a.name,' - ',av.value) as label FROM attribute_values av JOIN attributes a ON a.id=av.attribute_id ORDER BY av.id DESC")->fetchAll();
          ?>
          <div class="row g-3">
            <div class="col-lg-5">
              <div class="card p-3">
                <div class="fw-semibold mb-2">افزودن محصول</div>
                <form method="post" class="small">
                  <input type="hidden" name="_token" value="<?= e(csrf_token()) ?>">
                  <input type="hidden" name="create_product" value="1">
                  <div class="mb-2"><label class="form-label">عنوان</label><input name="title" class="form-control" required></div>
                  <div class="mb-2"><label class="form-label">قیمت</label><input name="price" type="number" step="0.01" class="form-control" required></div>
                  <div class="mb-2"><label class="form-label">موجودی</label><input name="stock" type="number" class="form-control" required></div>
                  <div class="mb-2">
                    <label class="form-label">دسته</label>
                    <select name="category_id" class="form-select">
                      <option value="">—</option>
                      <?php foreach ($cats as $c): ?><option value="<?= (int)$c['id'] ?>"><?= e($c['name']) ?></option><?php endforeach; ?>
                    </select>
                  </div>
                  <div class="mb-2">
                    <label class="form-label">برند</label>
                    <select name="brand_id" class="form-select">
                      <option value="">—</option>
                      <?php foreach ($brands as $b): ?><option value="<?= (int)$b['id'] ?>"><?= e($b['name']) ?></option><?php endforeach; ?>
                    </select>
                  </div>
                  <div class="mb-2"><label class="form-label">توضیحات</label><textarea name="description" class="form-control" rows="3"></textarea></div>
                  <button class="btn btn-brand btn-sm">ذخیره</button>
                </form>
              </div>
            </div>
            <div class="col-lg-7">
              <div class="card p-3">
                <div class="fw-semibold mb-2">محصولات</div>
                <div class="table-responsive">
                  <table class="table table-sm align-middle mb-0">
                    <thead><tr><th>ID</th><th>عنوان</th><th>قیمت</th><th>موجودی</th><th>تصاویر</th><th>ویژگی‌ها</th></tr></thead>
                    <tbody>
                    <?php foreach ($prods as $p): ?>
                      <tr>
                        <td><?= (int)$p['id'] ?></td>
                        <td><a href="../product.php?slug=<?= e($p['slug']) ?>" target="_blank"><?= e($p['title']) ?></a></td>
                        <td><?= e(money((float)$p['price'])) ?></td>
                        <td><?= (int)$p['stock'] ?></td>
                        <td>
                          <form class="d-flex gap-2 align-items-center" action="../api/upload.php" method="post" enctype="multipart/form-data" onsubmit="return uploadImg(this, <?= (int)$p['id'] ?>);">
                            <input type="hidden" name="_token" value="<?= e(csrf_token()) ?>">
                            <input type="file" name="file" class="form-control form-control-sm" required>
                            <button class="btn btn-sm btn-outline-secondary">آپلود</button>
                          </form>
                        </td>
                        <td>
                          <form method="post" class="d-flex gap-2">
                            <input type="hidden" name="_token" value="<?= e(csrf_token()) ?>">
                            <input type="hidden" name="link_attr" value="1">
                            <input type="hidden" name="product_id" value="<?= (int)$p['id'] ?>">
                            <select name="value_id" class="form-select form-select-sm" style="width:200px">
                              <?php foreach ($attrVals as $av): ?><option value="<?= (int)$av['id'] ?>"><?= e($av['label']) ?></option><?php endforeach; ?>
                            </select>
                            <button class="btn btn-sm btn-outline-primary">افزودن</button>
                          </form>
                        </td>
                      </tr>
                    <?php endforeach; ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>

          <script>
            function uploadImg(form, productId) {
              const data = new FormData(form);
              fetch('../api/upload.php', { method: 'POST', body: data, headers: { 'X-CSRF-Token': '<?= e(csrf_token()) ?>' } })
                .then(r => r.json()).then(async res => {
                  if (res.ok) {
                    await fetch('save-image.php', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                      body: '_token=' + encodeURIComponent('<?= e(csrf_token()) ?>') + '&product_id=' + productId + '&url=' + encodeURIComponent(res.url)
                    });
                    location.reload();
                  } else { alert(res.message || 'خطا'); }
                });
              return false;
            }
          </script>
        <?php endif; ?>

        <?php if ($section === 'sliders'): ?>
          <?php
          if (is_post()) {
            verify_csrf();
            if (isset($_POST['create_slider'])) {
              $title = trim($_POST['title'] ?? '');
              $image_url = trim($_POST['image_url'] ?? '');
              $link_url = trim($_POST['link_url'] ?? '');
              $sort_order = (int)($_POST['sort_order'] ?? 0);
              $pdo->prepare("INSERT INTO sliders (title,image_url,link_url,sort_order,is_active) VALUES (?,?,?,?,1)")
                  ->execute([$title,$image_url,$link_url,$sort_order]);
            }
          }
          $sl = $pdo->query("SELECT * FROM sliders ORDER BY sort_order ASC, id DESC")->fetchAll();
          ?>
          <div class="row g-3">
            <div class="col-md-5">
              <div class="card p-3">
                <div class="fw-semibold mb-2">افزودن اسلاید</div>
                <form method="post" class="small">
                  <input type="hidden" name="_token" value="<?= e(csrf_token()) ?>">
                  <input type="hidden" name="create_slider" value="1">
                  <div class="mb-2"><label class="form-label">عنوان</label><input name="title" class="form-control"></div>
                  <div class="mb-2"><label class="form-label">تصویر (URL)</label><input name="image_url" class="form-control" placeholder="uploads/..."></div>
                  <div class="mb-2"><label class="form-label">لینک</label><input name="link_url" class="form-control" placeholder="index.php"></div>
                  <div class="mb-2"><label class="form-label">ترتیب</label><input name="sort_order" type="number" class="form-control" value="0"></div>
                  <button class="btn btn-brand btn-sm">ذخیره</button>
                </form>
              </div>
            </div>
            <div class="col-md-7">
              <div class="card p-3">
                <div class="fw-semibold mb-2">اسلایدها</div>
                <div class="table-responsive">
                  <table class="table table-sm mb-0"><thead><tr><th>ID</th><th>عنوان</th><th>تصویر</th></tr></thead><tbody>
                  <?php foreach ($sl as $s): ?>
                    <tr><td><?= (int)$s['id'] ?></td><td><?= e($s['title']) ?></td><td><img src="../<?= e($s['image_url']) ?>" style="height:40px"></td></tr>
                  <?php endforeach; ?>
                  </tbody></table>
                </div>
              </div>
            </div>
          </div>
        <?php endif; ?>

        <?php if ($section === 'coupons'): ?>
          <?php
          if (is_post()) {
            verify_csrf();
            $code = strtoupper(trim($_POST['code'] ?? ''));
            $type = $_POST['type'] === 'percent' ? 'percent' : 'fixed';
            $amount = (float)($_POST['amount'] ?? 0);
            $min_order_value = $_POST['min_order_value'] !== '' ? (float)$_POST['min_order_value'] : null;
            $expires_at = $_POST['expires_at'] !== '' ? $_POST['expires_at'] : null;
            $pdo->prepare("INSERT INTO coupons (code,type,amount,min_order_value,expires_at,is_active) VALUES (?,?,?,?,?,1)")
                ->execute([$code,$type,$amount,$min_order_value,$expires_at]);
          }
          $cps = $pdo->query("SELECT * FROM coupons ORDER BY id DESC")->fetchAll();
          ?>
          <div class="row g-3">
            <div class="col-md-5">
              <div class="card p-3">
                <div class="fw-semibold mb-2">ایجاد کوپن</div>
                <form method="post" class="small">
                  <input type="hidden" name="_token" value="<?= e(csrf_token()) ?>">
                  <div class="mb-2"><label class="form-label">کد</label><input name="code" class="form-control" required></div>
                  <div class="mb-2">
                    <label class="form-label">نوع</label>
                    <select name="type" class="form-select">
                      <option value="fixed">مبلغ ثابت</option>
                      <option value="percent">درصد</option>
                    </select>
                  </div>
                  <div class="mb-2"><label class="form-label">مقدار</label><input name="amount" type="number" step="0.01" class="form-control" required></div>
                  <div class="mb-2"><label class="form-label">حداقل سفارش</label><input name="min_order_value" type="number" step="0.01" class="form-control"></div>
                  <div class="mb-2"><label class="form-label">انقضا</label><input name="expires_at" type="datetime-local" class="form-control"></div>
                  <button class="btn btn-brand btn-sm">ذخیره</button>
                </form>
              </div>
            </div>
            <div class="col-md-7">
              <div class="card p-3">
                <div class="fw-semibold mb-2">کوپن‌ها</div>
                <div class="table-responsive">
                  <table class="table table-sm mb-0">
                    <thead><tr><th>کد</th><th>نوع</th><th>مقدار</th><th>استفاده شده</th></tr></thead>
                    <tbody>
                    <?php foreach ($cps as $c): ?>
                      <tr><td><?= e($c['code']) ?></td><td><?= e($c['type']) ?></td><td><?= e($c['amount']) ?></td><td><?= (int)$c['used_count'] ?></td></tr>
                    <?php endforeach; ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        <?php endif; ?>

        <?php if ($section === 'posts'): ?>
          <?php
          if (is_post()) {
            verify_csrf();
            $title = trim($_POST['title'] ?? '');
            $slug = slugify($title);
            $content = trim($_POST['content'] ?? '');
            $pdo->prepare("INSERT INTO posts (title,slug,content,is_published) VALUES (?,?,?,1)")
                ->execute([$title,$slug,$content]);
          }
          $posts = $pdo->query("SELECT * FROM posts ORDER BY id DESC")->fetchAll();
          ?>
          <div class="row g-3">
            <div class="col-md-5">
              <div class="card p-3">
                <div class="fw-semibold mb-2">پست جدید</div>
                <form method="post" class="small">
                  <input type="hidden" name="_token" value="<?= e(csrf_token()) ?>">
                  <div class="mb-2"><label class="form-label">عنوان</label><input name="title" class="form-control" required></div>
                  <div class="mb-2"><label class="form-label">محتوا</label><textarea name="content" class="form-control" rows="6" required></textarea></div>
                  <button class="btn btn-brand btn-sm">انتشار</button>
                </form>
              </div>
            </div>
            <div class="col-md-7">
              <div class="card p-3">
                <div class="fw-semibold mb-2">پست‌ها</div>
                <ul class="list-group list-group-flush">
                  <?php foreach ($posts as $p): ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center bg-transparent">
                      <a href="../post.php?slug=<?= e($p['slug']) ?>" target="_blank" class="text-decoration-none"><?= e($p['title']) ?></a>
                      <span class="badge badge-soft"><?= $p['is_published'] ? 'منتشر' : 'پیش‌نویس' ?></span>
                    </li>
                  <?php endforeach; ?>
                </ul>
              </div>
            </div>
          </div>
        <?php endif; ?>

        <?php if ($section === 'orders'): ?>
          <?php $orders = $pdo->query("SELECT * FROM orders ORDER BY id DESC LIMIT 100")->fetchAll(); ?>
          <div class="card p-3">
            <div class="fw-semibold mb-2">سفارش‌ها</div>
            <div class="table-responsive">
              <table class="table table-sm align-middle mb-0">
                <thead><tr><th>ID</th><th>وضعیت</th><th>مبلغ</th><th>کوپن</th><th>تاریخ</th></tr></thead>
                <tbody>
                <?php foreach ($orders as $o): ?>
                  <tr>
                    <td><?= (int)$o['id'] ?></td>
                    <td><?= e($o['status']) ?></td>
                    <td><?= e(money((float)$o['total'])) ?> تومان</td>
                    <td><?= e($o['coupon_code'] ?? '-') ?></td>
                    <td><?= e($o['created_at']) ?></td>
                  </tr>
                <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          </div>
        <?php endif; ?>
      </main>
    </div>
  </div>
</div>
<script src="../assets/js/chart.umd.min.js" crossorigin="anonymous"></script>
<script>
  (function(){
    const el = document.getElementById('salesChart');
    if (!el) return;
    const labels = <?= json_encode($labels, JSON_UNESCAPED_UNICODE) ?>;
    const data = <?= json_encode($values, JSON_UNESCAPED_UNICODE) ?>;
    const ctx = el.getContext('2d');
    new Chart(ctx, {
      type: 'line',
      data: {
        labels,
        datasets: [{
          label: 'فروش (تومان)',
          data,
          borderColor: '#16a34a',
          backgroundColor: 'rgba(22,163,74,.15)',
          tension: .35,
          fill: true,
          pointRadius: 2
        }]
      },
      options: {
        plugins: { legend: { display: false } },
        scales: {
          x: { ticks: { color: '#9ca3af' }, grid: { color: 'rgba(148,163,184,.15)' } },
          y: { ticks: { color: '#9ca3af' }, grid: { color: 'rgba(148,163,184,.15)' } }
        }
      }
    });
  })();
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
