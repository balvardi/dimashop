<?php
require_once __DIR__ . '/../config.php';
require_admin();
verify_csrf();
$product_id = (int)($_POST['product_id'] ?? 0);
$url = trim($_POST['url'] ?? '');
if ($product_id && $url !== '') {
  db()->prepare("INSERT INTO product_images (product_id, image_url, sort_order) VALUES (?,?,0)")
     ->execute([$product_id,$url]);
}
header('Location: index.php?section=products');
exit;
