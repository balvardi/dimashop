<?php
require_once __DIR__ . '/../config.php';
header('Content-Type: application/json; charset=utf-8');

$action = $_GET['action'] ?? '';
if (!in_array($action, ['apply','remove'], true)) json_response(['ok'=>false], 400);

if ($action === 'apply') {
  verify_csrf();
  $code = strtoupper(trim($_POST['code'] ?? ''));
  if ($code === '') json_response(['ok'=>false,'message'=>'کد لازم است'], 422);

  $stmt = db()->prepare("SELECT * FROM coupons WHERE code=? AND is_active=1 LIMIT 1");
  $stmt->execute([$code]);
  $c = $stmt->fetch();
  if (!$c) json_response(['ok'=>false,'message'=>'کد معتبر نیست'], 404);

  if (!empty($c['expires_at']) && strtotime($c['expires_at']) < time()) {
    json_response(['ok'=>false,'message'=>'کد منقضی شده است'], 422);
  }
  if ($c['max_uses'] !== null && (int)$c['used_count'] >= (int)$c['max_uses']) {
    json_response(['ok'=>false,'message'=>'محدودیت استفاده تکمیل شده است'], 422);
  }
  $tot = cart_totals();
  if ($c['min_order_value'] !== null && $tot['subtotal'] < (float)$c['min_order_value']) {
    json_response(['ok'=>false,'message'=>'حداقل مبلغ سفارش رعایت نشده است'], 422);
  }

  $_SESSION['cart']['coupon'] = [
    'code' => $c['code'],
    'type' => $c['type'],
    'amount' => (float)$c['amount']
  ];
  json_response(['ok'=>true]);
}

if ($action === 'remove') {
  verify_csrf();
  $_SESSION['cart']['coupon'] = null;
  json_response(['ok'=>true]);
}
