<?php
require_once __DIR__ . '/../config.php';
header('Content-Type: application/json; charset=utf-8');
$q = trim($_GET['q'] ?? '');
if ($q === '') json_response(['items'=>[]]);
$stmt = db()->prepare("SELECT id,title,slug FROM products WHERE is_active=1 AND title LIKE ? ORDER BY id DESC LIMIT 10");
$stmt->execute(["%$q%"]);
json_response(['items'=>$stmt->fetchAll()]);
