<?php
require_once __DIR__ . '/../config.php';
require_admin();
verify_csrf();

if (!isset($_FILES['file'])) {
  json_response(['ok'=>false,'message'=>'فایل ارسال نشد'], 400);
}
$f = $_FILES['file'];
if ($f['error'] !== UPLOAD_ERR_OK) json_response(['ok'=>false,'message'=>'خطا در آپلود'], 400);

$ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
$allowed = ['jpg','jpeg','png','webp'];
if (!in_array($ext, $allowed, true)) json_response(['ok'=>false,'message'=>'فرمت نامعتبر'], 422);

if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0775, true);

$filename = uniqid('img_', true) . '.' . $ext;
$path = UPLOAD_DIR . '/' . $filename;
if (!move_uploaded_file($f['tmp_name'], $path)) {
  json_response(['ok'=>false,'message'=>'عدم امکان ذخیره فایل'], 500);
}

json_response(['ok'=>true,'url'=>'uploads/' . $filename]);
