<?php
require_once __DIR__ . '/../config.php';
header('Content-Type: application/json; charset=utf-8');
cart_init();

$action = $_GET['action'] ?? '';
if (!in_array($action, ['add','update','remove','clear'], true)) {
  json_response(['ok'=>false,'message'=>'invalid action'], 400);
}

if ($action !== 'clear') verify_csrf();

if ($action === 'add') {
  $product_id = (int)($_POST['product_id'] ?? 0);
  $qty = max(1, (int)($_POST['qty'] ?? 1));
  $attr = $_POST['attr'] ?? [];

  $stmt = db()->prepare("SELECT id,title,price,stock FROM products WHERE id=? AND is_active=1 LIMIT 1");
  $stmt->execute([$product_id]);
  $p = $stmt->fetch();
  if (!$p) json_response(['ok'=>false,'message'=>'محصول معتبر نیست'], 404);

  $attrNames = [];
  $finalPrice = (float)$p['price'];
  if (!empty($attr)) {
    $placeholders = implode(',', array_fill(0, count($attr), '?'));
    $vals = array_values($attr);
    $q = db()->prepare("
      SELECT a.name as attr_name, av.id, av.value, av.modifier_type, av.modifier_value
      FROM attribute_values av
      JOIN attributes a ON a.id = av.attribute_id
      WHERE av.id IN ($placeholders)
    ");
    $q->execute($vals);
    $found = $q->fetchAll();
    $foundIds = array_column($found, 'id');

    $allowed = db()->prepare("
      SELECT COUNT(*) FROM product_attribute_values WHERE product_id=? AND attribute_value_id IN ($placeholders)
    ");
    $allowed->execute(array_merge([$product_id], $vals));
    $cnt = (int)$allowed->fetchColumn();
    if ($cnt !== count($vals)) json_response(['ok'=>false,'message'=>'گزینه نامعتبر'], 422);

    foreach ($found as $f) {
      $attrNames[$f['attr_name']] = $f['value'];
      if ($f['modifier_type'] === 'flat') $finalPrice += (float)$f['modifier_value'];
      else $finalPrice += (float)$p['price'] * ((float)$f['modifier_value'] / 100.0);
    }
  }

  $key = cart_key($p['id'], $attrNames);
  if (!isset($_SESSION['cart']['items'][$key])) {
    $_SESSION['cart']['items'][$key] = [
      'product_id' => $p['id'],
      'title' => $p['title'],
      'price' => $finalPrice,
      'qty' => 0,
      'attributes' => $attrNames
    ];
  }
  $_SESSION['cart']['items'][$key]['qty'] += $qty;

  $count = array_sum(array_column($_SESSION['cart']['items'], 'qty'));
  json_response(['ok'=>true,'cart_count'=>$count]);
}

if ($action === 'update') {
  verify_csrf();
  $key = $_POST['key'] ?? '';
  $qty = max(1, (int)($_POST['qty'] ?? 1));
  if (isset($_SESSION['cart']['items'][$key])) {
    $_SESSION['cart']['items'][$key]['qty'] = $qty;
  }
  json_response(['ok'=>true]);
}

if ($action === 'remove') {
  verify_csrf();
  $key = $_POST['key'] ?? '';
  unset($_SESSION['cart']['items'][$key]);
  json_response(['ok'=>true]);
}

if ($action === 'clear') {
  $_SESSION['cart'] = ['items'=>[],'coupon'=>null];
  json_response(['ok'=>true]);
}
