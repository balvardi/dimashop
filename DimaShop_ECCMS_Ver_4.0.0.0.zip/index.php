<?php require_once __DIR__ . '/config.php'; ?>
<?php include __DIR__ . '/includes/header.php'; ?>
<?php include __DIR__ . '/includes/navbar.php'; ?>

<main class="container my-4">
  <?php
  $pdo = db();
  $sliders = $pdo->query("SELECT * FROM sliders WHERE is_active=1 ORDER BY sort_order ASC, id DESC")->fetchAll();

  $q = $_GET['q'] ?? '';
  if ($q !== '') {
    $stmt = $pdo->prepare("SELECT * FROM products WHERE is_active=1 AND title LIKE :q ORDER BY id DESC LIMIT 24");
    $stmt->execute([':q' => "%$q%"]);
  } else {
    $stmt = $pdo->query("SELECT * FROM products WHERE is_active=1 ORDER BY id DESC LIMIT 24");
  }
  $products = $stmt->fetchAll();

  $cats = $pdo->query("SELECT * FROM categories WHERE is_active=1 ORDER BY id DESC LIMIT 12")->fetchAll();
  ?>

  <?php if ($sliders): ?>
    <div id="mainSlider" class="carousel slide mb-4" data-bs-ride="carousel">
      <div class="carousel-inner rounded-3 overflow-hidden">
        <?php foreach ($sliders as $i => $s): ?>
          <div class="carousel-item <?= $i === 0 ? 'active' : '' ?>">
            <?php if (!empty($s['link_url'])): ?>
              <a href="<?= e($s['link_url']) ?>"><img src="<?= e($s['image_url']) ?>" class="d-block w-100" alt="<?= e($s['title'] ?? '') ?>"></a>
            <?php else: ?>
              <img src="<?= e($s['image_url']) ?>" class="d-block w-100" alt="<?= e($s['title'] ?? '') ?>">
            <?php endif; ?>
          </div>
        <?php endforeach; ?>
      </div>
      <button class="carousel-control-prev" type="button" data-bs-target="#mainSlider" data-bs-slide="prev"><span class="carousel-control-prev-icon"></span></button>
      <button class="carousel-control-next" type="button" data-bs-target="#mainSlider" data-bs-slide="next"><span class="carousel-control-next-icon"></span></button>
    </div>
  <?php endif; ?>

  <section class="mb-4">
    <h5 class="mb-3">دسته‌بندی‌ها</h5>
    <div class="row g-3">
      <?php foreach ($cats as $c): ?>
        <div class="col-6 col-md-3 col-lg-2">
          <a href="index.php?category=<?= (int)$c['id'] ?>" class="card text-decoration-none">
            <div class="card-body text-center">
              <div class="fw-semibold"><?= e($c['name']) ?></div>
            </div>
          </a>
        </div>
      <?php endforeach; ?>
    </div>
  </section>

  <section>
    <div class="d-flex align-items-center justify-content-between mb-2">
      <h5 class="mb-0"><?= $q !== '' ? 'نتایج جستجو' : 'جدیدترین محصولات' ?></h5>
      <?php if ($q !== ''): ?><small class="text-muted">جستجو برای: <?= e($q) ?></small><?php endif; ?>
    </div>
    <div class="row g-3">
      <?php foreach ($products as $p): 
        $img = db()->prepare("SELECT image_url FROM product_images WHERE product_id=? ORDER BY sort_order ASC, id ASC LIMIT 1");
        $img->execute([$p['id']]);
        $img = $img->fetchColumn() ?: 'https://via.placeholder.com/600x400?text=Product';
      ?>
        <div class="col-6 col-md-3 col-lg-2">
          <div class="card h-100">
            <a href="product.php?slug=<?= e($p['slug']) ?>"><img src="<?= e($img) ?>" class="card-img-top" alt="<?= e($p['title']) ?>"></a>
            <div class="card-body d-flex flex-column">
              <div class="small text-muted mb-1"><?= e($p['sku'] ?? '') ?></div>
              <a href="product.php?slug=<?= e($p['slug']) ?>" class="text-decoration-none fw-semibold mb-2"><?= e($p['title']) ?></a>
              <div class="mt-auto fw-bold"><?= e(money((float)$p['price'])) ?> تومان</div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
      <?php if (!$products): ?>
        <div class="col-12"><div class="alert alert-info">محصولی یافت نشد.</div></div>
      <?php endif; ?>
    </div>
  </section>
</main>

<?php include __DIR__ . '/includes/footer.php'; ?>
