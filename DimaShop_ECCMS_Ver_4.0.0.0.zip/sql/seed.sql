-- Seed admin user (password: Admin@12345)
INSERT INTO users (name, email, password_hash, role)
VALUES ('Administrator', 'admin@example.com', 
  '$2y$10$zA4oD5sU3KQ2Q0F/6m1kUuB2ac1oXh1dU7lT4m0qE3Q7XoM1mZrC2', 'admin');

INSERT INTO categories (name, slug) VALUES
('موبایل', 'mobile'),
('لپ‌تاپ', 'laptop'),
('هدفون', 'headphone');

INSERT INTO brands (name, slug) VALUES
('Dima', 'dima'),
('TechPro', 'techpro');

INSERT INTO products (title, slug, sku, description, price, stock, category_id, brand_id, is_active)
VALUES
('گوشی هوشمند Dima X1', 'dima-x1', 'DX1-001', 'توضیحات گوشی...', 12000000, 50, 1, 1, 1),
('لپ‌تاپ TechPro 15', 'techpro-15', 'TP15-001', 'توضیحات لپ‌تاپ...', 38000000, 20, 2, 2, 1);

INSERT INTO product_images (product_id, image_url, sort_order) VALUES
(1, 'uploads/dima-x1.jpg', 0),
(2, 'uploads/techpro-15.jpg', 0);

INSERT INTO attributes (name) VALUES ('رنگ'), ('حافظه');

INSERT INTO attribute_values (attribute_id, value, modifier_type, modifier_value) VALUES
(1, 'مشکی', 'flat', 0),
(1, 'آبی', 'flat', 200000),
(2, '64GB', 'flat', 0),
(2, '128GB', 'flat', 800000);

INSERT INTO product_attribute_values (product_id, attribute_value_id) VALUES
(1, 1),(1,2),(1,3),(1,4);

INSERT INTO sliders (title, image_url, link_url, sort_order, is_active)
VALUES ('حراج ویژه تابستان', 'uploads/slider-1.jpg', 'index.php', 0, 1);

INSERT INTO posts (title, slug, content) VALUES
('اولین پست وبلاگ', 'first-post', 'این یک پست نمونه است.');
