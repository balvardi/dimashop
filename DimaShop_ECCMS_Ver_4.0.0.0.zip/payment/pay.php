<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../lib/gateway-zarinpal.php';
require_login();

$order_id = (int)($_GET['id'] ?? 0);
if ($order_id <= 0) { http_response_code(400); exit('order id required'); }

$pdo = db();
$order = $pdo->prepare("SELECT * FROM orders WHERE id=? AND user_id=? LIMIT 1");
$order->execute([$order_id, $_SESSION['user']['id']]);
$order = $order->fetch();

if (!$order || $order['status'] !== 'pending') {
  http_response_code(404);
  exit('سفارش معتبر نیست یا وضعیت نامعتبر است.');
}

$pay = $pdo->prepare("SELECT * FROM payments WHERE order_id=? ORDER BY id DESC LIMIT 1");
$pay->execute([$order_id]);
$payment = $pay->fetch();

if (!$payment) {
  $pdo->prepare("INSERT INTO payments (order_id, gateway, amount, status) VALUES (?,?,?, 'initiated')")
      ->execute([$order_id, 'zarinpal', $order['total']]);
  $payment_id = (int)$pdo->lastInsertId();
} else {
  $payment_id = (int)$payment['id'];
}

$callback = app_base_url() . '/payment/callback.php';
$desc = 'پرداخت سفارش #' . $order_id;
$req = zarinpal_request($order_id, (float)$order['total'], $desc, $callback);

if (!$req['ok']) { exit('عدم امکان اتصال به درگاه'); }

$pdo->prepare("UPDATE payments SET authority=?, raw_request=? WHERE id=?")
    ->execute([$req['authority'], $req['raw'] ?? null, $payment_id]);

header('Location: ' . $req['startpay_url']);
exit;
