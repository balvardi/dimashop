<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../lib/gateway-zarinpal.php';

$authority = $_GET['Authority'] ?? $_GET['authority'] ?? '';
$status = $_GET['Status'] ?? $_GET['status'] ?? '';

$pdo = db();

if ($authority === '') {
  include __DIR__ . '/../includes/header.php';
  include __DIR__ . '/../includes/navbar.php';
  echo '<main class="container my-5"><div class="alert alert-danger">پارامتر Authority موجود نیست.</div></main>';
  include __DIR__ . '/../includes/footer.php';
  exit;
}

$payStmt = $pdo->prepare("SELECT * FROM payments WHERE authority=? LIMIT 1");
$payStmt->execute([$authority]);
$payment = $payStmt->fetch();

if (!$payment) {
  include __DIR__ . '/../includes/header.php';
  include __DIR__ . '/../includes/navbar.php';
  echo '<main class="container my-5"><div class="alert alert-danger">پرداخت یافت نشد.</div></main>';
  include __DIR__ . '/../includes/footer.php';
  exit;
}

$orderStmt = $pdo->prepare("SELECT * FROM orders WHERE id=? LIMIT 1");
$orderStmt->execute([(int)$payment['order_id']]);
$order = $orderStmt->fetch();

if (!$order) {
  include __DIR__ . '/../includes/header.php';
  include __DIR__ . '/../includes/navbar.php';
  echo '<main class="container my-5"><div class="alert alert-danger">سفارش یافت نشد.</div></main>';
  include __DIR__ . '/../includes/footer.php';
  exit;
}

if (strtoupper((string)$status) !== 'OK') {
  $pdo->prepare("UPDATE payments SET status='cancelled', raw_response=? WHERE id=?")
      ->execute([json_encode(['status'=>$status], JSON_UNESCAPED_UNICODE), (int)$payment['id']]);
  include __DIR__ . '/../includes/header.php';
  include __DIR__ . '/../includes/navbar.php';
  echo '<main class="container my-5"><div class="alert alert-warning">پرداخت توسط کاربر لغو شد.</div><a class="btn btn-outline-primary mt-3" href="../checkout.php">بازگشت</a></main>';
  include __DIR__ . '/../includes/footer.php';
  exit;
}

$vr = zarinpal_verify($authority, (float)$payment['amount']);

if (!$vr['ok']) {
  $pdo->prepare("UPDATE payments SET status='failed', raw_response=? WHERE id=?")
      ->execute([$vr['raw'] ?? json_encode($vr, JSON_UNESCAPED_UNICODE), (int)$payment['id']]);

  include __DIR__ . '/../includes/header.php';
  include __DIR__ . '/../includes/navbar.php';
  echo '<main class="container my-5"><div class="alert alert-danger">تایید پرداخت ناموفق بود.</div><a class="btn btn-outline-primary mt-3" href="../checkout.php">بازگشت</a></main>';
  include __DIR__ . '/../includes/footer.php';
  exit;
}

$pdo->beginTransaction();
try {
  $pdo->prepare("UPDATE payments SET status='verified', ref_id=?, card_pan=?, raw_response=? WHERE id=?")
      ->execute([$vr['ref_id'], $vr['card_pan'], $vr['raw'] ?? null, (int)$payment['id']]);

  $items = $pdo->prepare("SELECT * FROM order_items WHERE order_id=?");
  $items->execute([(int)$order['id']]);
  $items = $items->fetchAll();

  $uStock = $pdo->prepare("UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?");
  foreach ($items as $it) {
    $uStock->execute([(int)$it['qty'], (int)$it['product_id'], (int)$it['qty']]);
    if ($uStock->rowCount() === 0) throw new Exception('موجودی کافی نیست.');
  }

  if (!empty($order['coupon_code'])) {
    $pdo->prepare("UPDATE coupons SET used_count = used_count + 1 WHERE code = ?")->execute([$order['coupon_code']]);
  }

  $pdo->prepare("UPDATE orders SET status='paid' WHERE id=?")->execute([(int)$order['id']]);

  $pdo->commit();

  $_SESSION['cart'] = ['items'=>[],'coupon'=>null];

  header('Location: ' . BASE_URL . 'order-success.php?id=' . (int)$order['id']);
  exit;

} catch (Throwable $e) {
  $pdo->rollBack();
  $pdo->prepare("UPDATE payments SET status='failed' WHERE id=?")->execute([(int)$payment['id']]);
  include __DIR__ . '/../includes/header.php';
  include __DIR__ . '/../includes/navbar.php';
  echo '<main class="container my-5"><div class="alert alert-danger">خطا در تکمیل سفارش: ' . e($e->getMessage()) . '</div></main>';
  include __DIR__ . '/../includes/footer.php';
  exit;
}
