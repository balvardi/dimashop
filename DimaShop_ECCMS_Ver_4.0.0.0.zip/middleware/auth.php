<?php
require_once __DIR__ . '/../config.php';
// Usage: require_login() or require_admin() in your pages.
