<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib/gateway-zarinpal.php';
require_login();
cart_init();

$items = $_SESSION['cart']['items'];
if (!$items) { header('Location: cart.php'); exit; }

$tot = cart_totals();
$pdo = db();
$error = '';
$order_id = null;

if (is_post()) {
  verify_csrf();
  $full_name = trim($_POST['full_name'] ?? '');
  $phone = trim($_POST['phone'] ?? '');
  $address = trim($_POST['address'] ?? '');

  if ($full_name === '' || $phone === '' || $address === '') {
    $error = 'همه فیلدها الزامی است.';
  } else {
    $pdo->beginTransaction();
    try {
      $coupon_code = $_SESSION['cart']['coupon']['code'] ?? null;
      $stmt = $pdo->prepare("INSERT INTO orders (user_id, status, subtotal, discount, shipping, total, coupon_code) VALUES (?,?,?,?,?,?,?)");
      $stmt->execute([$_SESSION['user']['id'] ?? null, 'pending', $tot['subtotal'], $tot['discount'], $tot['shipping'], $tot['total'], $coupon_code]);
      $order_id = (int)$pdo->lastInsertId();

      $iStmt = $pdo->prepare("INSERT INTO order_items (order_id, product_id, qty, unit_price, attributes_json) VALUES (?,?,?,?,?)");
      foreach ($items as $it) {
        $iStmt->execute([$order_id, $it['product_id'], $it['qty'], $it['price'], json_encode($it['attributes'], JSON_UNESCAPED_UNICODE)]);
      }

      $pStmt = $pdo->prepare("INSERT INTO payments (order_id, gateway, amount, status) VALUES (?,?,?, 'initiated')");
      $pStmt->execute([$order_id, 'zarinpal', $tot['total']]);
      $payment_id = (int)$pdo->lastInsertId();

      $callback = app_base_url() . '/payment/callback.php';
      $desc = 'پرداخت سفارش #' . $order_id;
      $meta = ['mobile' => $phone];
      $req = zarinpal_request($order_id, (float)$tot['total'], $desc, $callback, $meta);

      if (!$req['ok']) {
        throw new Exception('عدم امکان اتصال به درگاه. لطفاً بعداً تلاش کنید.');
      }

      $upd = $pdo->prepare("UPDATE payments SET authority=?, raw_request=? WHERE id=?");
      $upd->execute([$req['authority'], $req['raw'] ?? null, $payment_id]);

      $pdo->commit();

      header('Location: ' . $req['startpay_url']);
      exit;
    } catch (Throwable $e) {
      $pdo->rollBack();
      $error = $e->getMessage();
    }
  }
}
?>
<?php include __DIR__ . '/includes/header.php'; ?>
<?php include __DIR__ . '/includes/navbar.php'; ?>

<main class="container my-4">
  <h1 class="h5 mb-3">تسویه حساب</h1>
  <?php if (!empty($error)): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
  <div class="row g-4">
    <div class="col-md-7">
      <div class="card">
        <div class="card-body">
          <h6 class="mb-3">آدرس و اطلاعات تماس</h6>
          <form method="post">
            <input type="hidden" name="_token" value="<?= e(csrf_token()) ?>">
            <div class="row g-3">
              <div class="col-md-6">
                <label class="form-label">نام و نام خانوادگی</label>
                <input type="text" name="full_name" class="form-control" required>
              </div>
              <div class="col-md-6">
                <label class="form-label">شماره تماس</label>
                <input type="tel" name="phone" class="form-control" required>
              </div>
              <div class="col-12">
                <label class="form-label">آدرس</label>
                <textarea name="address" class="form-control" rows="3" required></textarea>
              </div>
              <div class="col-12">
                <button class="btn btn-success">پرداخت آنلاین</button>
              </div>
            </div>
          </form>
          <div class="text-muted small mt-3">پس از ثبت، به درگاه زرین‌پال منتقل می‌شوید.</div>
        </div>
      </div>
    </div>
    <div class="col-md-5">
      <div class="card">
        <div class="card-body">
          <h6 class="mb-3">خلاصه سفارش</h6>
          <?php foreach ($items as $it): ?>
            <div class="d-flex justify-content-between small">
              <div><?= e($it['title']) ?> × <?= (int)$it['qty'] ?></div>
              <div><?= e(money((float)$it['price'] * (int)$it['qty'])) ?> تومان</div>
            </div>
          <?php endforeach; ?>
          <hr>
          <?php $tot = cart_totals(); ?>
          <div class="d-flex justify-content-between"><span>جمع جزء</span><strong><?= e(money((float)$tot['subtotal'])) ?> تومان</strong></div>
          <div class="d-flex justify-content-between"><span>تخفیف</span><strong><?= e(money((float)$tot['discount'])) ?> تومان</strong></div>
          <div class="d-flex justify-content-between"><span>ارسال</span><strong><?= e(money((float)$tot['shipping'])) ?> تومان</strong></div>
          <div class="d-flex justify-content-between fs-5 mt-2"><span>قابل پرداخت</span><strong><?= e(money((float)$tot['total'])) ?> تومان</strong></div>
        </div>
      </div>
    </div>
  </div>
</main>

<?php include __DIR__ . '/includes/footer.php'; ?>
