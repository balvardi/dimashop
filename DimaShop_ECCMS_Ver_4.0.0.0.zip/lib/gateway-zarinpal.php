<?php
declare(strict_types=1);

function zr_base(): string {
  return ZARINPAL_SANDBOX ? 'https://sandbox.zarinpal.com/pg/v4' : 'https://api.zarinpal.com/pg/v4';
}
function zr_startpay_base(): string {
  return ZARINPAL_SANDBOX ? 'https://sandbox.zarinpal.com/pg/StartPay/' : 'https://www.zarinpal.com/pg/StartPay/';
}

function http_post_json(string $url, array $payload): array {
  $ch = curl_init($url);
  $data = json_encode($payload, JSON_UNESCAPED_UNICODE);
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
    CURLOPT_POSTFIELDS => $data,
  ]);
  $res = curl_exec($ch);
  $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  $err = curl_error($ch);
  curl_close($ch);
  if ($res === false) return ['status' => 0, 'error' => $err, 'body' => null, 'raw' => null];
  $body = json_decode($res, true);
  return ['status' => $status, 'error' => null, 'body' => $body, 'raw' => $res];
}

function zarinpal_request(int $order_id, float $amount, string $description, string $callback_url, array $metadata = []): array {
  $payload = [
    'merchant_id' => ZARINPAL_MERCHANT_ID,
    'amount' => (int)round($amount),
    'callback_url' => $callback_url,
    'description' => $description,
    'metadata' => $metadata
  ];
  $resp = http_post_json(zr_base() . '/payment/request.json', $payload);
  if ($resp['status'] !== 200 || empty($resp['body']['data'])) {
    return ['ok'=>false, 'message'=>'خطا در ارتباط با درگاه', 'debug'=>$resp];
  }
  $data = $resp['body']['data'];
  if (($data['code'] ?? 0) === 100 && !empty($data['authority'])) {
    return [
      'ok' => true,
      'authority' => $data['authority'],
      'startpay_url' => zr_startpay_base() . $data['authority'],
      'raw' => $resp['raw']
    ];
  }
  return ['ok'=>false, 'message'=>'کد ناموفق از درگاه: ' . ($data['code'] ?? 'n/a'), 'debug'=>$resp];
}

function zarinpal_verify(string $authority, float $amount): array {
  $payload = [
    'merchant_id' => ZARINPAL_MERCHANT_ID,
    'amount' => (int)round($amount),
    'authority' => $authority
  ];
  $resp = http_post_json(zr_base() . '/payment/verify.json', $payload);
  if ($resp['status'] !== 200 || empty($resp['body']['data'])) {
    return ['ok'=>false, 'message'=>'خطا در تایید پرداخت', 'debug'=>$resp];
  }
  $data = $resp['body']['data'];
  $code = (int)($data['code'] ?? 0);
  if ($code === 100 || $code === 101) {
    return [
      'ok' => true,
      'code' => $code,
      'ref_id' => $data['ref_id'] ?? null,
      'card_pan' => $data['card_pan'] ?? null,
      'raw' => $resp['raw']
    ];
  }
  return ['ok'=>false, 'message'=>'تایید ناموفق: ' . $code, 'debug'=>$resp, 'raw'=>$resp['raw'] ?? null];
}
