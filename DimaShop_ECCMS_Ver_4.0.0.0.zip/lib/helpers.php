<?php
function is_post(): bool { return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST'; }

function csrf_token(): string {
  if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = hash_hmac('sha256', bin2hex(random_bytes(16)), APP_KEY);
  }
  return $_SESSION['csrf_token'];
}

function verify_csrf(): void {
  $token = $_POST['_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
  if (!$token || !hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
    http_response_code(419);
    exit('CSRF token mismatch');
  }
}

function e(string $str): string { return htmlspecialchars($str, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

function slugify(string $text): string {
  $text = trim($text);
  $text = preg_replace('~[^\pL\d]+~u', '-', $text);
  $text = iconv('UTF-8', 'ASCII//TRANSLIT', $text);
  $text = preg_replace('~[^-\w]+~', '', $text);
  $text = trim($text, '-');
  $text = preg_replace('~-+~', '-', $text);
  $text = strtolower($text);
  return $text ?: 'n-a';
}

function money(float $v): string { return number_format($v, 0, '.', ','); }

function current_user(): ?array {
  return $_SESSION['user'] ?? null;
}

function require_login(): void {
  if (!current_user()) {
    header('Location: ' . BASE_URL . 'auth/login.php');
    exit;
  }
}

function require_admin(): void {
  if (!current_user() || ($_SESSION['user']['role'] ?? '') !== 'admin') {
    http_response_code(403);
    exit('Forbidden');
  }
}

function json_response($data, int $status = 200): void {
  http_response_code($status);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode($data, JSON_UNESCAPED_UNICODE);
  exit;
}

function cart_init(): void {
  if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [
      'items' => [],
      'coupon' => null,
    ];
  }
}

function cart_key(int $product_id, array $attributes): string {
  ksort($attributes);
  return $product_id . ':' . md5(json_encode($attributes, JSON_UNESCAPED_UNICODE));
}

function cart_totals(): array {
  cart_init();
  $subtotal = 0;
  foreach ($_SESSION['cart']['items'] as $item) {
    $subtotal += $item['price'] * $item['qty'];
  }
  $discount = 0;
  if (!empty($_SESSION['cart']['coupon'])) {
    $c = $_SESSION['cart']['coupon'];
    if ($c['type'] === 'percent') $discount = $subtotal * ($c['amount'] / 100.0);
    else $discount = min($subtotal, $c['amount']);
  }
  $shipping = 0;
  $total = max(0, $subtotal - $discount) + $shipping;
  return compact('subtotal','discount','shipping','total');
}
