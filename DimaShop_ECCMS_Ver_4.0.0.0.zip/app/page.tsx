"use client"

import  from "../assets/js/main"

export default function SyntheticV0PageForDeployment() {
  return < />
}