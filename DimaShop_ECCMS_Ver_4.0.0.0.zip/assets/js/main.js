// jQuery based AJAX interactions
$(() => {
  // Add to cart
  $(document).on("submit", ".add-to-cart-form", function (e) {
    e.preventDefault()
    const form = $(this)
    const data = form.serializeArray()
    data.push({ name: "_token", value: window.CSRF_TOKEN })
    $.post(
      "api/cart.php?action=add",
      data,
      (res) => {
        if (res.ok) {
          alert("به سبد اضافه شد")
          $('.navbar a[href$="cart.php"]').text("سبد خرید (" + res.cart_count + ")")
        } else {
          alert(res.message || "خطا در افزودن به سبد")
        }
      },
      "json",
    )
  })

  // Update cart quantity
  $(document).on("change", ".cart-qty", function () {
    const key = $(this).data("key")
    const qty = Number.parseInt($(this).val() || "1", 10)
    $.post(
      "api/cart.php?action=update",
      { key, qty, _token: window.CSRF_TOKEN },
      (res) => {
        if (res.ok) location.reload()
      },
      "json",
    )
  })

  // Remove from cart
  $(document).on("click", ".cart-remove", function () {
    const key = $(this).data("key")
    $.post(
      "api/cart.php?action=remove",
      { key, _token: window.CSRF_TOKEN },
      (res) => {
        if (res.ok) location.reload()
      },
      "json",
    )
  })

  // Apply coupon
  $("#apply-coupon-btn").on("click", () => {
    const code = $("#coupon-code").val().trim()
    if (!code) return alert("کد تخفیف را وارد کنید")
    $.post(
      "api/coupons.php?action=apply",
      { code, _token: window.CSRF_TOKEN },
      (res) => {
        if (res.ok) location.reload()
        else alert(res.message || "کد معتبر نیست")
      },
      "json",
    )
  })

  // Remove coupon
  $("#remove-coupon-btn").on("click", () => {
    $.post(
      "api/coupons.php?action=remove",
      { _token: window.CSRF_TOKEN },
      (res) => {
        if (res.ok) location.reload()
      },
      "json",
    )
  })

  // Live price update on product page
  $(document).on("change", ".product-attr", () => {
    const base = Number.parseFloat($("#base-price").data("base"))
    let price = base
    $(".product-attr option:selected").each(function () {
      const t = $(this).data("type")
      const v = Number.parseFloat($(this).data("value") || 0)
      if (t === "flat") price += v
      else if (t === "percent") price += base * (v / 100.0)
    })
    $("#final-price").text(price.toLocaleString("fa-IR"))
  })
})
