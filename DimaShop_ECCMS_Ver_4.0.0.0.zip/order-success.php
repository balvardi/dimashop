<?php require_once __DIR__ . '/config.php'; require_login(); ?>
<?php include __DIR__ . '/includes/header.php'; ?>
<?php include __DIR__ . '/includes/navbar.php'; ?>

<main class="container my-5">
  <div class="alert alert-success">
    سفارش شما با موفقیت ثبت شد. شماره سفارش: <?= (int)($_GET['id'] ?? 0) ?>
  </div>
  <a href="index.php" class="btn btn-primary">بازگشت به صفحه اصلی</a>
</main>

<?php include __DIR__ . '/includes/footer.php'; ?>
