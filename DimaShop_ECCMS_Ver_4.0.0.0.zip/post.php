<?php require_once __DIR__ . '/config.php'; ?>
<?php
$slug = $_GET['slug'] ?? '';
$stmt = db()->prepare("SELECT * FROM posts WHERE slug=? AND is_published=1 LIMIT 1");
$stmt->execute([$slug]);
$post = $stmt->fetch();
if (!$post) { http_response_code(404); exit('یافت نشد'); }
?>
<?php include __DIR__ . '/includes/header.php'; ?>
<?php include __DIR__ . '/includes/navbar.php'; ?>
<main class="container my-4">
  <h1 class="h4 mb-3"><?= e($post['title']) ?></h1>
  <div class="text-muted small mb-4"><?= e($post['created_at']) ?></div>
  <article class="lh-lg"><?= nl2br(e($post['content'])) ?></article>
</main>
<?php include __DIR__ . '/includes/footer.php'; ?>
