<?php require_once __DIR__ . '/config.php'; ?>
<?php
$posts = db()->query("SELECT * FROM posts WHERE is_published=1 ORDER BY id DESC")->fetchAll();
?>
<?php include __DIR__ . '/includes/header.php'; ?>
<?php include __DIR__ . '/includes/navbar.php'; ?>
<main class="container my-4">
  <h1 class="h5 mb-3">وبلاگ</h1>
  <div class="row g-3">
    <?php foreach ($posts as $p): ?>
      <div class="col-md-6 col-lg-4">
        <div class="card h-100">
          <div class="card-body d-flex flex-column">
            <h2 class="h6"><a href="post.php?slug=<?= e($p['slug']) ?>" class="text-decoration-none"><?= e($p['title']) ?></a></h2>
            <div class="text-muted small mt-auto"><?= e($p['created_at']) ?></div>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</main>
<?php include __DIR__ . '/includes/footer.php'; ?>
