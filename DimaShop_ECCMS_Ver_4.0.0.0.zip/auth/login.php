<?php require_once __DIR__ . '/../config.php'; ?>
<?php
if (current_user()) { header('Location: ' . BASE_URL); exit; }
$error = '';
if (is_post()) {
  verify_csrf();
  $email = trim($_POST['email'] ?? '');
  $password = (string)($_POST['password'] ?? '');
  $stmt = db()->prepare("SELECT * FROM users WHERE email=? LIMIT 1");
  $stmt->execute([$email]);
  $user = $stmt->fetch();
  if ($user && password_verify($password, $user['password_hash'])) {
    $_SESSION['user'] = ['id'=>$user['id'],'name'=>$user['name'],'email'=>$user['email'],'role'=>$user['role']];
    header('Location: ' . BASE_URL);
    exit;
  } else {
    $error = 'ایمیل یا رمز عبور نادرست است.';
  }
}
?>
<?php include __DIR__ . '/../includes/header.php'; ?>
<?php include __DIR__ . '/../includes/navbar.php'; ?>
<main class="container my-5" style="max-width:420px">
  <h1 class="h5 mb-3">ورود</h1>
  <?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
  <form method="post">
    <input type="hidden" name="_token" value="<?= e(csrf_token()) ?>">
    <div class="mb-3">
      <label class="form-label">ایمیل</label>
      <input type="email" name="email" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">رمز عبور</label>
      <input type="password" name="password" class="form-control" required>
    </div>
    <button class="btn btn-primary w-100">ورود</button>
  </form>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
