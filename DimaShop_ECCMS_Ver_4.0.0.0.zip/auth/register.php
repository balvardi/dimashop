<?php require_once __DIR__ . '/../config.php'; ?>
<?php
if (current_user()) { header('Location: ' . BASE_URL); exit; }
$error = '';
if (is_post()) {
  verify_csrf();
  $name = trim($_POST['name'] ?? '');
  $email = trim($_POST['email'] ?? '');
  $password = (string)($_POST['password'] ?? '');
  if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 8) {
    $error = 'ورودی نامعتبر';
  } else {
    $pdo = db();
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email=? LIMIT 1");
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
      $error = 'این ایمیل قبلاً ثبت شده است.';
    } else {
      $hash = password_hash($password, PASSWORD_BCRYPT);
      $pdo->prepare("INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?,'customer')")
          ->execute([$name,$email,$hash]);
      $_SESSION['user'] = ['id'=>$pdo->lastInsertId(),'name'=>$name,'email'=>$email,'role'=>'customer'];
      header('Location: ' . BASE_URL);
      exit;
    }
  }
}
?>
<?php include __DIR__ . '/../includes/header.php'; ?>
<main class="container my-5" style="max-width:480px">
  <h1 class="h5 mb-3">ثبت‌نام</h1>
  <?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
  <form method="post">
    <input type="hidden" name="_token" value="<?= e(csrf_token()) ?>">
    <div class="mb-3">
      <label class="form-label">نام</label>
      <input type="text" name="name" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">ایمیل</label>
      <input type="email" name="email" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">رمز عبور</label>
      <input type="password" name="password" class="form-control" minlength="8" required>
    </div>
    <button class="btn btn-primary w-100">ثبت‌نام</button>
  </form>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
