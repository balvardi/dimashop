<?php require_once __DIR__ . '/config.php'; require_login(); ?>
<?php
$pdo = db();
$user = current_user();

/* User stats */
$ordersCount = (int)$pdo->prepare("SELECT COUNT(*) FROM orders WHERE user_id = ?")
  ->execute([$user['id']]) ?: 0;
$ordersStmt = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE user_id = ?");
$ordersStmt->execute([$user['id']]);
$ordersCount = (int)$ordersStmt->fetchColumn();

$totalPaidStmt = $pdo->prepare("SELECT COALESCE(SUM(total),0) FROM orders WHERE user_id=? AND status IN ('paid','shipped','completed')");
$totalPaidStmt->execute([$user['id']]);
$totalPaid = (float)$totalPaidStmt->fetchColumn();

$pendingStmt = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE user_id=? AND status='pending'");
$pendingStmt->execute([$user['id']]);
$pendingCount = (int)$pendingStmt->fetchColumn();

$recent = $pdo->prepare("SELECT id, status, total, created_at FROM orders WHERE user_id=? ORDER BY id DESC LIMIT 6");
$recent->execute([$user['id']]);
$recentOrders = $recent->fetchAll();

/* Recommended products (latest active) */
$prods = $pdo->query("SELECT id,title,slug,price FROM products WHERE is_active=1 ORDER BY id DESC LIMIT 8")->fetchAll();
$imgStmt = $pdo->prepare("SELECT image_url FROM product_images WHERE product_id=? ORDER BY sort_order ASC, id ASC LIMIT 1");
?>
<?php include __DIR__ . '/includes/header.php'; ?>
<?php include __DIR__ . '/includes/navbar.php'; ?>

<main class="container my-4">
  <div class="row g-3">
    <div class="col-lg-4">
      <div class="card p-3">
        <div class="d-flex align-items-center gap-2">
          <div class="fw-semibold">سلام، <?= e($user['name']) ?></div>
          <span class="badge text-bg-light">کاربر</span>
        </div>
        <div class="mt-2 small text-muted">خلاصه حساب شما</div>
        <div class="row g-2 mt-2">
          <div class="col-4"><div class="p-2 border rounded text-center"><div class="small text-muted">سفارش‌ها</div><div class="fw-bold"><?= $ordersCount ?></div></div></div>
          <div class="col-4"><div class="p-2 border rounded text-center"><div class="small text-muted">در انتظار</div><div class="fw-bold"><?= $pendingCount ?></div></div></div>
          <div class="col-4"><div class="p-2 border rounded text-center"><div class="small text-muted">پرداختی</div><div class="fw-bold"><?= e(money($totalPaid)) ?></div></div></div>
        </div>
        <a href="profile.php" class="btn btn-outline-secondary btn-sm mt-3 w-100">ویرایش پروفایل</a>
      </div>
    </div>

    <div class="col-lg-8">
      <div class="card p-3 h-100">
        <div class="d-flex align-items-center justify-content-between mb-2">
          <div class="fw-semibold">سفارش‌های اخیر</div>
          <a href="cart.php" class="btn btn-sm btn-primary">سبد خرید</a>
        </div>
        <div class="table-responsive">
          <table class="table table-sm align-middle mb-0">
            <thead><tr><th>#</th><th>وضعیت</th><th>مبلغ</th><th>تاریخ</th></tr></thead>
            <tbody>
            <?php foreach ($recentOrders as $o): ?>
              <tr>
                <td><?= (int)$o['id'] ?></td>
                <td><?= e($o['status']) ?></td>
                <td><?= e(money((float)$o['total'])) ?> تومان</td>
                <td><?= e($o['created_at']) ?></td>
              </tr>
            <?php endforeach; if (!$recentOrders): ?>
              <tr><td colspan="4" class="small text-muted">سفارشی ثبت نشده است.</td></tr>
            <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <div class="col-12">
      <div class="card p-3">
        <div class="fw-semibold mb-2">پیشنهاد برای شما</div>
        <div class="row g-3">
          <?php foreach ($prods as $p): 
            $imgStmt->execute([$p['id']]); $img = $imgStmt->fetchColumn() ?: 'https://via.placeholder.com/600x400?text=Product';
          ?>
            <div class="col-6 col-md-3 col-lg-2">
              <div class="card h-100">
                <a href="product.php?slug=<?= e($p['slug']) ?>"><img src="<?= e($img) ?>" class="card-img-top" alt="<?= e($p['title']) ?>"></a>
                <div class="card-body d-flex flex-column">
                  <a href="product.php?slug=<?= e($p['slug']) ?>" class="text-decoration-none small fw-semibold mb-2"><?= e($p['title']) ?></a>
                  <div class="mt-auto fw-bold small"><?= e(money((float)$p['price'])) ?> تومان</div>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>

  </div>
</main>

<?php include __DIR__ . '/includes/footer.php'; ?>
