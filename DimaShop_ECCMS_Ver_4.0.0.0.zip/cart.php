<?php require_once __DIR__ . '/config.php'; cart_init(); ?>
<?php include __DIR__ . '/includes/header.php'; ?>
<?php include __DIR__ . '/includes/navbar.php'; ?>

<main class="container my-4">
  <h1 class="h5 mb-3">سبد خرید</h1>
  <?php $items = $_SESSION['cart']['items']; $tot = cart_totals(); ?>
  <?php if (!$items): ?>
    <div class="alert alert-info">سبد خرید شما خالی است.</div>
  <?php else: ?>
    <div class="table-responsive">
      <table class="table align-middle">
        <thead><tr><th>محصول</th><th>ویژگی‌ها</th><th>قیمت</th><th style="width:120px">تعداد</th><th>مجموع</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($items as $key => $it): ?>
          <tr>
            <td class="fw-semibold"><?= e($it['title']) ?></td>
            <td class="small text-muted">
              <?php foreach ($it['attributes'] as $name => $value): ?>
                <div><?= e($name) ?>: <?= e($value) ?></div>
              <?php endforeach; ?>
            </td>
            <td><?= e(money((float)$it['price'])) ?> تومان</td>
            <td>
              <input type="number" class="form-control cart-qty" data-key="<?= e($key) ?>" value="<?= (int)$it['qty'] ?>" min="1">
            </td>
            <td><?= e(money((float)$it['price'] * (int)$it['qty'])) ?> تومان</td>
            <td><button class="btn btn-sm btn-outline-danger cart-remove" data-key="<?= e($key) ?>">حذف</button></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <div class="row g-3">
      <div class="col-md-6">
        <div class="card">
          <div class="card-body">
            <label class="form-label">کد تخفیف</label>
            <div class="input-group">
              <input type="text" id="coupon-code" class="form-control" placeholder="کوپن">
              <button class="btn btn-outline-primary" id="apply-coupon-btn">اعمال</button>
              <button class="btn btn-outline-secondary" id="remove-coupon-btn">حذف</button>
            </div>
            <?php if (!empty($_SESSION['cart']['coupon'])): ?>
              <div class="mt-2 small text-success">کوپن فعال: <?= e($_SESSION['cart']['coupon']['code']) ?></div>
            <?php endif; ?>
          </div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="card">
          <div class="card-body">
            <div class="d-flex justify-content-between"><span>جمع جزء</span><strong><?= e(money((float)$tot['subtotal'])) ?> تومان</strong></div>
            <div class="d-flex justify-content-between"><span>تخفیف</span><strong><?= e(money((float)$tot['discount'])) ?> تومان</strong></div>
            <div class="d-flex justify-content-between"><span>هزینه ارسال</span><strong><?= e(money((float)$tot['shipping'])) ?> تومان</strong></div>
            <hr>
            <div class="d-flex justify-content-between fs-5"><span>قابل پرداخت</span><strong><?= e(money((float)$tot['total'])) ?> تومان</strong></div>
            <a href="checkout.php" class="btn btn-success w-100 mt-3">ادامه فرآیند خرید</a>
          </div>
        </div>
      </div>
    </div>
  <?php endif; ?>
</main>

<?php include __DIR__ . '/includes/footer.php'; ?>
