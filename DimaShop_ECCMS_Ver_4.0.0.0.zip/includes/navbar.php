<?php cart_init(); $user = current_user(); $cartCount = array_sum(array_column($_SESSION['cart']['items'], 'qty')); ?>
<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container">
    <a class="navbar-brand fw-bold" href="<?= e(BASE_URL) ?>"><img src="assets/images/logo.png" width="auto" height="40px"/></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse gap-3" id="mainNav">
      <form class="d-flex ms-auto" role="search" action="<?= e(BASE_URL) ?>index.php" method="get">
        <input class="form-control" type="search" placeholder="جستجو..." name="q" id="search-input" autocomplete="off">
      </form>
      <ul class="navbar-nav mb-2 mb-lg-0">
        <li class="nav-item"><a class="nav-link" href="<?= e(BASE_URL) ?>cart.php">سبد خرید (<?= (int)$cartCount ?>)</a></li>
        <?php if ($user): ?>
          <li class="nav-item"><a class="nav-link" href="<?= e(BASE_URL) ?>dashboard.php">داشبورد</a></li>
        <?php endif; ?>
        <?php if ($user): ?>
          <li class="nav-item"><a class="nav-link" href="<?= e(BASE_URL) ?>profile.php"><?= e($user['name']) ?></a></li>
          <?php if (($user['role'] ?? '') === 'admin'): ?>
            <li class="nav-item"><a class="nav-link" href="<?= e(BASE_URL) ?>admin/index.php">مدیریت</a></li>
          <?php endif; ?>
          <li class="nav-item"><a class="nav-link" href="<?= e(BASE_URL) ?>auth/logout.php">خروج</a></li>
        <?php else: ?>
          <li class="nav-item"><a class="nav-link" href="<?= e(BASE_URL) ?>auth/login.php">ورود</a></li>
          <li class="nav-item"><a class="nav-link" href="<?= e(BASE_URL) ?>auth/register.php">ثبت‌نام</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
