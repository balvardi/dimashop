<?php require_once __DIR__ . '/../config.php'; ?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="utf-8">
  <title>دیماشاپ</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?= e(BASE_URL) ?>styles/bootstrap.rtl.min.css" crossorigin="anonymous">
  <link rel="stylesheet" href="<?= e(BASE_URL) ?>assets/main.css">
  <link rel="stylesheet" href="<?= e(BASE_URL) ?>assets/vazir.css">
</head>
<body>
