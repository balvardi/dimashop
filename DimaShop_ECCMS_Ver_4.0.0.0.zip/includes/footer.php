<footer class="border-top mt-5">
  <div class="container py-4 text-muted small">
    <div>© <?= date('Y') ?> Dima Shop</div>
  </div>
</footer>

<script src="https://code.jquery.com/jquery-3.7.1.min.js" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
<script>
  window.CSRF_TOKEN = '<?= e(csrf_token()) ?>';
</script>
<script src="<?= e(BASE_URL) ?>assets/js/main.js"></script>
</body>
</html>
