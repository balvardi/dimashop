<?php require_once __DIR__ . '/config.php'; ?>
<?php
$slug = $_GET['slug'] ?? '';
if ($slug === '') { header('Location: index.php'); exit; }
$pdo = db();
$stmt = $pdo->prepare("SELECT * FROM products WHERE slug=? AND is_active=1 LIMIT 1");
$stmt->execute([$slug]);
$product = $stmt->fetch();
if (!$product) { http_response_code(404); exit('محصول یافت نشد'); }

$images = $pdo->prepare("SELECT * FROM product_images WHERE product_id=? ORDER BY sort_order ASC, id ASC");
$images->execute([$product['id']]);
$images = $images->fetchAll();

$attrs = $pdo->prepare("
  SELECT a.id as attr_id, a.name as attr_name, av.id as val_id, av.value, av.modifier_type, av.modifier_value
  FROM attributes a
  JOIN attribute_values av ON av.attribute_id = a.id
  JOIN product_attribute_values pav ON pav.attribute_value_id = av.id
  WHERE pav.product_id = ?
  ORDER BY a.id ASC, av.id ASC
");
$attrs->execute([$product['id']]);
$rows = $attrs->fetchAll();

$grouped = [];
foreach ($rows as $r) {
  $grouped[$r['attr_id']]['name'] = $r['attr_name'];
  $grouped[$r['attr_id']]['values'][] = $r;
}
?>
<?php include __DIR__ . '/includes/header.php'; ?>
<?php include __DIR__ . '/includes/navbar.php'; ?>

<main class="container my-4">
  <div class="row g-4">
    <div class="col-lg-6">
      <?php $first = $images[0]['image_url'] ?? 'https://via.placeholder.com/800x600?text=Product'; ?>
      <img src="<?= e($first) ?>" class="img-fluid rounded border mb-3" alt="<?= e($product['title']) ?>">
      <div class="d-flex gap-2">
        <?php foreach ($images as $img): ?>
          <img src="<?= e($img['image_url']) ?>" style="width:96px;height:96px;object-fit:cover" class="rounded border" alt="">
        <?php endforeach; ?>
      </div>
    </div>
    <div class="col-lg-6">
      <h1 class="h4 mb-3"><?= e($product['title']) ?></h1>
      <div class="text-muted small mb-2"><?= e($product['sku'] ?? '') ?></div>

      <div id="base-price" data-base="<?= (float)$product['price'] ?>" class="mb-2"></div>
      <div class="h5">قیمت: <span id="final-price"><?= e(money((float)$product['price'])) ?></span> تومان</div>

      <form class="mt-3 add-to-cart-form">
        <input type="hidden" name="product_id" value="<?= (int)$product['id'] ?>">
        <?php foreach ($grouped as $attrId => $data): ?>
          <div class="mb-3">
            <label class="form-label"><?= e($data['name']) ?></label>
            <select name="attr[<?= (int)$attrId ?>]" class="form-select product-attr">
              <?php foreach ($data['values'] as $v): ?>
                <option value="<?= (int)$v['val_id'] ?>"
                        data-type="<?= e($v['modifier_type']) ?>"
                        data-value="<?= e($v['modifier_value']) ?>">
                  <?= e($v['value']) ?>
                  <?php if ((float)$v['modifier_value'] != 0): ?>
                    (<?= $v['modifier_type']==='percent' ? '%' : '+' ?><?= e(money((float)$v['modifier_value'])) ?>)
                  <?php endif; ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
        <?php endforeach; ?>
        <div class="d-flex align-items-center gap-2">
          <input type="number" name="qty" value="1" min="1" class="form-control" style="max-width:120px">
          <button class="btn btn-primary">افزودن به سبد</button>
        </div>
      </form>

      <hr class="my-4">
      <div class="small text-muted"><?= nl2br(e($product['description'] ?? '')) ?></div>
    </div>
  </div>
</main>

<?php include __DIR__ . '/includes/footer.php'; ?>
