"use client"

import { Download } from "lucide-react"

async function downloadZip() {
  const res = await fetch("/api/zip")
  if (!res.ok) {
    alert("خطا در ساخت فایل ZIP")
    return
  }
  const blob = await res.blob()
  const url = URL.createObjectURL(blob)
  const a = document.createElement("a")
  a.href = url
  a.download = "dimashop.zip"
  document.body.appendChild(a)
  a.click()
  a.remove()
  URL.revokeObjectURL(url)
}

export default function Page() {
  return (
    <main className="min-h-dvh grid place-items-center bg-white">
      <div className="w-full max-w-md rounded-2xl border border-gray-200 p-6 shadow-sm">
        <h1 className="text-xl font-bold mb-2 text-gray-900">DIma Shop - ساخت فایل ZIP</h1>
        <p className="text-sm text-gray-600 mb-6">
          با فشردن دکمه زیر، فایل ZIP شامل کد کامل پروژه DIma Shop ساخته و دانلود می‌شود.
        </p>
        <button
          onClick={downloadZip}
          className="inline-flex items-center gap-2 rounded-lg bg-emerald-600 px-4 py-2 text-white hover:bg-emerald-700"
        >
          <Download className="h-4 w-4" />
          دانلود dimashop.zip
        </button>
        <p className="text-xs text-gray-500 mt-4">
          شامل: PHP MVC، درگاه زرین‌پال، پنل ادمین، Tailwind (build محلی)، اسکیما SQL و فایل‌های امنیتی .htaccess
        </p>
      </div>
    </main>
  )
}
