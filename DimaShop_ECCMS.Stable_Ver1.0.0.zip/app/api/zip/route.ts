import JSZip from "jszip"
import { projectFiles } from "@/lib/project-files"

export async function GET() {
  const zip = new JSZip()
  for (const [path, content] of Object.entries(projectFiles())) {
    // If content is string, add as text; if Uint8Array/Buffer, add as binary
    if (typeof content === "string") {
      zip.file(path, content)
    } else {
      zip.file(path, content as Uint8Array)
    }
  }
  const buf = await zip.generateAsync({ type: "nodebuffer", compression: "DEFLATE", compressionOptions: { level: 9 } })
  return new Response(buf, {
    headers: {
      "Content-Type": "application/zip",
      "Content-Disposition": 'attachment; filename="dimashop.zip"',
      "Cache-Control": "no-store",
    },
  })
}
