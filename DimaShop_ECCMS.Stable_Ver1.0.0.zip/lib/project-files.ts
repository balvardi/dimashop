export function projectFiles(): Record<string, string | Uint8Array> {
  // All files packaged into the ZIP: PHP app, SQL schema, Tailwind build setup, security .htaccess, README, etc.
  const files: Record<string, string> = {
    // Root meta
    "README.md": readme(),
    ".gitignore": gitignore(),

    // Node/Tailwind build setup
    "package.json": packageJson(),
    "postcss.config.js": postcssConfig(),
    "tailwind.config.js": tailwindConfig(),
    "resources/css/app.css": tailwindEntryCss(),
    "public/assets/.gitkeep": "",

    // Database
    "database/schema.sql": schemaSql(),

    // Public
    "public/.htaccess": publicHtaccess(),
    "public/index.php": publicIndexPhp(),
    "public/uploads/.htaccess": publicUploadsHtaccess(),

    // PHP App Core
    "bootstrap.php": bootstrapPhp(),
    "app/Config.php": configPhp(),
    "app/Database.php": databasePhp(),
    "app/Router.php": routerPhp(),
    "app/Controller.php": controllerPhp(),
    "app/Model.php": modelPhp(),
    "app/Helpers.php": helpersPhp(),

    // Middleware
    "app/Middleware/Csrf.php": csrfPhp(),
    "app/Middleware/RateLimit.php": rateLimitPhp(),

    // Services
    "app/Services/Cart.php": cartPhp(),
    "app/Services/Payment/Zarinpal.php": zarinpalPhp(),

    // Models
    "app/Models/Product.php": modelProductPhp(),
    "app/Models/Order.php": modelOrderPhp(),
    "app/Models/Coupon.php": modelCouponPhp(),

    // Controllers - Front
    "app/Controllers/HomeController.php": homeControllerPhp(),
    "app/Controllers/ProductController.php": productControllerPhp(),
    "app/Controllers/CartController.php": cartControllerPhp(),
    "app/Controllers/CheckoutController.php": checkoutControllerPhp(),
    "app/Controllers/PaymentController.php": paymentControllerPhp(),

    // Controllers - Admin
    "app/Controllers/Admin/AuthController.php": adminAuthControllerPhp(),
    "app/Controllers/Admin/DashboardController.php": adminDashboardControllerPhp(),
    "app/Controllers/Admin/ProductsController.php": adminProductsControllerPhp(),
    "app/Controllers/Admin/OrdersController.php": adminOrdersControllerPhp(),

    // Views - Front (Tailwind build-linked)
    "app/Views/layout.php": viewLayoutPhp(),
    "app/Views/home.php": viewHomePhp(),
    "app/Views/product-detail.php": viewProductDetailPhp(),
    "app/Views/cart.php": viewCartPhp(),
    "app/Views/checkout.php": viewCheckoutPhp(),
    "app/Views/order-success.php": viewOrderSuccessPhp(),

    // Views - Admin
    "app/Views/admin/layout.php": viewAdminLayoutPhp(),
    "app/Views/admin/login.php": viewAdminLoginPhp(),
    "app/Views/admin/dashboard.php": viewAdminDashboardPhp(),
    "app/Views/admin/products.php": viewAdminProductsPhp(),
    "app/Views/admin/orders.php": viewAdminOrdersPhp(),
  }

  return files
}

/* --------------- Root files --------------- */
function readme(): string {
  return `# DIma Shop

DIma Shop یک فروشگاه‌ساز رایگان، سبک و ماژولار با PHP و MySQL است که از درگاه پرداخت زرین‌پال پشتیبانی می‌کند و رابط کاربری آن با Tailwind CSS ساخته شده است.

وب‌سایت رسمی: https://dimashop.ir
ایمیل پشتیبانی: info@dima.shop.ir

نصب سریع:
1) ساخت دیتابیس و اجرای database/schema.sql
2) تنظیم app/Config.php (DB, APP_URL, ZarinPal)
3) تنظیم DocumentRoot روی public/ و فعال‌سازی mod_rewrite
4) نصب و Build تیلویند:
   npm install
   npm run build
5) تنظیم Callback زرین‌پال روی https://dimashop.ir/payment/callback

برای توسعه:
- npm run dev (watch CSS)
- تمام فرم‌های POST دارای CSRF هستند.
- برای تولید، APP_DEBUG را false کنید و هدرهای امنیتی را فعال نگه دارید.

مجوز: MIT
`
}

function gitignore(): string {
  return `# Dependencies
/node_modules
yarn.lock
pnpm-lock.yaml

# Build
public/assets/app.css
/build

# Logs
npm-debug.log*
yarn-debug.log*
pnpm-debug.log*

# Env files
.env*
`
}

function packageJson(): string {
  return `{
  "name": "dimashop",
  "version": "1.0.0",
  "private": true,
  "description": "DIma Shop - PHP MySQL Ecommerce with Tailwind CSS",
  "scripts": {
    "dev": "tailwindcss -i ./resources/css/app.css -o ./public/assets/app.css --watch",
    "build": "tailwindcss -i ./resources/css/app.css -o ./public/assets/app.css --minify"
  },
  "devDependencies": {
    "autoprefixer": "^10.4.20",
    "postcss": "^8.4.41",
    "tailwindcss": "^3.4.9"
  }
}
`
}

function postcssConfig(): string {
  return `module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {}
  }
}
`
}

function tailwindConfig(): string {
  return `/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.php",
    "./public/**/*.php",
    "./resources/**/*.js",
    "./*.php"
  ],
  theme: {
    extend: {
      colors: {
        primary: "#0ea5a6"
      }
    }
  },
  darkMode: "class",
  plugins: []
}
`
}

function tailwindEntryCss(): string {
  return `@tailwind base;
@tailwind components;
@tailwind utilities;

html[dir="rtl"] {}

.btn { @apply inline-flex items-center justify-center px-4 py-2 rounded-lg; }
.btn-primary { @apply bg-primary text-white hover:bg-teal-600; }
`
}

/* --------------- Database --------------- */
function schemaSql(): string {
  return `-- Users
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','customer') NOT NULL DEFAULT 'customer',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Products
CREATE TABLE IF NOT EXISTS products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  slug VARCHAR(255) NOT NULL UNIQUE,
  description TEXT,
  price INT NOT NULL,
  sale_price INT DEFAULT NULL,
  sku VARCHAR(100) DEFAULT NULL,
  stock_qty INT DEFAULT 0,
  status ENUM('publish','draft') NOT NULL DEFAULT 'publish',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Coupons
CREATE TABLE IF NOT EXISTS coupons (
  id INT AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(100) NOT NULL UNIQUE,
  type ENUM('percent','fixed') NOT NULL DEFAULT 'percent',
  amount INT NOT NULL,
  usage_limit INT DEFAULT NULL,
  used INT NOT NULL DEFAULT 0,
  expires_at DATETIME DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Orders
CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT DEFAULT NULL,
  status VARCHAR(50) NOT NULL DEFAULT 'pending',
  total INT NOT NULL,
  subtotal INT NOT NULL,
  discount INT NOT NULL DEFAULT 0,
  shipping_cost INT NOT NULL DEFAULT 0,
  tax INT NOT NULL DEFAULT 0,
  payment_status VARCHAR(50) NOT NULL DEFAULT 'unpaid',
  payment_method VARCHAR(50) DEFAULT 'zarinpal',
  payment_ref VARCHAR(100) DEFAULT NULL,
  email VARCHAR(190) DEFAULT NULL,
  name VARCHAR(190) DEFAULT NULL,
  phone VARCHAR(50) DEFAULT NULL,
  address TEXT,
  city VARCHAR(190) DEFAULT NULL,
  postal_code VARCHAR(50) DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Order Items
CREATE TABLE IF NOT EXISTS order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  product_id INT NOT NULL,
  variation_id INT DEFAULT NULL,
  name VARCHAR(255) NOT NULL,
  sku VARCHAR(100) DEFAULT NULL,
  price INT NOT NULL,
  qty INT NOT NULL,
  total INT NOT NULL,
  FOREIGN KEY (order_id) REFERENCES orders (id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Admin seed (admin@example.com / Admin@12345)
INSERT INTO users (email, password_hash, role) VALUES
('admin@example.com', '$2y$10$N9k9F9mPd8j2z8m2B.8ZfO8M1zUq1eI3n7mTgG6s5m3rXJ0k1bC7G', 'admin');

-- Sample product
INSERT INTO products (name, slug, description, price, sale_price, sku, stock_qty, status) VALUES
('محصول نمونه', 'sample-product', 'توضیحات محصول نمونه', 200000, 180000, 'SKU-1', 10, 'publish');
`
}

/* --------------- Public --------------- */
function publicHtaccess(): string {
  return `<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule ^ index.php [QSA,L]
</IfModule>

Options -Indexes

<FilesMatch "(\\.env|\\.env\\.local|composer\\.(json|lock)|package\\.json|webpack\\.config\\.js|tsconfig\\.json|phpunit\\.xml|\\.git|\\.svn|\\.DS_Store|\\.bak|\\.sql)$">
  Require all denied
</FilesMatch>

<IfModule mod_headers.c>
  Header set X-Content-Type-Options "nosniff"
  Header set X-Frame-Options "SAMEORIGIN"
  Header set Referrer-Policy "strict-origin-when-cross-origin"
  Header set X-XSS-Protection "1; mode=block"
  Header set Content-Security-Policy "default-src 'self'; img-src 'self' data: https:; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'self'; base-uri 'self'; form-action 'self'"
</IfModule>
`
}

function publicUploadsHtaccess(): string {
  return `php_flag engine off
RemoveHandler .php .phtml .php3 .php4 .php5 .php7 .php8
RemoveType .php .phtml .php3 .php4 .php5 .php7 .php8
<FilesMatch "\\.(php|phtml|php\\d+)$">
  Require all denied
</FilesMatch>
Options -ExecCGI
`
}

function publicIndexPhp(): string {
  return `<?php
declare(strict_types=1);

session_start();

require_once __DIR__ . '/../bootstrap.php';

use App\\Router;
use App\\Controllers\\HomeController;
use App\\Controllers\\ProductController;
use App\\Controllers\\CartController;
use App\\Controllers\\CheckoutController;
use App\\Controllers\\PaymentController;
use App\\Controllers\\Admin\\AuthController as AdminAuthController;
use App\\Controllers\\Admin\\DashboardController as AdminDashboardController;
use App\\Controllers\\Admin\\ProductsController as AdminProductsController;
use App\\Controllers\\Admin\\OrdersController as AdminOrdersController;

$router = new Router();

// Front routes
$router->get('/', [HomeController::class, 'index']);
$router->get('/product/{slug}', [ProductController::class, 'show']);

$router->get('/cart', [CartController::class, 'index']);
$router->post('/cart/add', [CartController::class, 'add']);
$router->post('/cart/update', [CartController::class, 'update']);
$router->post('/cart/remove', [CartController::class, 'remove']);
$router->post('/cart/clear', [CartController::class, 'clear']);

$router->get('/checkout', [CheckoutController::class, 'index']);
$router->post('/checkout', [CheckoutController::class, 'placeOrder']);

// Payment
$router->get('/payment/callback', [PaymentController::class, 'callback']);

// Order success
$router->get('/order/success/{id}', [CheckoutController::class, 'success']);

// Admin
$router->get('/admin', [AdminDashboardController::class, 'index']);
$router->get('/admin/login', [AdminAuthController::class, 'loginForm']);
$router->post('/admin/login', [AdminAuthController::class, 'login']);
$router->get('/admin/logout', [AdminAuthController::class, 'logout']);

$router->get('/admin/dashboard', [AdminDashboardController::class, 'index']);
$router->get('/admin/products', [AdminProductsController::class, 'index']);
$router->post('/admin/products/create', [AdminProductsController::class, 'create']);
$router->post('/admin/products/delete', [AdminProductsController::class, 'delete']);

$router->get('/admin/orders', [AdminOrdersController::class, 'index']);
$router->post('/admin/orders/status', [AdminOrdersController::class, 'updateStatus']);

$router->dispatch();
`
}

/* --------------- PHP Core --------------- */
function bootstrapPhp(): string {
  return `<?php
declare(strict_types=1);

spl_autoload_register(function ($class) {
    $prefix = 'App\\\\';
    $base_dir = __DIR__ . '/app/';
    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) return;
    $relative_class = substr($class, $len);
    $file = $base_dir . str_replace('\\\\', '/', $relative_class) . '.php';
    if (file_exists($file)) require $file;
});

require_once __DIR__ . '/app/Config.php';
require_once __DIR__ . '/app/Helpers.php';

App\\Hooks::init();
`
}

function configPhp(): string {
  return `<?php
declare(strict_types=1);

namespace App;

class Config
{
    // Database
    public const DB_HOST = '127.0.0.1';
    public const DB_NAME = 'dimashop';
    public const DB_USER = 'root';
    public const DB_PASS = '';
    public const DB_CHARSET = 'utf8mb4';

    // App
    public const APP_URL = 'https://dimashop.ir';
    public const APP_NAME = 'DIma Shop';
    public const APP_LOCALE = 'fa_IR';
    public const APP_TIMEZONE = 'Asia/Tehran';
    public const APP_DEBUG = true;
    public const CONTACT_EMAIL = 'info@dima.shop.ir';

    // CSRF
    public const CSRF_TOKEN_KEY = '_csrf';

    // Currency
    public const CURRENCY = 'Toman';
    public const ZARINPAL_AMOUNT_IN_RIAL = true;

    // ZarinPal
    public const ZARINPAL_MERCHANT_ID = 'XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX';
    public const ZARINPAL_SANDBOX = true;

    public static function zarinpalEndpoints(): array
    {
        $sandbox = self::ZARINPAL_SANDBOX;
        return [
            'request' => $sandbox
                ? 'https://sandbox.zarinpal.com/pg/v4/payment/request.json'
                : 'https://api.zarinpal.com/pg/v4/payment/request.json',
            'verify' => $sandbox
                ? 'https://sandbox.zarinpal.com/pg/v4/payment/verify.json'
                : 'https://api.zarinpal.com/pg/v4/payment/verify.json',
            'startpay' => $sandbox
                ? 'https://sandbox.zarinpal.com/pg/StartPay/'
                : 'https://www.zarinpal.com/pg/StartPay/',
        ];
    }
}
`
}

function databasePhp(): string {
  return `<?php
declare(strict_types=1);

namespace App;

use PDO;
use PDOException;

class Database
{
    private static ?PDO $pdo = null;

    public static function pdo(): PDO
    {
        if (self::$pdo === null) {
            $dsn = sprintf('mysql:host=%s;dbname=%s;charset=%s', Config::DB_HOST, Config::DB_NAME, Config::DB_CHARSET);
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ];
            try {
                self::$pdo = new PDO($dsn, Config::DB_USER, Config::DB_PASS, $options);
            } catch (PDOException $e) {
                if (Config::APP_DEBUG) {
                    die('DB Connection failed: ' . $e->getMessage());
                }
                die('DB Connection failed.');
            }
        }
        return self::$pdo;
    }
}
`
}

function routerPhp(): string {
  return `<?php
declare(strict_types=1);

namespace App;

class Router
{
    private array $routes = ['GET' => [], 'POST' => []];

    public function get(string $pattern, $handler): void
    {
        $this->routes['GET'][$pattern] = $handler;
    }
    public function post(string $pattern, $handler): void
    {
        $this->routes['POST'][$pattern] = $handler;
    }

    public function dispatch(): void
    {
        $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
        $uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?? '/';
        $uri = rtrim($uri, '/') ?: '/';

        foreach ($this->routes[$method] as $pattern => $handler) {
            $regex = preg_replace('#\\{([a-zA-Z_][a-zA-Z0-9_]*)\\}#', '(?P<$1>[^/]+)', $pattern);
            $regex = '#^' . rtrim($regex, '/') . '$#';
            if (preg_match($regex, $uri, $matches)) {
                $params = array_filter($matches, 'is_string', ARRAY_FILTER_USE_KEY);
                return $this->invoke($handler, $params);
            }
        }

        http_response_code(404);
        echo '404 Not Found';
    }

    private function invoke($handler, array $params): void
    {
        if (is_callable($handler)) {
            echo call_user_func_array($handler, $params);
            return;
        }
        if (is_array($handler) && count($handler) === 2) {
            [$class, $method] = $handler;
            $controller = new $class();
            echo call_user_func_array([$controller, $method], $params);
            return;
        }
        throw new \\RuntimeException('Invalid route handler');
    }
}
`
}

function controllerPhp(): string {
  return `<?php
declare(strict_types=1);

namespace App;

class Controller
{
    protected function view(string $template, array $data = []): string
    {
        extract($data);
        ob_start();
        include __DIR__ . "/Views/{$template}.php";
        return ob_get_clean();
    }

    protected function redirect(string $path): void
    {
        header('Location: ' . rtrim(Config::APP_URL, '/') . $path);
        exit;
    }

    protected function isPost(): bool
    {
        return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
    }

    protected function requireAdmin(): void
    {
        if (!isset($_SESSION['admin_id'])) {
            $this->redirect('/admin/login');
        }
    }
}
`
}

function modelPhp(): string {
  return `<?php
declare(strict_types=1);

namespace App;

use PDO;

abstract class Model
{
    protected PDO $db;
    public function __construct()
    {
        $this->db = Database::pdo();
    }
}
`
}

function helpersPhp(): string {
  return `<?php
declare(strict_types=1);

namespace App;

class Helpers
{
    public static function e(string $str): string
    {
        return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
    }
    public static function money(int|float $amount): string
    {
        $formatted = number_format($amount);
        return $formatted . ' ' . Config::CURRENCY;
    }
    public static function csrfToken(): string
    {
        if (!isset($_SESSION[Config::CSRF_TOKEN_KEY])) {
            $_SESSION[Config::CSRF_TOKEN_KEY] = bin2hex(random_bytes(32));
        }
        return $_SESSION[Config::CSRF_TOKEN_KEY];
    }
    public static function verifyCsrf(?string $token): bool
    {
        return isset($_SESSION[Config::CSRF_TOKEN_KEY]) && hash_equals($_SESSION[Config::CSRF_TOKEN_KEY], (string)$token);
    }

    public static function rialize(int $amountToman): int
    {
        return Config::ZARINPAL_AMOUNT_IN_RIAL ? $amountToman * 10 : $amountToman;
    }
}

class Hooks
{
    private static array $actions = [];
    private static array $filters = [];

    public static function init(): void {}

    public static function addAction(string $hook, callable $cb, int $prio = 10): void
    {
        self::$actions[$hook][$prio][] = $cb;
    }
    public static function doAction(string $hook, ...$args): void
    {
        if (!isset(self::$actions[$hook])) return;
        ksort(self::$actions[$hook]);
        foreach (self::$actions[$hook] as $cbs) {
            foreach ($cbs as $cb) $cb(...$args);
        }
    }

    public static function addFilter(string $hook, callable $cb, int $prio = 10): void
    {
        self::$filters[$hook][$prio][] = $cb;
    }
    public static function applyFilters(string $hook, $value, ...$args)
    {
        if (!isset(self::$filters[$hook])) return $value;
        ksort(self::$filters[$hook]);
        foreach (self::$filters[$hook] as $cbs) {
            foreach ($cbs as $cb) $value = $cb($value, ...$args);
        }
        return $value;
    }
}
`
}

/* --------------- Middleware --------------- */
function csrfPhp(): string {
  return `<?php
declare(strict_types=1);

namespace App\\Middleware;

use App\\Config;

class Csrf
{
    public static function requireToken(): void
    {
        $token = $_POST[Config::CSRF_TOKEN_KEY] ?? null;
        if (!\\App\\Helpers::verifyCsrf($token)) {
            http_response_code(400);
            exit('Invalid CSRF token');
        }
    }
}
`
}

function rateLimitPhp(): string {
  return `<?php
declare(strict_types=1);

namespace App\\Middleware;

class RateLimit {
  public static function allow(string $key, int $maxPerMinute = 30): bool {
    $dir = sys_get_temp_dir() . '/dima_rate';
    if (!is_dir($dir)) @mkdir($dir, 0700, true);
    $file = $dir . '/' . sha1($key . '|' . date('YmdHi')) . '.cnt';
    $count = 0;
    if (file_exists($file)) {
      $count = (int)file_get_contents($file);
    }
    $count++;
    file_put_contents($file, (string)$count, LOCK_EX);
    return $count <= $maxPerMinute;
  }
}
`
}

/* --------------- Services --------------- */
function cartPhp(): string {
  return `<?php
declare(strict_types=1);

namespace App\\Services;

use App\\Models\\Product;

class Cart
{
    private const KEY = '_cart';

    public static function items(): array
    {
        return $_SESSION[self::KEY]['items'] ?? [];
    }

    public static function add(int $productId, int $qty = 1, ?int $variationId = null): void
    {
        $key = $productId . ':' . ($variationId ?? 0);
        $items = self::items();
        if (isset($items[$key])) {
            $items[$key]['qty'] += $qty;
        } else {
            $items[$key] = ['product_id' => $productId, 'variation_id' => $variationId, 'qty' => $qty];
        }
        $_SESSION[self::KEY]['items'] = $items;
    }

    public static function update(string $key, int $qty): void
    {
        $items = self::items();
        if (isset($items[$key])) {
            $items[$key]['qty'] = max(1, $qty);
            $_SESSION[self::KEY]['items'] = $items;
        }
    }

    public static function remove(string $key): void
    {
        $items = self::items();
        unset($items[$key]);
        $_SESSION[self::KEY]['items'] = $items;
    }

    public static function clear(): void
    {
        $_SESSION[self::KEY] = ['items' => []];
    }

    public static function totals(): array
    {
        $subtotal = 0;
        $lines = [];
        foreach (self::items() as $key => $line) {
            $product = (new Product())->findById($line['product_id']);
            if (!$product) continue;
            $price = (int)($product['sale_price'] ?? $product['price']);
            $lineTotal = $price * $line['qty'];
            $subtotal += $lineTotal;
            $lines[] = [
                'key' => $key,
                'product' => $product,
                'qty' => $line['qty'],
                'price' => $price,
                'total' => $lineTotal,
            ];
        }
        $discount = 0;
        if (!empty($_SESSION['_coupon'])) {
            $coupon = $_SESSION['_coupon'];
            if ($coupon['type'] === 'percent') {
                $discount = (int)floor($subtotal * ($coupon['amount'] / 100));
            } else {
                $discount = (int)$coupon['amount'];
            }
            $discount = min($discount, $subtotal);
        }
        $tax = (int)floor(($subtotal - $discount) * 0.0);
        $shipping = (int)($_SESSION['_shipping_cost'] ?? 0);

        $total = max(0, $subtotal - $discount + $tax + $shipping);

        return compact('lines', 'subtotal', 'discount', 'tax', 'shipping', 'total');
    }
}
`
}

function zarinpalPhp(): string {
  return `<?php
declare(strict_types=1);

namespace App\\Services\\Payment;

use App\\Config;

class Zarinpal
{
    public static function requestPayment(int $amountToman, string $callbackUrl, string $description, ?string $email = null, ?string $mobile = null): array
    {
        $endpoints = Config::zarinpalEndpoints();
        $payload = [
            'merchant_id' => Config::ZARINPAL_MERCHANT_ID,
            'amount' => \\App\\Helpers::rialize($amountToman),
            'callback_url' => $callbackUrl,
            'description' => $description,
            'metadata' => [
                'email' => $email,
                'mobile' => $mobile,
            ],
        ];
        $resp = self::postJson($endpoints['request'], $payload);
        if (isset($resp['data']) && $resp['data']['code'] == 100) {
            $authority = $resp['data']['authority'];
            $startPay = $endpoints['startpay'] . $authority;
            return ['success' => true, 'authority' => $authority, 'start_pay' => $startPay];
        }
        $message = $resp['errors']['message'] ?? 'Payment request failed';
        return ['success' => false, 'message' => $message, 'response' => $resp];
    }

    public static function verifyPayment(int $amountToman, string $authority): array
    {
        $endpoints = Config::zarinpalEndpoints();
        $payload = [
            'merchant_id' => Config::ZARINPAL_MERCHANT_ID,
            'amount' => \\App\\Helpers::rialize($amountToman),
            'authority' => $authority,
        ];
        $resp = self::postJson($endpoints['verify'], $payload);
        if (isset($resp['data']) && $resp['data']['code'] == 100) {
            return ['success' => true, 'ref_id' => $resp['data']['ref_id']];
        }
        $message = $resp['errors']['message'] ?? 'Payment verify failed';
        return ['success' => false, 'message' => $message, 'response' => $resp];
    }

    private static function postJson(string $url, array $data): array
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
            CURLOPT_POSTFIELDS => json_encode($data, JSON_UNESCAPED_UNICODE),
            CURLOPT_TIMEOUT => 30,
        ]);
        $result = curl_exec($ch);
        $err = curl_error($ch);
        curl_close($ch);
        if ($err) {
            return ['errors' => ['message' => 'cURL error: ' . $err]];
        }
        $decoded = json_decode($result, true);
        return is_array($decoded) ? $decoded : ['errors' => ['message' => 'Invalid JSON response']];
    }
}
`
}

/* --------------- Models --------------- */
function modelProductPhp(): string {
  return `<?php
declare(strict_types=1);

namespace App\\Models;

use App\\Model;
use PDO;

class Product extends Model
{
    public function latest(int $limit = 12): array
    {
        $stmt = $this->db->prepare("SELECT * FROM products WHERE status='publish' ORDER BY id DESC LIMIT :lim");
        $stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function findBySlug(string $slug): ?array
    {
        $stmt = $this->db->prepare("SELECT * FROM products WHERE slug = :slug AND status='publish' LIMIT 1");
        $stmt->execute([':slug' => $slug]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function findById(int $id): ?array
    {
        $stmt = $this->db->prepare("SELECT * FROM products WHERE id = :id LIMIT 1");
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function create(array $data): int
    {
        $stmt = $this->db->prepare("INSERT INTO products (name, slug, description, price, sale_price, sku, stock_qty, status) VALUES (:name, :slug, :description, :price, :sale_price, :sku, :stock_qty, :status)");
        $stmt->execute([
            ':name' => $data['name'],
            ':slug' => $data['slug'],
            ':description' => $data['description'] ?? '',
            ':price' => (int)$data['price'],
            ':sale_price' => $data['sale_price'] !== '' ? (int)$data['sale_price'] : null,
            ':sku' => $data['sku'] ?? null,
            ':stock_qty' => (int)($data['stock_qty'] ?? 0),
            ':status' => $data['status'] ?? 'publish',
        ]);
        return (int)$this->db->lastInsertId();
    }

    public function delete(int $id): void
    {
        $stmt = $this->db->prepare("DELETE FROM products WHERE id=:id");
        $stmt->execute([':id' => $id]);
    }
}
`
}

function modelOrderPhp(): string {
  return `<?php
declare(strict_types=1);

namespace App\\Models;

use App\\Model;
use PDO;

class Order extends Model
{
    public function create(array $data, array $items): int
    {
        $this->db->beginTransaction();
        try {
            $stmt = $this->db->prepare("INSERT INTO orders (user_id, status, total, subtotal, discount, shipping_cost, tax, payment_status, payment_method, payment_ref, email, name, phone, address, city, postal_code) VALUES (:user_id, :status, :total, :subtotal, :discount, :shipping_cost, :tax, :payment_status, :payment_method, :payment_ref, :email, :name, :phone, :address, :city, :postal_code)");
            $stmt->execute([
                ':user_id' => $data['user_id'] ?? null,
                ':status' => $data['status'] ?? 'pending',
                ':total' => (int)$data['total'],
                ':subtotal' => (int)$data['subtotal'],
                ':discount' => (int)$data['discount'],
                ':shipping_cost' => (int)$data['shipping_cost'],
                ':tax' => (int)$data['tax'],
                ':payment_status' => $data['payment_status'] ?? 'unpaid',
                ':payment_method' => $data['payment_method'] ?? 'zarinpal',
                ':payment_ref' => $data['payment_ref'] ?? null,
                ':email' => $data['email'] ?? null,
                ':name' => $data['name'] ?? null,
                ':phone' => $data['phone'] ?? null,
                ':address' => $data['address'] ?? null,
                ':city' => $data['city'] ?? null,
                ':postal_code' => $data['postal_code'] ?? null,
            ]);
            $orderId = (int)$this->db->lastInsertId();

            $ins = $this->db->prepare("INSERT INTO order_items (order_id, product_id, variation_id, name, sku, price, qty, total) VALUES (:order_id, :product_id, :variation_id, :name, :sku, :price, :qty, :total)");
            foreach ($items as $it) {
                $ins->execute([
                    ':order_id' => $orderId,
                    ':product_id' => $it['product_id'],
                    ':variation_id' => $it['variation_id'] ?? null,
                    ':name' => $it['name'],
                    ':sku' => $it['sku'] ?? null,
                    ':price' => (int)$it['price'],
                    ':qty' => (int)$it['qty'],
                    ':total' => (int)$it['total'],
                ]);
            }

            $this->db->commit();
            return $orderId;
        } catch (\\Throwable $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    public function markPaid(int $orderId, string $refId): void
    {
        $stmt = $this->db->prepare("UPDATE orders SET payment_status='paid', status='processing', payment_ref=:ref WHERE id=:id");
        $stmt->execute([':ref' => $refId, ':id' => $orderId]);
    }

    public function find(int $id): ?array
    {
        $stmt = $this->db->prepare("SELECT * FROM orders WHERE id=:id");
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function all(int $limit = 50): array
    {
        $stmt = $this->db->prepare("SELECT * FROM orders ORDER BY id DESC LIMIT :lim");
        $stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}
`
}

function modelCouponPhp(): string {
  return `<?php
declare(strict_types=1);

namespace App\\Models;

use App\\Model;

class Coupon extends Model
{
    public function findActiveByCode(string $code): ?array
    {
        $stmt = $this->db->prepare("SELECT * FROM coupons WHERE code=:code AND (expires_at IS NULL OR expires_at > NOW()) AND (usage_limit IS NULL OR usage_limit > used) LIMIT 1");
        $stmt->execute([':code' => $code]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function incrementUse(int $id): void
    {
        $stmt = $this->db->prepare("UPDATE coupons SET used = used + 1 WHERE id=:id AND (usage_limit IS NULL OR used < usage_limit)");
        $stmt->execute([':id' => $id]);
    }
}
`
}

/* --------------- Controllers (Front) --------------- */
function homeControllerPhp(): string {
  return `<?php
declare(strict_types=1);

namespace App\\Controllers;

use App\\Controller;
use App\\Models\\Product;

class HomeController extends Controller
{
    public function index(): string
    {
        $products = (new Product())->latest(12);
        return $this->view('home', compact('products'));
    }
}
`
}

function productControllerPhp(): string {
  return `<?php
declare(strict_types=1);

namespace App\\Controllers;

use App\\Controller;
use App\\Models\\Product;

class ProductController extends Controller
{
    public function show(string $slug): string
    {
        $product = (new Product())->findBySlug($slug);
        if (!$product) {
            http_response_code(404);
            return 'محصول یافت نشد';
        }
        return $this->view('product-detail', compact('product'));
    }
}
`
}

function cartControllerPhp(): string {
  return `<?php
declare(strict_types=1);

namespace App\\Controllers;

use App\\Controller;
use App\\Middleware\\Csrf;
use App\\Services\\Cart;

class CartController extends Controller
{
    public function index(): string
    {
        $totals = Cart::totals();
        return $this->view('cart', compact('totals'));
    }

    public function add(): string
    {
        \\App\\Middleware\\Csrf::requireToken();
        $productId = (int)($_POST['product_id'] ?? 0);
        $qty = (int)($_POST['qty'] ?? 1);
        if ($productId > 0) {
            Cart::add($productId, max(1, $qty));
        }
        $this->redirect('/cart');
        return '';
    }

    public function update(): string
    {
        \\App\\Middleware\\Csrf::requireToken();
        foreach (($_POST['items'] ?? []) as $key => $qty) {
            Cart::update($key, (int)$qty);
        }
        $this->redirect('/cart');
        return '';
    }

    public function remove(): string
    {
        \\App\\Middleware\\Csrf::requireToken();
        $key = $_POST['key'] ?? '';
        Cart::remove($key);
        $this->redirect('/cart');
        return '';
    }

    public function clear(): string
    {
        \\App\\Middleware\\Csrf::requireToken();
        Cart::clear();
        $this->redirect('/cart');
        return '';
    }
}
`
}

function checkoutControllerPhp(): string {
  return `<?php
declare(strict_types=1);

namespace App\\Controllers;

use App\\Config;
use App\\Controller;
use App\\Models\\Order;
use App\\Services\\Cart;
use App\\Services\\Payment\\Zarinpal;

class CheckoutController extends Controller
{
    public function index(): string
    {
        $totals = Cart::totals();
        if ($totals['total'] <= 0) {
            $this->redirect('/cart');
        }
        return $this->view('checkout', compact('totals'));
    }

    public function placeOrder(): string
    {
        \\App\\Middleware\\Csrf::requireToken();
        $totals = Cart::totals();
        if ($totals['total'] <= 0) {
            $this->redirect('/cart');
        }

        $customer = [
            'email' => $_POST['email'] ?? null,
            'name' => $_POST['name'] ?? null,
            'phone' => $_POST['phone'] ?? null,
            'address' => $_POST['address'] ?? null,
            'city' => $_POST['city'] ?? null,
            'postal_code' => $_POST['postal_code'] ?? null,
        ];

        $items = [];
        foreach ($totals['lines'] as $line) {
            $p = $line['product'];
            $items[] = [
                'product_id' => (int)$p['id'],
                'variation_id' => null,
                'name' => $p['name'],
                'sku' => $p['sku'] ?? null,
                'price' => (int)$line['price'],
                'qty' => (int)$line['qty'],
                'total' => (int)$line['total'],
            ];
        }

        $orderData = array_merge($customer, [
            'subtotal' => $totals['subtotal'],
            'discount' => $totals['discount'],
            'tax' => $totals['tax'],
            'shipping_cost' => $totals['shipping'],
            'total' => $totals['total'],
            'payment_status' => 'unpaid',
            'payment_method' => 'zarinpal',
            'status' => 'pending',
        ]);

        $orderId = (new Order())->create($orderData, $items);

        $callback = rtrim(Config::APP_URL, '/') . '/payment/callback?order_id=' . $orderId;
        $desc = 'پرداخت سفارش #' . $orderId . ' در ' . Config::APP_NAME;
        $req = Zarinpal::requestPayment((int)$totals['total'], $callback, $desc, $customer['email'], $customer['phone']);

        if ($req['success']) {
            header('Location: ' . $req['start_pay']);
            exit;
        }

        return $this->view('checkout', [
            'totals' => $totals,
            'error' => 'خطا در ایجاد تراکنش: ' . ($req['message'] ?? 'نامشخص'),
        ]);
    }

    public function success(string $id): string
    {
        $order = (new \\App\\Models\\Order())->find((int)$id);
        if (!$order) {
            http_response_code(404);
            return 'سفارش یافت نشد';
        }
        return $this->view('order-success', compact('order'));
    }
}
`
}

function paymentControllerPhp(): string {
  return `<?php
declare(strict_types=1);

namespace App\\Controllers;

use App\\Controller;
use App\\Models\\Order;
use App\\Services\\Payment\\Zarinpal;

class PaymentController extends Controller
{
    public function callback(): string
    {
        $orderId = (int)($_GET['order_id'] ?? 0);
        $status = $_GET['Status'] ?? '';
        $authority = $_GET['Authority'] ?? '';
        if ($orderId <= 0 || !$authority) {
            return 'پارامترهای نامعتبر';
        }
        $orderModel = new Order();
        $order = $orderModel->find($orderId);
        if (!$order) {
            return 'سفارش یافت نشد';
        }

        if (strtolower($status) !== 'ok') {
            return 'پرداخت توسط کاربر لغو شد';
        }

        $verify = Zarinpal::verifyPayment((int)$order['total'], $authority);
        if (!empty($verify['success'])) {
            $orderModel->markPaid($orderId, (string)$verify['ref_id']);
            \\App\\Services\\Cart::clear();
            $this->redirect('/order/success/' . $orderId);
            return '';
        }

        if (isset($verify['response']['data']['code']) && (int)$verify['response']['data']['code'] === 101) {
            if ($order['payment_status'] !== 'paid') {
                $orderModel->markPaid($orderId, (string)($verify['response']['data']['ref_id'] ?? ''));
            }
            \\App\\Services\\Cart::clear();
            $this->redirect('/order/success/' . $orderId);
            return '';
        }

        return 'تایید پرداخت ناموفق بود: ' . ($verify['message'] ?? '');
    }
}
`
}

/* --------------- Controllers (Admin) --------------- */
function adminAuthControllerPhp(): string {
  return `<?php
declare(strict_types=1);

namespace App\\Controllers\\Admin;

use App\\Controller;
use App\\Database;

class AuthController extends Controller
{
    public function loginForm(): string
    {
        return $this->view('admin/login');
    }

    public function login(): string
    {
        \\App\\Middleware\\Csrf::requireToken();

        if (!\\App\\Middleware\\RateLimit::allow('login:' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'), 10)) {
            http_response_code(429);
            exit('درخواست‌های بیش‌ازحد. لطفا چند دقیقه دیگر تلاش کنید.');
        }

        $email = $_POST['email'] ?? '';
        $pass = $_POST['password'] ?? '';
        $db = Database::pdo();
        $stmt = $db->prepare("SELECT * FROM users WHERE email=:email AND role='admin' LIMIT 1");
        $stmt->execute([':email' => $email]);
        $user = $stmt->fetch();
        if ($user && password_verify($pass, $user['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['admin_id'] = $user['id'];
            $this->redirect('/admin/dashboard');
        }
        return $this->view('admin/login', ['error' => 'ورود نامعتبر']);
    }

    public function logout(): string
    {
        unset($_SESSION['admin_id']);
        $this->redirect('/admin/login');
        return '';
    }
}
`
}

function adminDashboardControllerPhp(): string {
  return `<?php
declare(strict_types=1);

namespace App\\Controllers\\Admin;

use App\\Controller;
use App\\Database;

class DashboardController extends Controller
{
    public function index(): string
    {
        $this->requireAdmin();
        $db = Database::pdo();
        $orders = (int)$db->query("SELECT COUNT(*) AS c FROM orders")->fetch()['c'];
        $products = (int)$db->query("SELECT COUNT(*) AS c FROM products")->fetch()['c'];
        $revenue = (int)$db->query("SELECT COALESCE(SUM(total),0) AS s FROM orders WHERE payment_status='paid'")->fetch()['s'];
        return $this->view('admin/dashboard', compact('orders', 'products', 'revenue'));
    }
}
`
}

function adminProductsControllerPhp(): string {
  return `<?php
declare(strict_types=1);

namespace App\\Controllers\\Admin;

use App\\Controller;
use App\\Models\\Product;

class ProductsController extends Controller
{
    public function index(): string
    {
        $this->requireAdmin();
        $products = (new Product())->latest(100);
        return $this->view('admin/products', compact('products'));
    }

    public function create(): string
    {
        $this->requireAdmin();
        \\App\\Middleware\\Csrf::requireToken();
        $data = [
            'name' => $_POST['name'] ?? '',
            'slug' => $_POST['slug'] ?? '',
            'description' => $_POST['description'] ?? '',
            'price' => (int)($_POST['price'] ?? 0),
            'sale_price' => $_POST['sale_price'] ?? '',
            'sku' => $_POST['sku'] ?? null,
            'stock_qty' => (int)($_POST['stock_qty'] ?? 0),
            'status' => $_POST['status'] ?? 'publish',
        ];
        (new Product())->create($data);
        $this->redirect('/admin/products');
        return '';
    }

    public function delete(): string
    {
        $this->requireAdmin();
        \\App\\Middleware\\Csrf::requireToken();
        $id = (int)($_POST['id'] ?? 0);
        if ($id > 0) {
            (new Product())->delete($id);
        }
        $this->redirect('/admin/products');
        return '';
    }
}
`
}

function adminOrdersControllerPhp(): string {
  return `<?php
declare(strict_types=1);

namespace App\\Controllers\\Admin;

use App\\Controller;
use App\\Models\\Order;

class OrdersController extends Controller
{
    public function index(): string
    {
        $this->requireAdmin();
        $orders = (new Order())->all(100);
        return $this->view('admin/orders', compact('orders'));
    }

    public function updateStatus(): string
    {
        $this->requireAdmin();
        \\App\\Middleware\\Csrf::requireToken();
        $id = (int)($_POST['id'] ?? 0);
        $status = $_POST['status'] ?? 'processing';
        if ($id > 0) {
            $db = \\App\\Database::pdo();
            $stmt = $db->prepare("UPDATE orders SET status=:st WHERE id=:id");
            $stmt->execute([':st' => $status, ':id' => $id]);
        }
        $this->redirect('/admin/orders');
        return '';
    }
}
`
}

/* --------------- Views (Front) --------------- */
function viewLayoutPhp(): string {
  return `<?php
use App\\Helpers;
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="utf-8">
  <title><?= Helpers::e(\\App\\Config::APP_NAME) ?></title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="canonical" href="https://dimashop.ir">
  <link rel="stylesheet" href="/assets/app.css">
</head>
<body class="bg-gray-50 text-gray-900">
  <header class="bg-white border-b sticky top-0 z-30">
    <div class="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
      <a href="/" class="flex items-center gap-2">
        <div class="w-8 h-8 bg-primary/10 text-primary rounded grid place-items-center font-bold">D</div>
        <span class="font-bold text-lg"><?= Helpers::e(\\App\\Config::APP_NAME) ?></span>
      </a>
      <nav class="flex items-center gap-4">
        <a class="text-sm hover:text-primary" href="/">خانه</a>
        <a class="text-sm hover:text-primary" href="/cart">سبد خرید</a>
        <a class="text-sm hover:text-primary" href="/admin">مدیریت</a>
      </nav>
    </div>
  </header>
  <main class="max-w-7xl mx-auto px-4 py-8">
    <?= $content ?? '' ?>
  </main>
  <footer class="bg-white border-t">
    <div class="max-w-7xl mx-auto px-4 py-6 text-sm text-gray-600 flex flex-col sm:flex-row gap-2 sm:gap-4 items-center justify-between">
      <span><?= Helpers::e(\\App\\Config::APP_NAME) ?> &copy; <?= date('Y') ?></span>
      <span>فروشگاه‌ساز PHP با پشتیبانی زرین‌پال</span>
      <a href="mailto:<?= Helpers::e(\\App\\Config::CONTACT_EMAIL) ?>" class="text-primary hover:underline">
        تماس: <?= Helpers::e(\\App\\Config::CONTACT_EMAIL) ?>
      </a>
    </div>
  </footer>
</body>
</html>
`
}

function viewHomePhp(): string {
  return `<?php
use App\\Helpers;
$this->layout = __DIR__ . '/layout.php';
ob_start();
?>
<h1 class="text-2xl font-bold mb-6">محصولات جدید</h1>
<div class="grid gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
  <?php foreach ($products as $p): ?>
    <div class="bg-white border rounded-xl overflow-hidden hover:shadow-sm transition">
      <div class="w-full h-40 bg-gray-100">
        <img alt="product" src="/placeholder.svg" class="w-full h-full object-cover">
      </div>
      <div class="p-4">
        <div class="font-semibold"><?= Helpers::e($p['name']) ?></div>
        <div class="text-gray-600 my-2"><?= Helpers::money((int)($p['sale_price'] ?: $p['price'])) ?></div>
        <a class="inline-flex items-center justify-center px-3 py-2 text-sm bg-primary text-white rounded-lg hover:bg-teal-600" href="/product/<?= Helpers::e($p['slug']) ?>">
          مشاهده
        </a>
      </div>
    </div>
  <?php endforeach; ?>
</div>
<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';
`
}

function viewProductDetailPhp(): string {
  return `<?php
use App\\Helpers;
$this->layout = __DIR__ . '/layout.php';
ob_start();
?>
<div class="grid gap-8 md:grid-cols-2">
  <div>
    <div class="w-full aspect-square bg-gray-100 rounded-xl overflow-hidden">
      <img alt="product" src="/placeholder.svg" class="w-full h-full object-cover">
    </div>
  </div>
  <div>
    <h1 class="text-2xl font-bold mb-3"><?= Helpers::e($product['name']) ?></h1>
    <div class="prose prose-sm max-w-none mb-4 prose-p:my-1">
      <?= nl2br(Helpers::e($product['description'])) ?>
    </div>
    <div class="text-xl font-extrabold mb-6"><?= Helpers::money((int)($product['sale_price'] ?: $product['price'])) ?></div>
    <form method="post" action="/cart/add" class="space-y-4">
      <input type="hidden" name="<?= \\App\\Config::CSRF_TOKEN_KEY ?>" value="<?= Helpers::csrfToken() ?>">
      <input type="hidden" name="product_id" value="<?= (int)$product['id'] ?>">
      <div>
        <label class="block text-sm mb-1">تعداد</label>
        <input type="number" name="qty" min="1" value="1" class="w-28 rounded-lg border-gray-300" />
      </div>
      <button class="inline-flex items-center justify-center px-4 py-2 bg-primary text-white rounded-lg hover:bg-teal-600">
        افزودن به سبد
      </button>
    </form>
  </div>
</div>
<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';
`
}

function viewCartPhp(): string {
  return `<?php
use App\\Helpers;
use App\\Services\\Cart;
$this->layout = __DIR__ . '/layout.php';
ob_start();
$totals = $totals ?? Cart::totals();
?>
<h1 class="text-2xl font-bold mb-6">سبد خرید</h1>

<?php if (empty($totals['lines'])): ?>
  <div class="rounded-lg border border-red-200 bg-red-50 text-red-700 p-4">سبد خرید شما خالی است.</div>
<?php else: ?>
<form method="post" action="/cart/update" class="space-y-4">
  <input type="hidden" name="<?= \\App\\Config::CSRF_TOKEN_KEY ?>" value="<?= Helpers::csrfToken() ?>">

  <div class="overflow-x-auto bg-white border rounded-xl">
    <table class="w-full text-sm">
      <thead class="bg-gray-50">
        <tr>
          <th class="px-3 py-2 text-right font-semibold">محصول</th>
          <th class="px-3 py-2 text-right font-semibold">قیمت</th>
          <th class="px-3 py-2 text-right font-semibold">تعداد</th>
          <th class="px-3 py-2 text-right font-semibold">مجموع</th>
          <th class="px-3 py-2"></th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($totals['lines'] as $line): $p=$line['product']; ?>
        <tr class="border-t">
          <td class="px-3 py-3"><?= Helpers::e($p['name']) ?></td>
          <td class="px-3 py-3"><?= Helpers::money($line['price']) ?></td>
          <td class="px-3 py-3">
            <input class="w-20 rounded-lg border-gray-300" type="number" name="items[<?= Helpers::e($line['key']) ?>]" value="<?= (int)$line['qty'] ?>" min="1">
          </td>
          <td class="px-3 py-3"><?= Helpers::money($line['total']) ?></td>
          <td class="px-3 py-3 text-left">
            <button
              class="inline-flex items-center justify-center px-3 py-1.5 text-xs bg-red-500 text-white rounded-lg hover:bg-red-600"
              type="submit"
              formaction="/cart/remove"
              name="key"
              value="<?= Helpers::e($line['key']) ?>"
              onclick="return confirm('حذف شود؟')"
            >
              حذف
            </button>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <div class="flex flex-col md:flex-row gap-6">
    <div class="md:w-1/2">
      <h3 class="font-semibold mb-2">کد تخفیف</h3>
      <div class="flex gap-2">
        <input type="text" name="coupon" class="flex-1 rounded-lg border-gray-300" placeholder="مثال: OFF10" />
        <span class="text-gray-500 text-sm self-center">اعمال کوپن در مرحله بعد</span>
      </div>
    </div>
    <div class="md:w-1/2">
      <div class="bg-white border rounded-xl p-4 space-y-2">
        <div class="flex items-center justify-between"><span>جمع جزء</span><span><?= Helpers::money($totals['subtotal']) ?></span></div>
        <div class="flex items-center justify-between"><span>تخفیف</span><span><?= Helpers::money($totals['discount']) ?></span></div>
        <div class="flex items-center justify-between"><span>حمل و نقل</span><span><?= Helpers::money($totals['shipping']) ?></span></div>
        <div class="flex items-center justify-between"><span>مالیات</span><span><?= Helpers::money($totals['tax']) ?></span></div>
        <hr class="my-2">
        <div class="flex items-center justify-between font-bold text-lg"><span>مبلغ قابل پرداخت</span><span><?= Helpers::money($totals['total']) ?></span></div>
        <div class="flex gap-2 pt-2">
          <button class="inline-flex items-center justify-center px-4 py-2 bg-gray-800 text-white rounded-lg hover:bg-gray-700" type="submit">به‌روزرسانی سبد</button>
          <a class="inline-flex items-center justify-center px-4 py-2 bg-primary text-white rounded-lg hover:bg-teal-600" href="/checkout">ادامه فرآیند خرید</a>
          <button class="inline-flex items-center justify-center px-4 py-2 bg-gray-100 text-gray-900 rounded-lg hover:bg-gray-200"
                  type="submit"
                  formaction="/cart/clear"
                  onclick="return confirm('سبد خالی شود؟')">
            خالی کردن
          </button>
        </div>
      </div>
    </div>
  </div>
</form>
<?php endif; ?>

<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';
`
}

function viewCheckoutPhp(): string {
  return `<?php
use App\\Helpers;
$this->layout = __DIR__ . '/layout.php';
ob_start();
?>
<h1 class="text-2xl font-bold mb-6">تسویه حساب</h1>
<?php if (!empty($error)): ?>
  <div class="rounded-lg border border-red-200 bg-red-50 text-red-700 p-4 mb-4"><?= Helpers::e($error) ?></div>
<?php endif; ?>

<div class="grid gap-6 md:grid-cols-2">
  <div class="bg-white border rounded-xl p-4">
    <form method="post" action="/checkout" class="space-y-4">
      <input type="hidden" name="<?= \\App\\Config::CSRF_TOKEN_KEY ?>" value="<?= Helpers::csrfToken() ?>">
      <div>
        <label class="block text-sm mb-1">نام و نام خانوادگی</label>
        <input name="name" required class="w-full rounded-lg border-gray-300" />
      </div>
      <div>
        <label class="block text-sm mb-1">ایمیل</label>
        <input name="email" type="email" class="w-full rounded-lg border-gray-300" />
      </div>
      <div>
        <label class="block text-sm mb-1">موبایل</label>
        <input name="phone" class="w-full rounded-lg border-gray-300" />
      </div>
      <div>
        <label class="block text-sm mb-1">آدرس</label>
        <textarea name="address" required class="w-full rounded-lg border-gray-300"></textarea>
      </div>
      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label class="block text-sm mb-1">شهر</label>
          <input name="city" required class="w-full rounded-lg border-gray-300" />
        </div>
        <div>
          <label class="block text-sm mb-1">کد پستی</label>
          <input name="postal_code" required class="w-full rounded-lg border-gray-300" />
        </div>
      </div>
      <button class="inline-flex items-center justify-center px-4 py-2 bg-primary text-white rounded-lg hover:bg-teal-600" type="submit">
        پرداخت با زرین‌پال
      </button>
    </form>
  </div>
  <div class="bg-white border rounded-xl p-4">
    <h3 class="font-semibold mb-3">سفارش شما</h3>
    <div class="space-y-2 text-sm">
      <div class="flex items-center justify-between"><span>جمع جزء</span><span><?= Helpers::money($totals['subtotal']) ?></span></div>
      <div class="flex items-center justify-between"><span>تخفیف</span><span><?= Helpers::money($totals['discount']) ?></span></div>
      <div class="flex items-center justify-between"><span>حمل و نقل</span><span><?= Helpers::money($totals['shipping']) ?></span></div>
      <div class="flex items-center justify-between"><span>مالیات</span><span><?= Helpers::money($totals['tax']) ?></span></div>
      <hr class="my-2">
      <div class="flex items-center justify-between font-bold text-lg"><span>مبلغ قابل پرداخت</span><span><?= Helpers::money($totals['total']) ?></span></div>
    </div>
  </div>
</div>
<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';
`
}

function viewOrderSuccessPhp(): string {
  return `<?php
use App\\Helpers;
$this->layout = __DIR__ . '/layout.php';
ob_start();
?>
<div class="bg-white border rounded-xl p-6 max-w-2xl mx-auto text-center">
  <div class="mx-auto w-16 h-16 rounded-full bg-green-100 text-green-600 grid place-items-center text-2xl mb-4">✓</div>
  <h1 class="text-2xl font-bold mb-2">پرداخت موفق</h1>
  <p class="text-gray-600 mb-4">سفارش شما با موفقیت ثبت شد.</p>
  <div class="grid gap-2 text-sm">
    <div>کد سفارش: <span class="font-mono">#<?= (int)$order['id'] ?></span></div>
    <div>وضعیت پرداخت: <?= Helpers::e($order['payment_status']) ?> | وضعیت سفارش: <?= Helpers::e($order['status']) ?></div>
    <div>کدرهگیری: <span class="font-mono"><?= Helpers::e((string)($order['payment_ref'] ?? '')) ?></span></div>
  </div>
  <a class="inline-flex items-center justify-center px-4 py-2 bg-primary text-white rounded-lg hover:bg-teal-600 mt-6" href="/">
    بازگشت به صفحه اصلی
  </a>
</div>
<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';
`
}

/* --------------- Views (Admin) --------------- */
function viewAdminLayoutPhp(): string {
  return `<?php
use App\\Helpers;
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="utf-8">
  <title>مدیریت - <?= Helpers::e(\\App\\Config::APP_NAME) ?></title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="/assets/app.css">
</head>
<body class="min-h-screen bg-slate-950 text-white">
  <header class="border-b border-slate-800">
    <div class="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
      <div class="flex items-center gap-3">
        <div class="w-8 h-8 rounded bg-primary/20 text-primary grid place-items-center font-bold">D</div>
        <span class="font-semibold"><?= Helpers::e(\\App\\Config::APP_NAME) ?> - مدیریت</span>
      </div>
      <nav class="flex items-center gap-4 text-sm">
        <a href="/admin/dashboard" class="hover:text-primary">داشبورد</a>
        <a href="/admin/products" class="hover:text-primary">محصولات</a>
        <a href="/admin/orders" class="hover:text-primary">سفارش‌ها</a>
        <a href="/admin/logout" class="hover:text-primary">خروج</a>
      </nav>
    </div>
  </header>
  <main class="max-w-7xl mx-auto px-4 py-8">
    <?= $content ?? '' ?>
  </main>
</body>
</html>
`
}

function viewAdminLoginPhp(): string {
  return `<?php
use App\\Helpers;
ob_start();
?>
<div class="max-w-md mx-auto mt-10 bg-slate-900 border border-slate-800 rounded-xl p-6">
  <h2 class="text-xl font-bold mb-4">ورود مدیر</h2>
  <?php if (!empty($error)): ?>
    <div class="mb-4 rounded-lg border border-red-400 bg-red-900/30 text-red-200 p-3"><?= Helpers::e($error) ?></div>
  <?php endif; ?>
  <form method="post" action="/admin/login" class="space-y-4">
    <input type="hidden" name="<?= \\App\\Config::CSRF_TOKEN_KEY ?>" value="<?= Helpers::csrfToken() ?>">
    <div>
      <label class="block text-sm mb-1">ایمیل</label>
      <input name="email" type="email" required class="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2" />
    </div>
    <div>
      <label class="block text-sm mb-1">رمز عبور</label>
      <input name="password" type="password" required class="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2" />
    </div>
    <button class="inline-flex items-center justify-center px-4 py-2 bg-primary text-white rounded-lg hover:bg-teal-600" type="submit">
      ورود
    </button>
  </form>
</div>
<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';
`
}

function viewAdminDashboardPhp(): string {
  return `<?php
use App\\Helpers;
ob_start();
?>
<h1 class="text-2xl font-bold mb-6">داشبورد</h1>
<div class="grid gap-4 sm:grid-cols-3">
  <div class="bg-slate-900 border border-slate-800 rounded-xl p-4">
    <div class="text-sm text-slate-400 mb-1">تعداد سفارش‌ها</div>
    <div class="text-2xl font-bold"><?= (int)$orders ?></div>
  </div>
  <div class="bg-slate-900 border border-slate-800 rounded-xl p-4">
    <div class="text-sm text-slate-400 mb-1">تعداد محصولات</div>
    <div class="text-2xl font-bold"><?= (int)$products ?></div>
  </div>
  <div class="bg-slate-900 border border-slate-800 rounded-xl p-4">
    <div class="text-sm text-slate-400 mb-1">درآمد (پرداخت‌شده)</div>
    <div class="text-2xl font-bold"><?= Helpers::money((int)$revenue) ?></div>
  </div>
</div>
<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';
`
}

function viewAdminProductsPhp(): string {
  return `<?php
use App\\Helpers;
ob_start();
?>
<h1 class="text-2xl font-bold mb-6">محصولات</h1>

<div class="bg-slate-900 border border-slate-800 rounded-xl p-6 mb-6">
  <h3 class="font-semibold mb-4">افزودن محصول</h3>
  <form method="post" action="/admin/products/create" class="space-y-4">
    <input type="hidden" name="<?= \\App\\Config::CSRF_TOKEN_KEY ?>" value="<?= Helpers::csrfToken() ?>">
    <div class="grid gap-4 sm:grid-cols-2">
      <div>
        <label class="block text-sm mb-1">نام</label>
        <input name="name" required class="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2" />
      </div>
      <div>
        <label class="block text-sm mb-1">اسلاگ</label>
        <input name="slug" required class="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2" />
      </div>
    </div>
    <div class="grid gap-4 sm:grid-cols-2">
      <div>
        <label class="block text-sm mb-1">قیمت</label>
        <input name="price" type="number" required class="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2" />
      </div>
      <div>
        <label class="block text-sm mb-1">قیمت فروش ویژه</label>
        <input name="sale_price" type="number" class="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2" />
      </div>
    </div>
    <div class="grid gap-4 sm:grid-cols-2">
      <div>
        <label class="block text-sm mb-1">SKU</label>
        <input name="sku" class="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2" />
      </div>
      <div>
        <label class="block text-sm mb-1">موجودی</label>
        <input name="stock_qty" type="number" class="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2" />
      </div>
    </div>
    <div>
      <label class="block text-sm mb-1">توضیحات</label>
      <textarea name="description" class="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2"></textarea>
    </div>
    <div>
      <label class="block text-sm mb-1">وضعیت</label>
      <select name="status" class="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2">
        <option value="publish">انتشار</option>
        <option value="draft">پیش‌نویس</option>
      </select>
    </div>
    <button class="inline-flex items-center justify-center px-4 py-2 bg-primary text-white rounded-lg hover:bg-teal-600" type="submit">
      ذخیره
    </button>
  </form>
</div>

<div class="overflow-x-auto bg-slate-900 border border-slate-800 rounded-xl">
  <table class="w-full text-sm">
    <thead class="bg-slate-800/60">
      <tr>
        <th class="px-3 py-2 text-right font-semibold">#</th>
        <th class="px-3 py-2 text-right font-semibold">نام</th>
        <th class="px-3 py-2 text-right font-semibold">قیمت</th>
        <th class="px-3 py-2 text-right font-semibold">وضعیت</th>
        <th class="px-3 py-2"></th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($products as $p): ?>
      <tr class="border-t border-slate-800">
        <td class="px-3 py-2"><?= (int)$p['id'] ?></td>
        <td class="px-3 py-2"><?= Helpers::e($p['name']) ?></td>
        <td class="px-3 py-2"><?= Helpers::money((int)($p['sale_price'] ?: $p['price'])) ?></td>
        <td class="px-3 py-2"><?= Helpers::e($p['status']) ?></td>
        <td class="px-3 py-2 text-left">
          <form method="post" action="/admin/products/delete" onsubmit="return confirm('حذف شود؟')" class="inline">
            <input type="hidden" name="<?= \\App\\Config::CSRF_TOKEN_KEY ?>" value="<?= Helpers::csrfToken() ?>">
            <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
            <button class="inline-flex items-center justify-center px-3 py-1.5 text-xs bg-red-500 text-white rounded-lg hover:bg-red-600">حذف</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';
`
}

function viewAdminOrdersPhp(): string {
  return `<?php
use App\\Helpers;
ob_start();
?>
<h1 class="text-2xl font-bold mb-6">سفارش‌ها</h1>
<div class="overflow-x-auto bg-slate-900 border border-slate-800 rounded-xl">
  <table class="w-full text-sm">
    <thead class="bg-slate-800/60">
      <tr>
        <th class="px-3 py-2 text-right font-semibold">#</th>
        <th class="px-3 py-2 text-right font-semibold">مبلغ</th>
        <th class="px-3 py-2 text-right font-semibold">وضعیت پرداخت</th>
        <th class="px-3 py-2 text-right font-semibold">وضعیت سفارش</th>
        <th class="px-3 py-2 text-right font-semibold">کدرهگیری</th>
        <th class="px-3 py-2"></th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($orders as $o): ?>
      <tr class="border-t border-slate-800">
        <td class="px-3 py-2">#<?= (int)$o['id'] ?></td>
        <td class="px-3 py-2"><?= Helpers::money((int)$o['total']) ?></td>
        <td class="px-3 py-2"><?= Helpers::e($o['payment_status']) ?></td>
        <td class="px-3 py-2"><?= Helpers::e($o['status']) ?></td>
        <td class="px-3 py-2"><?= Helpers::e((string)($o['payment_ref'] ?? '')) ?></td>
        <td class="px-3 py-2 text-left">
          <form method="post" action="/admin/orders/status" class="flex items-center gap-2">
            <input type="hidden" name="<?= \\App\\Config::CSRF_TOKEN_KEY ?>" value="<?= Helpers::csrfToken() ?>">
            <input type="hidden" name="id" value="<?= (int)$o['id'] ?>">
            <select name="status" class="rounded-lg border border-slate-700 bg-slate-950 px-2 py-1 text-xs">
              <option <?= $o['status']==='processing'?'selected':'' ?> value="processing">در حال انجام</option>
              <option <?= $o['status']==='completed'?'selected':'' ?> value="completed">تکمیل شده</option>
              <option <?= $o['status']==='cancelled'?'selected':'' ?> value="cancelled">لغو شده</option>
            </select>
            <button class="inline-flex items-center justify-center px-3 py-1.5 text-xs bg-primary text-white rounded-lg hover:bg-teal-600" type="submit">
              ذخیره
            </button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';
`
}
