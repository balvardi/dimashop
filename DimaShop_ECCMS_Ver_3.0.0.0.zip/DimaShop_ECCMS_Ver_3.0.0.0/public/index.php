<?php
declare(strict_types=1);

session_start();

require_once __DIR__ . '/../bootstrap.php';

use App\Router;
use App\Controllers\HomeController;
use App\Controllers\ProductController;
use App\Controllers\CartController;
use App\Controllers\CheckoutController;
use App\Controllers\PaymentController;
use App\Controllers\Admin\AuthController as AdminAuthController;
use App\Controllers\Admin\DashboardController as AdminDashboardController;
use App\Controllers\Admin\ProductsController as AdminProductsController;
use App\Controllers\Admin\OrdersController as AdminOrdersController;

$router = new Router();

// Front routes
$router->get('/', [HomeController::class, 'index']);
$router->get('/product/{slug}', [ProductController::class, 'show']);

$router->get('/cart', [CartController::class, 'index']);
$router->post('/cart/add', [CartController::class, 'add']);
$router->post('/cart/update', [CartController::class, 'update']);
$router->post('/cart/remove', [CartController::class, 'remove']);
$router->post('/cart/clear', [CartController::class, 'clear']);

$router->get('/checkout', [CheckoutController::class, 'index']);
$router->post('/checkout', [CheckoutController::class, 'placeOrder']);

// Payment
$router->get('/payment/callback', [PaymentController::class, 'callback']);

// Order success
$router->get('/order/success/{id}', [CheckoutController::class, 'success']);

// Admin
$router->get('/admin', [AdminDashboardController::class, 'index']);
$router->get('/admin/login', [AdminAuthController::class, 'loginForm']);
$router->post('/admin/login', [AdminAuthController::class, 'login']);
$router->get('/admin/logout', [AdminAuthController::class, 'logout']);

$router->get('/admin/dashboard', [AdminDashboardController::class, 'index']);
$router->get('/admin/products', [AdminProductsController::class, 'index']);
$router->post('/admin/products/create', [AdminProductsController::class, 'create']);
$router->post('/admin/products/delete', [AdminProductsController::class, 'delete']);

$router->get('/admin/orders', [AdminOrdersController::class, 'index']);
$router->post('/admin/orders/status', [AdminOrdersController::class, 'updateStatus']);

$router->dispatch();