-- Users
CREATE TABLE IF NOT EXISTS users (
id INT AUTO_INCREMENT PRIMARY KEY,
email VARCHAR(190) NOT NULL UNIQUE,
password_hash VARCHAR(255) NOT NULL,
role ENUM('admin','customer') NOT NULL DEFAULT 'customer',
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Products
CREATE TABLE IF NOT EXISTS products (
id INT AUTO_INCREMENT PRIMARY KEY,
name VARCHAR(255) NOT NULL,
slug VARCHAR(255) NOT NULL UNIQUE,
description TEXT,
price INT NOT NULL,
sale_price INT DEFAULT NULL,
sku VARCHAR(100) DEFAULT NULL,
stock_qty INT DEFAULT 0,
status ENUM('publish','draft') NOT NULL DEFAULT 'publish',
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Coupons
CREATE TABLE IF NOT EXISTS coupons (
id INT AUTO_INCREMENT PRIMARY KEY,
code VARCHAR(100) NOT NULL UNIQUE,
type ENUM('percent','fixed') NOT NULL DEFAULT 'percent',
amount INT NOT NULL,
usage_limit INT DEFAULT NULL,
used INT NOT NULL DEFAULT 0,
expires_at DATETIME DEFAULT NULL,
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Orders
CREATE TABLE IF NOT EXISTS orders (
id INT AUTO_INCREMENT PRIMARY KEY,
user_id INT DEFAULT NULL,
status VARCHAR(50) NOT NULL DEFAULT 'pending',
total INT NOT NULL,
subtotal INT NOT NULL,
discount INT NOT NULL DEFAULT 0,
shipping_cost INT NOT NULL DEFAULT 0,
tax INT NOT NULL DEFAULT 0,
payment_status VARCHAR(50) NOT NULL DEFAULT 'unpaid',
payment_method VARCHAR(50) DEFAULT 'zarinpal',
payment_ref VARCHAR(100) DEFAULT NULL,
email VARCHAR(190) DEFAULT NULL,
name VARCHAR(190) DEFAULT NULL,
phone VARCHAR(50) DEFAULT NULL,
address TEXT,
city VARCHAR(190) DEFAULT NULL,
postal_code VARCHAR(50) DEFAULT NULL,
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Order Items
CREATE TABLE IF NOT EXISTS order_items (
id INT AUTO_INCREMENT PRIMARY KEY,
order_id INT NOT NULL,
product_id INT NOT NULL,
variation_id INT DEFAULT NULL,
name VARCHAR(255) NOT NULL,
sku VARCHAR(100) DEFAULT NULL,
price INT NOT NULL,
qty INT NOT NULL,
total INT NOT NULL,
FOREIGN KEY (order_id) REFERENCES orders (id) ON DELETE CASCADE,
FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Admin seed (admin@example.com / Admin@12345)
INSERT INTO users (email, password_hash, role) VALUES
('admin@example.com', '$2y$10$N9k9F9mPd8j2z8m2B.8ZfO8M1zUq1eI3n7mTgG6s5m3rXJ0k1bC7G', 'admin');

-- Sample product
INSERT INTO products (name, slug, description, price, sale_price, sku, stock_qty, status) VALUES
('محصول نمونه', 'sample-product', 'توضیحات محصول نمونه', 200000, 180000, 'SKU-1', 10, 'publish');