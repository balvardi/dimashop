# Dima Shop (PHP + MySQL)

- نصب: Dimashop-installer.php را اجرا کنید.
- DocumentRoot روی public باشد یا از .htaccess روت استفاده کنید.
- Callback زرین‌پال: /payment/callback
