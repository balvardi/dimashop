<?php
declare(strict_types=1);

namespace App\Middleware;

class RateLimit {
public static function allow(string $key, int $maxPerMinute = 30): bool {
	$dir = sys_get_temp_dir() . '/Dima_rate';
	if (!is_dir($dir)) @mkdir($dir, 0700, true);
	$file = $dir . '/' . sha1($key . '|' . date('YmdHi')) . '.cnt';
	$count = 0;
	if (file_exists($file)) {
		$count = (int)file_get_contents($file);
	}
	$count++;
	file_put_contents($file, (string)$count, LOCK_EX);
	return $count <= $maxPerMinute;
}
}