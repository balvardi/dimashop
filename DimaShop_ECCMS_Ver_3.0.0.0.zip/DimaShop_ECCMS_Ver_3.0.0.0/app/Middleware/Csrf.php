<?php
declare(strict_types=1);

namespace App\Middleware;

use App\Config;

class Csrf
{
	public static function requireToken(): void
	{
			$token = $_POST[Config::CSRF_TOKEN_KEY] ?? null;
			if (!\App\Helpers::verifyCsrf($token)) {
					http_response_code(400);
					exit('Invalid CSRF token');
			}
	}
}