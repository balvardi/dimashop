<?php
use App\Helpers;
use App\Services\Cart;
$this->layout = __DIR__ . '/layout.php';
ob_start();
$totals = $totals ?? Cart::totals();
?>
<h1 class="text-2xl font-bold mb-6">سبد خرید</h1>

<?php if (empty($totals['lines'])): ?>
<div class="rounded-lg border border-red-200 bg-red-50 text-red-700 p-4">سبد خرید شما خالی است.</div>
<?php else: ?>
<form method="post" action="/cart/update" class="space-y-4">
<input type="hidden" name="<?= \App\Config::CSRF_TOKEN_KEY ?>" value="<?= Helpers::csrfToken() ?>">

<div class="overflow-x-auto bg-white border rounded-xl">
	<table class="w-full text-sm">
		<thead class="bg-gray-50">
			<tr>
				<th class="px-3 py-2 text-right font-semibold">محصول</th>
				<th class="px-3 py-2 text-right font-semibold">قیمت</th>
				<th class="px-3 py-2 text-right font-semibold">تعداد</th>
				<th class="px-3 py-2 text-right font-semibold">مجموع</th>
				<th class="px-3 py-2"></th>
			</tr>
		</thead>
		<tbody>
		<?php foreach ($totals['lines'] as $line): $p=$line['product']; ?>
			<tr class="border-t">
				<td class="px-3 py-3"><?= Helpers::e($p['name']) ?></td>
				<td class="px-3 py-3"><?= Helpers::money($line['price']) ?></td>
				<td class="px-3 py-3">
					<input class="w-20 rounded-lg border-gray-300" type="number" name="items[<?= Helpers::e($line['key']) ?>]" value="<?= (int)$line['qty'] ?>" min="1">
				</td>
				<td class="px-3 py-3"><?= Helpers::money($line['total']) ?></td>
				<td class="px-3 py-3 text-left">
					<button
						class="inline-flex items-center justify-center px-3 py-1.5 text-xs bg-red-500 text-white rounded-lg hover:bg-red-600"
						type="submit"
						formaction="/cart/remove"
						name="key"
						value="<?= Helpers::e($line['key']) ?>"
						onclick="return confirm('حذف شود؟')"
					>
						حذف
					</button>
				</td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</div>

<div class="flex flex-col md:flex-row gap-6">
	<div class="md:w-1/2">
		<h3 class="font-semibold mb-2">کد تخفیف</h3>
		<div class="flex gap-2">
			<input type="text" name="coupon" class="flex-1 rounded-lg border-gray-300" placeholder="مثال: OFF10" />
			<span class="text-gray-500 text-sm self-center">اعمال کوپن در مرحله بعد</span>
		</div>
	</div>
	<div class="md:w-1/2">
		<div class="bg-white border rounded-xl p-4 space-y-2">
			<div class="flex items-center justify-between"><span>جمع جزء</span><span><?= Helpers::money($totals['subtotal']) ?></span></div>
			<div class="flex items-center justify-between"><span>تخفیف</span><span><?= Helpers::money($totals['discount']) ?></span></div>
			<div class="flex items-center justify-between"><span>حمل و نقل</span><span><?= Helpers::money($totals['shipping']) ?></span></div>
			<div class="flex items-center justify-between"><span>مالیات</span><span><?= Helpers::money($totals['tax']) ?></span></div>
			<hr class="my-2">
			<div class="flex items-center justify-between font-bold text-lg"><span>مبلغ قابل پرداخت</span><span><?= Helpers::money($totals['total']) ?></span></div>
			<div class="flex gap-2 pt-2">
				<button class="inline-flex items-center justify-center px-4 py-2 bg-gray-800 text-white rounded-lg hover:bg-gray-700" type="submit">به‌روزرسانی سبد</button>
				<a class="inline-flex items-center justify-center px-4 py-2 bg-teal-600 text-white rounded-lg hover:bg-teal-700" href="/checkout">ادامه فرآیند خرید</a>
				<button class="inline-flex items-center justify-center px-4 py-2 bg-gray-100 text-gray-900 rounded-lg hover:bg-gray-200"
								type="submit"
								formaction="/cart/clear"
								onclick="return confirm('سبد خالی شود؟')">
					خالی کردن
				</button>
			</div>
		</div>
	</div>
</div>
</form>
<?php endif; ?>

<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';