<?php
use App\Helpers;
ob_start();
?>
<h1 class="text-2xl font-bold mb-6">سفارش‌ها</h1>
<div class="overflow-x-auto bg-slate-900 border border-slate-800 rounded-xl">
<table class="w-full text-sm">
	<thead class="bg-slate-800/60">
		<tr>
			<th class="px-3 py-2 text-right font-semibold">#</th>
			<th class="px-3 py-2 text-right font-semibold">مبلغ</th>
			<th class="px-3 py-2 text-right font-semibold">وضعیت پرداخت</th>
			<th class="px-3 py-2 text-right font-semibold">وضعیت سفارش</th>
			<th class="px-3 py-2 text-right font-semibold">کدرهگیری</th>
			<th class="px-3 py-2"></th>
		</tr>
	</thead>
	<tbody>
		<?php foreach ($orders as $o): ?>
		<tr class="border-t border-slate-800">
			<td class="px-3 py-2">#<?= (int)$o['id'] ?></td>
			<td class="px-3 py-2"><?= Helpers::money((int)$o['total']) ?></td>
			<td class="px-3 py-2"><?= Helpers::e($o['payment_status']) ?></td>
			<td class="px-3 py-2"><?= Helpers::e($o['status']) ?></td>
			<td class="px-3 py-2"><?= Helpers::e((string)($o['payment_ref'] ?? '')) ?></td>
			<td class="px-3 py-2 text-left">
				<form method="post" action="/admin/orders/status" class="flex items-center gap-2">
					<input type="hidden" name="<?= \App\Config::CSRF_TOKEN_KEY ?>" value="<?= Helpers::csrfToken() ?>">
					<input type="hidden" name="id" value="<?= (int)$o['id'] ?>">
					<select name="status" class="rounded-lg border border-slate-700 bg-slate-950 px-2 py-1 text-xs">
						<option <?= $o['status']==='processing'?'selected':'' ?> value="processing">در حال انجام</option>
						<option <?= $o['status']==='completed'?'selected':'' ?> value="completed">تکمیل شده</option>
						<option <?= $o['status']==='cancelled'?'selected':'' ?> value="cancelled">لغو شده</option>
					</select>
					<button class="inline-flex items-center justify-center px-3 py-1.5 text-xs bg-teal-600 text-white rounded-lg hover:bg-teal-700" type="submit">
						ذخیره
					</button>
				</form>
			</td>
		</tr>
		<?php endforeach; ?>
	</tbody>
</table>
</div>
<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';