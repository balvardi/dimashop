<?php
use App\Helpers;
ob_start();
?>
<h1 class="text-2xl font-bold mb-6">محصولات</h1>

<div class="bg-slate-900 border border-slate-800 rounded-xl p-6 mb-6">
<h3 class="font-semibold mb-4">افزودن محصول</h3>
<form method="post" action="/admin/products/create" class="space-y-4">
	<input type="hidden" name="<?= \App\Config::CSRF_TOKEN_KEY ?>" value="<?= Helpers::csrfToken() ?>">
	<div class="grid gap-4 sm:grid-cols-2">
		<div>
			<label class="block text-sm mb-1">نام</label>
			<input name="name" required class="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2" />
		</div>
		<div>
			<label class="block text-sm mb-1">اسلاگ</label>
			<input name="slug" required class="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2" />
		</div>
	</div>
	<div class="grid gap-4 sm:grid-cols-2">
		<div>
			<label class="block text-sm mb-1">قیمت</label>
			<input name="price" type="number" required class="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2" />
		</div>
		<div>
			<label class="block text-sm mb-1">قیمت فروش ویژه</label>
			<input name="sale_price" type="number" class="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2" />
		</div>
	</div>
	<div class="grid gap-4 sm:grid-cols-2">
		<div>
			<label class="block text-sm mb-1">SKU</label>
			<input name="sku" class="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2" />
		</div>
		<div>
			<label class="block text-sm mb-1">موجودی</label>
			<input name="stock_qty" type="number" class="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2" />
		</div>
	</div>
	<div>
		<label class="block text-sm mb-1">توضیحات</label>
		<textarea name="description" class="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2"></textarea>
	</div>
	<div>
		<label class="block text-sm mb-1">وضعیت</label>
		<select name="status" class="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2">
			<option value="publish">انتشار</option>
			<option value="draft">پیش‌نویس</option>
		</select>
	</div>
	<button class="inline-flex items-center justify-center px-4 py-2 bg-teal-600 text-white rounded-lg hover:bg-teal-700" type="submit">
		ذخیره
	</button>
</form>
</div>

<div class="overflow-x-auto bg-slate-900 border border-slate-800 rounded-xl">
<table class="w-full text-sm">
	<thead class="bg-slate-800/60">
		<tr>
			<th class="px-3 py-2 text-right font-semibold">#</th>
			<th class="px-3 py-2 text-right font-semibold">نام</th>
			<th class="px-3 py-2 text-right font-semibold">قیمت</th>
			<th class="px-3 py-2 text-right font-semibold">وضعیت</th>
			<th class="px-3 py-2"></th>
		</tr>
	</thead>
	<tbody>
	<?php foreach ($products as $p): ?>
		<tr class="border-t border-slate-800">
			<td class="px-3 py-2">#<?= (int)$p['id'] ?></td>
			<td class="px-3 py-2"><?= Helpers::e($p['name']) ?></td>
			<td class="px-3 py-2"><?= Helpers::money((int)($p['sale_price'] ?: $p['price'])) ?></td>
			<td class="px-3 py-2"><?= Helpers::e($p['status']) ?></td>
			<td class="px-3 py-2 text-left">
				<form method="post" action="/admin/products/delete" onsubmit="return confirm('حذف شود؟')" class="inline">
					<input type="hidden" name="<?= \App\Config::CSRF_TOKEN_KEY ?>" value="<?= Helpers::csrfToken() ?>">
					<input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
					<button class="inline-flex items-center justify-center px-3 py-1.5 text-xs bg-red-500 text-white rounded-lg hover:bg-red-600">حذف</button>
				</form>
			</td>
		</tr>
	<?php endforeach; ?>
	</tbody>
</table>
</div>
<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';