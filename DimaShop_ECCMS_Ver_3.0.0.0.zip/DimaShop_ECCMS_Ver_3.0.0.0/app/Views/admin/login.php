<?php
use App\Helpers;
ob_start();
?>
<div class="max-w-md mx-auto mt-10 bg-slate-900 border border-slate-800 rounded-xl p-6">
<h2 class="text-xl font-bold mb-4">ورود مدیر</h2>
<?php if (!empty($error)): ?>
	<div class="mb-4 rounded-lg border border-red-400 bg-red-900/30 text-red-200 p-3"><?= Helpers::e($error) ?></div>
<?php endif; ?>
<form method="post" action="/admin/login" class="space-y-4">
	<input type="hidden" name="<?= \App\Config::CSRF_TOKEN_KEY ?>" value="<?= Helpers::csrfToken() ?>">
	<div>
		<label class="block text-sm mb-1">ایمیل</label>
		<input name="email" type="email" required class="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2" />
	</div>
	<div>
		<label class="block text-sm mb-1">رمز عبور</label>
		<input name="password" type="password" required class="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2" />
	</div>
	<button class="inline-flex items-center justify-center px-4 py-2 bg-teal-600 text-white rounded-lg hover:bg-teal-700" type="submit">
		ورود
	</button>
</form>
</div>
<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';