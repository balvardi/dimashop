<?php
use App\Helpers;
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<title>مدیریت - <?= Helpers::e(\App\Config::APP_NAME) ?></title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-slate-950 text-white">
<header class="border-b border-slate-800">
	<div class="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
		<div class="flex items-center gap-3">
			<div class="w-8 h-8 rounded bg-teal-400/20 text-teal-400 grid place-items-center font-bold">D</div>
			<span class="font-semibold"><?= Helpers::e(\App\Config::APP_NAME) ?> - مدیریت</span>
		</div>
		<nav class="flex items-center gap-4 text-sm">
			<a href="/admin/dashboard" class="hover:text-teal-400">داشبورد</a>
			<a href="/admin/products" class="hover:text-teal-400">محصولات</a>
			<a href="/admin/orders" class="hover:text-teal-400">سفارش‌ها</a>
			<a href="/admin/logout" class="hover:text-teal-400">خروج</a>
		</nav>
	</div>
</header>
<main class="max-w-7xl mx-auto px-4 py-8">
	<?= $content ?? '' ?>
</main>
</body>
</html>