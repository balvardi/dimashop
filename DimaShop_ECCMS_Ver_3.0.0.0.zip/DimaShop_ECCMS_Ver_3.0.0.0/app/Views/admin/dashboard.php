<?php
use App\Helpers;
ob_start();
?>
<h1 class="text-2xl font-bold mb-6">داشبورد</h1>
<div class="grid gap-4 sm:grid-cols-3">
<div class="bg-slate-900 border border-slate-800 rounded-xl p-4">
	<div class="text-sm text-slate-400 mb-1">تعداد سفارش‌ها</div>
	<div class="text-2xl font-bold"><?= (int)$orders ?></div>
</div>
<div class="bg-slate-900 border border-slate-800 rounded-xl p-4">
	<div class="text-sm text-slate-400 mb-1">تعداد محصولات</div>
	<div class="text-2xl font-bold"><?= (int)$products ?></div>
</div>
<div class="bg-slate-900 border border-slate-800 rounded-xl p-4">
	<div class="text-sm text-slate-400 mb-1">درآمد (پرداخت‌شده)</div>
	<div class="text-2xl font-bold"><?= Helpers::money((int)$revenue) ?></div>
</div>
</div>
<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';