<?php
use App\Helpers;
$this->layout = __DIR__ . '/layout.php';
ob_start();
?>
<h1 class="text-2xl font-bold mb-6">تسویه حساب</h1>
<?php if (!empty($error)): ?>
<div class="rounded-lg border border-red-200 bg-red-50 text-red-700 p-4 mb-4"><?= Helpers::e($error) ?></div>
<?php endif; ?>

<div class="grid gap-6 md:grid-cols-2">
<div class="bg-white border rounded-xl p-4">
	<form method="post" action="/checkout" class="space-y-4">
		<input type="hidden" name="<?= \App\Config::CSRF_TOKEN_KEY ?>" value="<?= Helpers::csrfToken() ?>">
		<div>
			<label class="block text-sm mb-1">نام و نام خانوادگی</label>
			<input name="name" required class="w-full rounded-lg border-gray-300" />
		</div>
		<div>
			<label class="block text-sm mb-1">ایمیل</label>
			<input name="email" type="email" class="w-full rounded-lg border-gray-300" />
		</div>
		<div>
			<label class="block text-sm mb-1">موبایل</label>
			<input name="phone" class="w-full rounded-lg border-gray-300" />
		</div>
		<div>
			<label class="block text-sm mb-1">آدرس</label>
			<textarea name="address" required class="w-full rounded-lg border-gray-300"></textarea>
		</div>
		<div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
			<div>
				<label class="block text-sm mb-1">شهر</label>
				<input name="city" required class="w-full rounded-lg border-gray-300" />
			</div>
			<div>
				<label class="block text-sm mb-1">کد پستی</label>
				<input name="postal_code" required class="w-full rounded-lg border-gray-300" />
			</div>
		</div>
		<button class="inline-flex items-center justify-center px-4 py-2 bg-teal-600 text-white rounded-lg hover:bg-teal-700" type="submit">
			پرداخت با زرین‌پال
		</button>
	</form>
</div>
<div class="bg-white border rounded-xl p-4">
	<h3 class="font-semibold mb-3">سفارش شما</h3>
	<div class="space-y-2 text-sm">
		<div class="flex items-center justify-between"><span>جمع جزء</span><span><?= Helpers::money($totals['subtotal']) ?></span></div>
		<div class="flex items-center justify-between"><span>تخفیف</span><span><?= Helpers::money($totals['discount']) ?></span></div>
		<div class="flex items-center justify-between"><span>حمل و نقل</span><span><?= Helpers::money($totals['shipping']) ?></span></div>
		<div class="flex items-center justify-between"><span>مالیات</span><span><?= Helpers::money($totals['tax']) ?></span></div>
		<hr class="my-2">
		<div class="flex items-center justify-between font-bold text-lg"><span>مبلغ قابل پرداخت</span><span><?= Helpers::money($totals['total']) ?></span></div>
	</div>
</div>
</div>
<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';