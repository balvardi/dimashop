<?php
use App\Helpers;
$this->layout = __DIR__ . '/layout.php';
ob_start();
?>
<h1 class="text-2xl font-bold mb-6">محصولات جدید</h1>
<div class="grid gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
<?php foreach ($products as $p): ?>
	<div class="bg-white border rounded-xl overflow-hidden hover:shadow-sm transition">
		<div class="w-full h-40 bg-gray-100">
			<img alt="product" src="/placeholder.svg" class="w-full h-full object-cover">
		</div>
		<div class="p-4">
			<div class="font-semibold"><?= Helpers::e($p['name']) ?></div>
			<div class="text-gray-600 my-2"><?= Helpers::money((int)($p['sale_price'] ?: $p['price'])) ?></div>
			<a class="inline-flex items-center justify-center px-3 py-2 text-sm bg-teal-600 text-white rounded-lg hover:bg-teal-700" href="/product/<?= Helpers::e($p['slug']) ?>">
				مشاهده
			</a>
		</div>
	</div>
<?php endforeach; ?>
</div>
<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';