<?php
use App\Helpers;
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<title><?= Helpers::e(\App\Config::APP_NAME) ?></title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="canonical" href="<?= Helpers::e(\App\Config::APP_URL) ?>">
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 text-gray-900">
<header class="bg-white border-b sticky top-0 z-30">
	<div class="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
		<a href="/" class="flex items-center gap-2">
			<div class="w-8 h-8 bg-teal-100 text-teal-600 rounded grid place-items-center font-bold">D</div>
			<span class="font-bold text-lg"><?= Helpers::e(\App\Config::APP_NAME) ?></span>
		</a>
		<nav class="flex items-center gap-4">
			<a class="text-sm hover:text-teal-600" href="/">خانه</a>
			<a class="text-sm hover:text-teal-600" href="/cart">سبد خرید</a>
			<a class="text-sm hover:text-teal-600" href="/admin">مدیریت</a>
		</nav>
	</div>
</header>
<main class="max-w-7xl mx-auto px-4 py-8">
	<?= $content ?? '' ?>
</main>
<footer class="bg-white border-t">
	<div class="max-w-7xl mx-auto px-4 py-6 text-sm text-gray-600 flex flex-col sm:flex-row gap-2 sm:gap-4 items-center justify-between">
		<span><?= Helpers::e(\App\Config::APP_NAME) ?> &copy; <?= date('Y') ?></span>
		<span>فروشگاه‌ساز PHP با پشتیبانی زرین‌پال</span>
		<a href="mailto:<?= Helpers::e(\App\Config::CONTACT_EMAIL) ?>" class="text-teal-600 hover:underline">
			تماس: <?= Helpers::e(\App\Config::CONTACT_EMAIL) ?>
		</a>
	</div>
</footer>
</body>
</html>