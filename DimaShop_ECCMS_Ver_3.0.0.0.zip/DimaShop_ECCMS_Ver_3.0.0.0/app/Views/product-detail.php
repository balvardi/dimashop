<?php
use App\Helpers;
$this->layout = __DIR__ . '/layout.php';
ob_start();
?>
<div class="grid gap-8 md:grid-cols-2">
<div>
	<div class="w-full aspect-square bg-gray-100 rounded-xl overflow-hidden">
		<img alt="product" src="/placeholder.svg" class="w-full h-full object-cover">
	</div>
</div>
<div>
	<h1 class="text-2xl font-bold mb-3"><?= Helpers::e($product['name']) ?></h1>
	<div class="prose prose-sm max-w-none mb-4 prose-p:my-1">
		<?= nl2br(Helpers::e($product['description'])) ?>
	</div>
	<div class="text-xl font-extrabold mb-6"><?= Helpers::money((int)($product['sale_price'] ?: $product['price'])) ?></div>
	<form method="post" action="/cart/add" class="space-y-4">
		<input type="hidden" name="<?= \App\Config::CSRF_TOKEN_KEY ?>" value="<?= Helpers::csrfToken() ?>">
		<input type="hidden" name="product_id" value="<?= (int)$product['id'] ?>">
		<div>
			<label class="block text-sm mb-1">تعداد</label>
			<input type="number" name="qty" min="1" value="1" class="w-28 rounded-lg border-gray-300" />
		</div>
		<button class="inline-flex items-center justify-center px-4 py-2 bg-teal-600 text-white rounded-lg hover:bg-teal-700">
			افزودن به سبد
		</button>
	</form>
</div>
</div>
<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';