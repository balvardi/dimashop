<?php
use App\Helpers;
$this->layout = __DIR__ . '/layout.php';
ob_start();
?>
<div class="bg-white border rounded-xl p-6 max-w-2xl mx-auto text-center">
<div class="mx-auto w-16 h-16 rounded-full bg-green-100 text-green-600 grid place-items-center text-2xl mb-4">✓</div>
<h1 class="text-2xl font-bold mb-2">پرداخت موفق</h1>
<p class="text-gray-600 mb-4">سفارش شما با موفقیت ثبت شد.</p>
<div class="grid gap-2 text-sm">
	<div>کد سفارش: <span class="font-mono">#<?= (int)$order['id'] ?></span></div>
	<div>وضعیت پرداخت: <?= Helpers::e($order['payment_status']) ?> | وضعیت سفارش: <?= Helpers::e($order['status']) ?></div>
	<div>کدرهگیری: <span class="font-mono"><?= Helpers::e((string)($order['payment_ref'] ?? '')) ?></span></div>
</div>
<a class="inline-flex items-center justify-center px-4 py-2 bg-teal-600 text-white rounded-lg hover:bg-teal-700 mt-6" href="/">
	بازگشت به صفحه اصلی
</a>
</div>
<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';