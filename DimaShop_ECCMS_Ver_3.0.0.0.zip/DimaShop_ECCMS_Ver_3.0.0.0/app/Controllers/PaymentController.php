<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Controller;
use App\Models\Order;
use App\Services\Payment\Zarinpal;

class PaymentController extends Controller
{
	public function callback(): string
	{
			$orderId = (int)($_GET['order_id'] ?? 0);
			$status = $_GET['Status'] ?? '';
			$authority = $_GET['Authority'] ?? '';
			if ($orderId <= 0 || !$authority) {
					return 'پارامترهای نامعتبر';
			}
			$orderModel = new Order();
			$order = $orderModel->find($orderId);
			if (!$order) {
					return 'سفارش یافت نشد';
			}

			if (strtolower($status) !== 'ok') {
					return 'پرداخت توسط کاربر لغو شد';
			}

			$verify = Zarinpal::verifyPayment((int)$order['total'], $authority);
			if (!empty($verify['success'])) {
					$orderModel->markPaid($orderId, (string)$verify['ref_id']);
					\App\Services\Cart::clear();
					$this->redirect('/order/success/' . $orderId);
					return '';
			}

			if (isset($verify['response']['data']['code']) && (int)$verify['response']['data']['code'] === 101) {
					if ($order['payment_status'] !== 'paid') {
							$orderModel->markPaid($orderId, (string)($verify['response']['data']['ref_id'] ?? ''));
					}
					\App\Services\Cart::clear();
					$this->redirect('/order/success/' . $orderId);
					return '';
			}

			return 'تایید پرداخت ناموفق بود: ' . ($verify['message'] ?? '');
	}
}