<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controller;
use App\Models\Product;

class ProductsController extends Controller
{
	public function index(): string
	{
			$this->requireAdmin();
			$products = (new Product())->latest(100);
			return $this->view('admin/products', compact('products'));
	}

	public function create(): string
	{
			$this->requireAdmin();
			\App\Middleware\Csrf::requireToken();
			$data = [
					'name' => $_POST['name'] ?? '',
					'slug' => $_POST['slug'] ?? '',
					'description' => $_POST['description'] ?? '',
					'price' => (int)($_POST['price'] ?? 0),
					'sale_price' => $_POST['sale_price'] ?? '',
					'sku' => $_POST['sku'] ?? null,
					'stock_qty' => (int)($_POST['stock_qty'] ?? 0),
					'status' => $_POST['status'] ?? 'publish',
			];
			(new Product())->create($data);
			$this->redirect('/admin/products');
			return '';
	}

	public function delete(): string
	{
			$this->requireAdmin();
			\App\Middleware\Csrf::requireToken();
			$id = (int)($_POST['id'] ?? 0);
			if ($id > 0) {
					(new Product())->delete($id);
			}
			$this->redirect('/admin/products');
			return '';
	}
}