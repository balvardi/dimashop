<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controller;
use App\Database;

class AuthController extends Controller
{
	public function loginForm(): string
	{
			return $this->view('admin/login');
	}

	public function login(): string
	{
			\App\Middleware\Csrf::requireToken();

			if (!\App\Middleware\RateLimit::allow('login:' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'), 10)) {
					http_response_code(429);
					exit('درخواست‌های بیش‌ازحد. لطفا چند دقیقه دیگر تلاش کنید.');
			}

			$email = $_POST['email'] ?? '';
			$pass = $_POST['password'] ?? '';
			$db = Database::pdo();
			$stmt = $db->prepare("SELECT * FROM users WHERE email=:email AND role='admin' LIMIT 1");
			$stmt->execute([':email' => $email]);
			$user = $stmt->fetch();
			if ($user && password_verify($pass, $user['password_hash'])) {
					session_regenerate_id(true);
					$_SESSION['admin_id'] = $user['id'];
					$this->redirect('/admin/dashboard');
			}
			return $this->view('admin/login', ['error' => 'ورود نامعتبر']);
	}

	public function logout(): string
	{
			unset($_SESSION['admin_id']);
			$this->redirect('/admin/login');
			return '';
	}
}