<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controller;
use App\Models\Order;

class OrdersController extends Controller
{
	public function index(): string
	{
			$this->requireAdmin();
			$orders = (new Order())->all(100);
			return $this->view('admin/orders', compact('orders'));
	}

	public function updateStatus(): string
	{
			$this->requireAdmin();
			\App\Middleware\Csrf::requireToken();
			$id = (int)($_POST['id'] ?? 0);
			$status = $_POST['status'] ?? 'processing';
			if ($id > 0) {
					$db = \App\Database::pdo();
					$stmt = $db->prepare("UPDATE orders SET status=:st WHERE id=:id");
					$stmt->execute([':st' => $status, ':id' => $id]);
			}
			$this->redirect('/admin/orders');
			return '';
	}
}