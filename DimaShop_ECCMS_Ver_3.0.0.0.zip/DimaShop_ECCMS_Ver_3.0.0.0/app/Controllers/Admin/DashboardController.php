<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controller;
use App\Database;

class DashboardController extends Controller
{
	public function index(): string
	{
			$this->requireAdmin();
			$db = Database::pdo();
			$orders = (int)$db->query("SELECT COUNT(*) AS c FROM orders")->fetch()['c'];
			$products = (int)$db->query("SELECT COUNT(*) AS c FROM products")->fetch()['c'];
			$revenue = (int)$db->query("SELECT COALESCE(SUM(total),0) AS s FROM orders WHERE payment_status='paid'")->fetch()['s'];
			return $this->view('admin/dashboard', compact('orders', 'products', 'revenue'));
	}
}