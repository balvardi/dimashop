<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Controller;
use App\Models\Product;

class ProductController extends Controller
{
	public function show(string $slug): string
	{
			$product = (new Product())->findBySlug($slug);
			if (!$product) {
					http_response_code(404);
					return 'محصول یافت نشد';
			}
			return $this->view('product-detail', compact('product'));
	}
}