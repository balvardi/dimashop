<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Controller;
use App\Middleware\Csrf;
use App\Services\Cart;

class CartController extends Controller
{
	public function index(): string
	{
			$totals = Cart::totals();
			return $this->view('cart', compact('totals'));
	}

	public function add(): string
	{
			\App\Middleware\Csrf::requireToken();
			$productId = (int)($_POST['product_id'] ?? 0);
			$qty = (int)($_POST['qty'] ?? 1);
			if ($productId > 0) {
					Cart::add($productId, max(1, $qty));
			}
			$this->redirect('/cart');
			return '';
	}

	public function update(): string
	{
			\App\Middleware\Csrf::requireToken();
			foreach (($_POST['items'] ?? []) as $key => $qty) {
					Cart::update($key, (int)$qty);
			}
			$this->redirect('/cart');
			return '';
	}

	public function remove(): string
	{
			\App\Middleware\Csrf::requireToken();
			$key = $_POST['key'] ?? '';
			Cart::remove($key);
			$this->redirect('/cart');
			return '';
	}

	public function clear(): string
	{
			\App\Middleware\Csrf::requireToken();
			Cart::clear();
			$this->redirect('/cart');
			return '';
	}
}