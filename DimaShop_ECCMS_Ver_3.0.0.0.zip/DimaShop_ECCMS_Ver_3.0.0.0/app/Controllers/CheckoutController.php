<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Config;
use App\Controller;
use App\Models\Order;
use App\Services\Cart;
use App\Services\Payment\Zarinpal;

class CheckoutController extends Controller
{
	public function index(): string
	{
			$totals = Cart::totals();
			if ($totals['total'] <= 0) {
					$this->redirect('/cart');
			}
			return $this->view('checkout', compact('totals'));
	}

	public function placeOrder(): string
	{
			\App\Middleware\Csrf::requireToken();
			$totals = Cart::totals();
			if ($totals['total'] <= 0) {
					$this->redirect('/cart');
			}

			$customer = [
					'email' => $_POST['email'] ?? null,
					'name' => $_POST['name'] ?? null,
					'phone' => $_POST['phone'] ?? null,
					'address' => $_POST['address'] ?? null,
					'city' => $_POST['city'] ?? null,
					'postal_code' => $_POST['postal_code'] ?? null,
			];

			$items = [];
			foreach ($totals['lines'] as $line) {
					$p = $line['product'];
					$items[] = [
							'product_id' => (int)$p['id'],
							'variation_id' => null,
							'name' => $p['name'],
							'sku' => $p['sku'] ?? null,
							'price' => (int)$line['price'],
							'qty' => (int)$line['qty'],
							'total' => (int)$line['total'],
					];
			}

			$orderData = array_merge($customer, [
					'subtotal' => $totals['subtotal'],
					'discount' => $totals['discount'],
					'tax' => $totals['tax'],
					'shipping_cost' => $totals['shipping'],
					'total' => $totals['total'],
					'payment_status' => 'unpaid',
					'payment_method' => 'zarinpal',
					'status' => 'pending',
			]);

			$orderId = (new Order())->create($orderData, $items);

			$callback = rtrim(Config::APP_URL, '/') . '/payment/callback?order_id=' . $orderId;
			$desc = 'پرداخت سفارش #' . $orderId . ' در ' . Config::APP_NAME;
			$req = Zarinpal::requestPayment((int)$totals['total'], $callback, $desc, $customer['email'], $customer['phone']);

			if ($req['success']) {
					header('Location: ' . $req['start_pay']);
					exit;
			}

			return $this->view('checkout', [
					'totals' => $totals,
					'error' => 'خطا در ایجاد تراکنش: ' . ($req['message'] ?? 'نامشخص'),
			]);
	}

	public function success(string $id): string
	{
			$order = (new \App\Models\Order())->find((int)$id);
			if (!$order) {
					http_response_code(404);
					return 'سفارش یافت نشد';
			}
			return $this->view('order-success', compact('order'));
	}
}