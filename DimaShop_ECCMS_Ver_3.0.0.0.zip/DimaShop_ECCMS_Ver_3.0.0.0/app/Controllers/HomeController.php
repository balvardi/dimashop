<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Controller;
use App\Models\Product;

class HomeController extends Controller
{
	public function index(): string
	{
			$products = (new Product())->latest(12);
			return $this->view('home', compact('products'));
	}
}