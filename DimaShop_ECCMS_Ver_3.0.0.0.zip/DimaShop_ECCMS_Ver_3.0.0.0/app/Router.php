<?php
declare(strict_types=1);

namespace App;

class Router
{
	private array $routes = ['GET' => [], 'POST' => []];

	public function get(string $pattern, $handler): void
	{
			$this->routes['GET'][$pattern] = $handler;
	}
	public function post(string $pattern, $handler): void
	{
			$this->routes['POST'][$pattern] = $handler;
	}

	public function dispatch(): void
	{
			$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
			$uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?? '/';
			$uri = rtrim($uri, '/') ?: '/';

			foreach ($this->routes[$method] as $pattern => $handler) {
					$regex = preg_replace('#\\{([a-zA-Z_][a-zA-Z0-9_]*)\\}#', '(?P<$1>[^/]+)', $pattern);
					$regex = '#^' . rtrim($regex, '/') . '$#';
					if (preg_match($regex, $uri, $matches)) {
							$params = array_filter($matches, 'is_string', ARRAY_FILTER_USE_KEY);
							return $this->invoke($handler, $params);
					}
			}

			http_response_code(404);
			echo '404 Not Found';
	}

	private function invoke($handler, array $params): void
	{
			if (is_callable($handler)) {
					echo call_user_func_array($handler, $params);
					return;
			}
			if (is_array($handler) && count($handler) === 2) {
					[$class, $method] = $handler;
					$controller = new $class();
					echo call_user_func_array([$controller, $method], $params);
					return;
			}
			throw new \RuntimeException('Invalid route handler');
	}
}