<?php
declare(strict_types=1);

namespace App\Services;

use App\Models\Product;

class Cart
{
	private const KEY = '_cart';

	public static function items(): array
	{
			return $_SESSION[self::KEY]['items'] ?? [];
	}

	public static function add(int $productId, int $qty = 1, ?int $variationId = null): void
	{
			$key = $productId . ':' . ($variationId ?? 0);
			$items = self::items();
			if (isset($items[$key])) {
					$items[$key]['qty'] += $qty;
			} else {
					$items[$key] = ['product_id' => $productId, 'variation_id' => $variationId, 'qty' => $qty];
			}
			$_SESSION[self::KEY]['items'] = $items;
	}

	public static function update(string $key, int $qty): void
	{
			$items = self::items();
			if (isset($items[$key])) {
					$items[$key]['qty'] = max(1, $qty);
					$_SESSION[self::KEY]['items'] = $items;
			}
	}

	public static function remove(string $key): void
	{
			$items = self::items();
			unset($items[$key]);
			$_SESSION[self::KEY]['items'] = $items;
	}

	public static function clear(): void
	{
			$_SESSION[self::KEY] = ['items' => []];
	}

	public static function totals(): array
	{
			$subtotal = 0;
			$lines = [];
			foreach (self::items() as $key => $line) {
					$product = (new Product())->findById($line['product_id']);
					if (!$product) continue;
					$price = (int)($product['sale_price'] ?? $product['price']);
					$lineTotal = $price * $line['qty'];
					$subtotal += $lineTotal;
					$lines[] = [
							'key' => $key,
							'product' => $product,
							'qty' => $line['qty'],
							'price' => $price,
							'total' => $lineTotal,
					];
			}
			$discount = 0;
			if (!empty($_SESSION['_coupon'])) {
					$coupon = $_SESSION['_coupon'];
					if ($coupon['type'] === 'percent') {
							$discount = (int)floor($subtotal * ($coupon['amount'] / 100));
					} else {
							$discount = (int)$coupon['amount'];
					}
					$discount = min($discount, $subtotal);
			}
			$tax = (int)floor(($subtotal - $discount) * 0.0);
			$shipping = (int)($_SESSION['_shipping_cost'] ?? 0);

			$total = max(0, $subtotal - $discount + $tax + $shipping);

			return compact('lines', 'subtotal', 'discount', 'tax', 'shipping', 'total');
	}
}