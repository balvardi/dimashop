<?php
declare(strict_types=1);

namespace App\Services\Payment;

use App\Config;

class Zarinpal
{
	public static function requestPayment(int $amountToman, string $callbackUrl, string $description, ?string $email = null, ?string $mobile = null): array
	{
			$endpoints = Config::zarinpalEndpoints();
			$payload = [
					'merchant_id' => Config::ZARINPAL_MERCHANT_ID,
					'amount' => \App\Helpers::rialize($amountToman),
					'callback_url' => $callbackUrl,
					'description' => $description,
					'metadata' => [
							'email' => $email,
							'mobile' => $mobile,
					],
			];
			$resp = self::postJson($endpoints['request'], $payload);
			if (isset($resp['data']) && $resp['data']['code'] == 100) {
					$authority = $resp['data']['authority'];
					$startPay = $endpoints['startpay'] . $authority;
					return ['success' => true, 'authority' => $authority, 'start_pay' => $startPay];
			}
			$message = $resp['errors']['message'] ?? 'Payment request failed';
			return ['success' => false, 'message' => $message, 'response' => $resp];
	}

	public static function verifyPayment(int $amountToman, string $authority): array
	{
			$endpoints = Config::zarinpalEndpoints();
			$payload = [
					'merchant_id' => Config::ZARINPAL_MERCHANT_ID,
					'amount' => \App\Helpers::rialize($amountToman),
					'authority' => $authority,
			];
			$resp = self::postJson($endpoints['verify'], $payload);
			if (isset($resp['data']) && $resp['data']['code'] == 100) {
					return ['success' => true, 'ref_id' => $resp['data']['ref_id']];
			}
			$message = $resp['errors']['message'] ?? 'Payment verify failed';
			return ['success' => false, 'message' => $message, 'response' => $resp];
	}

	private static function postJson(string $url, array $data): array
	{
			$ch = curl_init($url);
			curl_setopt_array($ch, [
					CURLOPT_POST => true,
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
					CURLOPT_POSTFIELDS => json_encode($data, JSON_UNESCAPED_UNICODE),
					CURLOPT_TIMEOUT => 30,
			]);
			$result = curl_exec($ch);
			$err = curl_error($ch);
			curl_close($ch);
			if ($err) {
					return ['errors' => ['message' => 'cURL error: ' . $err]];
			}
			$decoded = json_decode($result, true);
			return is_array($decoded) ? $decoded : ['errors' => ['message' => 'Invalid JSON response']];
	}
}