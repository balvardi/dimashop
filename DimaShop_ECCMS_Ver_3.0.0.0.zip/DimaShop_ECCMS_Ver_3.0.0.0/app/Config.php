<?php
declare(strict_types=1);

namespace App;

class Config
{
	// Database
	public const DB_HOST = 'localhost';
	public const DB_NAME = 'dimashop';
	public const DB_USER = 'admin';
	public const DB_PASS = 'admin';
	public const DB_CHARSET = 'utf8mb4';

	// App
	public const APP_URL = 'http://localhost:8888/Script/DimaShop_ECCMS_Ver_3.0.0.0';
	public const APP_NAME = 'Dima Shop';
	public const APP_LOCALE = 'fa_IR';
	public const APP_TIMEZONE = 'Asia/Tehran';
	public const APP_DEBUG = false;
	public const CONTACT_EMAIL = 'info@Dima.shop.ir';

	// CSRF
	public const CSRF_TOKEN_KEY = '_csrf';

	// Currency
	public const CURRENCY = 'Toman';
	public const ZARINPAL_AMOUNT_IN_RIAL = true;

	// ZarinPal
	public const ZARINPAL_MERCHANT_ID = '8aa268bc-1840-4c04-9bae-9e6893c3aaf4';
	public const ZARINPAL_SANDBOX = false;

	public static function zarinpalEndpoints(): array
	{
			$sandbox = self::ZARINPAL_SANDBOX;
			return [
					'request' => $sandbox
							? 'https://sandbox.zarinpal.com/pg/v4/payment/request.json'
							: 'https://api.zarinpal.com/pg/v4/payment/request.json',
					'verify' => $sandbox
							? 'https://sandbox.zarinpal.com/pg/v4/payment/verify.json'
							: 'https://api.zarinpal.com/pg/v4/payment/verify.json',
					'startpay' => $sandbox
							? 'https://sandbox.zarinpal.com/pg/StartPay/'
							: 'https://www.zarinpal.com/pg/StartPay/',
			];
	}
}