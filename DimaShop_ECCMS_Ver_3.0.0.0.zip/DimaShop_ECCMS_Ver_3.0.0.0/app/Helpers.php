<?php
declare(strict_types=1);

namespace App;

class Helpers
{
	public static function e(string $str): string
	{
			return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
	}
	public static function money(int|float $amount): string
	{
			$formatted = number_format($amount);
			return $formatted . ' ' . Config::CURRENCY;
	}
	public static function csrfToken(): string
	{
			if (!isset($_SESSION[Config::CSRF_TOKEN_KEY])) {
					$_SESSION[Config::CSRF_TOKEN_KEY] = bin2hex(random_bytes(32));
			}
			return $_SESSION[Config::CSRF_TOKEN_KEY];
	}
	public static function verifyCsrf(?string $token): bool
	{
			return isset($_SESSION[Config::CSRF_TOKEN_KEY]) && hash_equals($_SESSION[Config::CSRF_TOKEN_KEY], (string)$token);
	}

	public static function rialize(int $amountToman): int
	{
			return Config::ZARINPAL_AMOUNT_IN_RIAL ? $amountToman * 10 : $amountToman;
	}
}

class Hooks
{
	private static array $actions = [];
	private static array $filters = [];

	public static function init(): void {}

	public static function addAction(string $hook, callable $cb, int $prio = 10): void
	{
			self::$actions[$hook][$prio][] = $cb;
	}
	public static function doAction(string $hook, ...$args): void
	{
			if (!isset(self::$actions[$hook])) return;
			ksort(self::$actions[$hook]);
			foreach (self::$actions[$hook] as $cbs) {
					foreach ($cbs as $cb) $cb(...$args);
			}
	}

	public static function addFilter(string $hook, callable $cb, int $prio = 10): void
	{
			self::$filters[$hook][$prio][] = $cb;
	}
	public static function applyFilters(string $hook, $value, ...$args)
	{
			if (!isset(self::$filters[$hook])) return $value;
			ksort(self::$filters[$hook]);
			foreach (self::$filters[$hook] as $cbs) {
					foreach ($cbs as $cb) $value = $cb($value, ...$args);
			}
			return $value;
	}
}