<?php
declare(strict_types=1);

namespace App;

class Controller
{
	protected function view(string $template, array $data = []): string
	{
			extract($data);
			ob_start();
			include __DIR__ . "/Views/{$template}.php";
			return ob_get_clean();
	}

	protected function redirect(string $path): void
	{
			header('Location: ' . rtrim(Config::APP_URL, '/') . $path);
			exit;
	}

	protected function isPost(): bool
	{
			return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
	}

	protected function requireAdmin(): void
	{
			if (!isset($_SESSION['admin_id'])) {
					$this->redirect('/admin/login');
			}
	}
}