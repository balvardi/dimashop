<?php
declare(strict_types=1);

namespace App;

use PDO;
use PDOException;

class Database
{
	private static ?PDO $pdo = null;

	public static function pdo(): PDO
	{
			if (self::$pdo === null) {
					$dsn = sprintf('mysql:host=%s;dbname=%s;charset=%s', Config::DB_HOST, Config::DB_NAME, Config::DB_CHARSET);
					$options = [
							PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
							PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
							PDO::ATTR_EMULATE_PREPARES => false,
					];
					try {
							self::$pdo = new PDO($dsn, Config::DB_USER, Config::DB_PASS, $options);
					} catch (PDOException $e) {
							if (Config::APP_DEBUG) {
									die('DB Connection failed: ' . $e->getMessage());
							}
							die('DB Connection failed.');
					}
			}
			return self::$pdo;
	}
}