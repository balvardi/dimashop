<?php
declare(strict_types=1);

namespace App\Models;

use App\Model;
use PDO;

class Product extends Model
{
	public function latest(int $limit = 12): array
	{
			$stmt = $this->db->prepare("SELECT * FROM products WHERE status='publish' ORDER BY id DESC LIMIT :lim");
			$stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
			$stmt->execute();
			return $stmt->fetchAll();
	}

	public function findBySlug(string $slug): ?array
	{
			$stmt = $this->db->prepare("SELECT * FROM products WHERE slug = :slug AND status='publish' LIMIT 1");
			$stmt->execute([':slug' => $slug]);
			$row = $stmt->fetch();
			return $row ?: null;
	}

	public function findById(int $id): ?array
	{
			$stmt = $this->db->prepare("SELECT * FROM products WHERE id = :id LIMIT 1");
			$stmt->execute([':id' => $id]);
			$row = $stmt->fetch();
			return $row ?: null;
	}

	public function create(array $data): int
	{
			$stmt = $this->db->prepare("INSERT INTO products (name, slug, description, price, sale_price, sku, stock_qty, status) VALUES (:name, :slug, :description, :price, :sale_price, :sku, :stock_qty, :status)");
			$stmt->execute([
					':name' => $data['name'],
					':slug' => $data['slug'],
					':description' => $data['description'] ?? '',
					':price' => (int)$data['price'],
					':sale_price' => $data['sale_price'] !== '' ? (int)$data['sale_price'] : null,
					':sku' => $data['sku'] ?? null,
					':stock_qty' => (int)($data['stock_qty'] ?? 0),
					':status' => $data['status'] ?? 'publish',
			]);
			return (int)$this->db->lastInsertId();
	}

	public function delete(int $id): void
	{
			$stmt = $this->db->prepare("DELETE FROM products WHERE id=:id");
			$stmt->execute([':id' => $id]);
	}
}