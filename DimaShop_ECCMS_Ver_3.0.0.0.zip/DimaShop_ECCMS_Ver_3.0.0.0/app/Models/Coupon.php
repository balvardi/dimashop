<?php
declare(strict_types=1);

namespace App\Models;

use App\Model;

class Coupon extends Model
{
	public function findActiveByCode(string $code): ?array
	{
			$stmt = $this->db->prepare("SELECT * FROM coupons WHERE code=:code AND (expires_at IS NULL OR expires_at > NOW()) AND (usage_limit IS NULL OR usage_limit > used) LIMIT 1");
			$stmt->execute([':code' => $code]);
			$row = $stmt->fetch();
			return $row ?: null;
	}

	public function incrementUse(int $id): void
	{
			$stmt = $this->db->prepare("UPDATE coupons SET used = used + 1 WHERE id=:id AND (usage_limit IS NULL OR used < usage_limit)");
			$stmt->execute([':id' => $id]);
	}
}