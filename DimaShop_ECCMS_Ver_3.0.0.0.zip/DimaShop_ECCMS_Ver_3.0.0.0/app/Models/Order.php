<?php
declare(strict_types=1);

namespace App\Models;

use App\Model;
use PDO;

class Order extends Model
{
	public function create(array $data, array $items): int
	{
			$this->db->beginTransaction();
			try {
					$stmt = $this->db->prepare("INSERT INTO orders (user_id, status, total, subtotal, discount, shipping_cost, tax, payment_status, payment_method, payment_ref, email, name, phone, address, city, postal_code) VALUES (:user_id, :status, :total, :subtotal, :discount, :shipping_cost, :tax, :payment_status, :payment_method, :payment_ref, :email, :name, :phone, :address, :city, :postal_code)");
					$stmt->execute([
							':user_id' => $data['user_id'] ?? null,
							':status' => $data['status'] ?? 'pending',
							':total' => (int)$data['total'],
							':subtotal' => (int)$data['subtotal'],
							':discount' => (int)$data['discount'],
							':shipping_cost' => (int)$data['shipping_cost'],
							':tax' => (int)$data['tax'],
							':payment_status' => $data['payment_status'] ?? 'unpaid',
							':payment_method' => $data['payment_method'] ?? 'zarinpal',
							':payment_ref' => $data['payment_ref'] ?? null,
							':email' => $data['email'] ?? null,
							':name' => $data['name'] ?? null,
							':phone' => $data['phone'] ?? null,
							':address' => $data['address'] ?? null,
							':city' => $data['city'] ?? null,
							':postal_code' => $data['postal_code'] ?? null,
					]);
					$orderId = (int)$this->db->lastInsertId();

					$ins = $this->db->prepare("INSERT INTO order_items (order_id, product_id, variation_id, name, sku, price, qty, total) VALUES (:order_id, :product_id, :variation_id, :name, :sku, :price, :qty, :total)");
					foreach ($items as $it) {
							$ins->execute([
									':order_id' => $orderId,
									':product_id' => $it['product_id'],
									':variation_id' => $it['variation_id'] ?? null,
									':name' => $it['name'],
									':sku' => $it['sku'] ?? null,
									':price' => (int)$it['price'],
									':qty' => (int)$it['qty'],
									':total' => (int)$it['total'],
							]);
					}

					$this->db->commit();
					return $orderId;
			} catch (\Throwable $e) {
					$this->db->rollBack();
					throw $e;
			}
	}

	public function markPaid(int $orderId, string $refId): void
	{
			$stmt = $this->db->prepare("UPDATE orders SET payment_status='paid', status='processing', payment_ref=:ref WHERE id=:id");
			$stmt->execute([':ref' => $refId, ':id' => $orderId]);
	}

	public function find(int $id): ?array
	{
			$stmt = $this->db->prepare("SELECT * FROM orders WHERE id=:id");
			$stmt->execute([':id' => $id]);
			$row = $stmt->fetch();
			return $row ?: null;
	}

	public function all(int $limit = 50): array
	{
			$stmt = $this->db->prepare("SELECT * FROM orders ORDER BY id DESC LIMIT :lim");
			$stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
			$stmt->execute();
			return $stmt->fetchAll();
	}
}